"""LLM 接入层：后台小任务的同步客户端 + agents SDK 的 tracing 开关。

对话主链路不经过本模块的客户端：chat_service 每次运行都会新建
AsyncOpenAI 客户端并显式绑给 Agent（因为 asyncio.run 每轮换事件循环，
共享客户端会复用旧循环的连接池导致 Event loop is closed）。

本模块只负责：
- set_tracing_disabled(True)：本地项目不上传 trace
- chat_json：记忆提炼 / 掌握度判定等后台结构化小任务用的同步客户端
"""
from typing import Optional

from agents import set_tracing_disabled
from openai import OpenAI

from infra import config

set_tracing_disabled(True)

# ---------------------------------------------------------------------------
# 后台小任务（记忆提炼 / 掌握度判定）：同步 OpenAI 客户端
# ---------------------------------------------------------------------------

_sync_client: Optional[OpenAI] = None


def _get_sync_client() -> OpenAI:
    global _sync_client
    if _sync_client is None:
        if not config.API_KEY:
            raise RuntimeError("未配置 API_KEY，请检查 .env 文件。")
        _sync_client = OpenAI(base_url=config.BASE_URL, api_key=config.API_KEY)
    return _sync_client


def chat_json(messages, model: Optional[str] = None) -> str:
    """发送一轮对话并要求返回 JSON 文本（用于记忆提炼等结构化任务）。"""
    resp = _get_sync_client().chat.completions.create(
        model=model or config.MODEL,
        messages=messages,
        temperature=0.2,
        response_format={"type": "json_object"},
    )
    return resp.choices[0].message.content or "{}"
