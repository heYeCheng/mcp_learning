"""文件解析：把 txt / md / docx / 文字类 PDF 读成"物理页"列表，供小R 切块压缩。

PDF 解析降级链：pdfplumber → pypdf → 返回空（避免安装重依赖）。
docx 用 python-docx；txt/md 按字符数估页。
"""
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_PAGE_CHARS = 1800  # 一页约多少字（中文正文）

# 常见章节标题样式，用于 detect_page_headings
_CHAPTER_RE = re.compile(
    r"^\s*(第[0-9一二三四五六七八九十百千万]+[章卷部篇节]"
    r"|Chapter\s+\d+"
    r"|[0-9]+(\.[0-9]+){0,2}\s+[^\n]{0,30})[\s:：]",
    re.IGNORECASE,
)
_HEADING_STYLE_RE = re.compile(r"^\s*(#{1,6}\s+|[0-9]+(\.[0-9]+){1,3}\s+)")


def _clean_extracted(text: str) -> str:
    """清洗提取出的文本：合并空白、去掉孤立页码等。"""
    if not text:
        return ""
    text = text.replace("\x00", "").replace("\u3000", " ").replace("\t", " ")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if re.fullmatch(r"[-—–_]{3,}|\d{1,4}|Page\s+\d+", s, re.IGNORECASE):
            continue  # 去掉孤立页码/分隔线
        lines.append(line.rstrip())
    return "\n".join(lines).strip()


def _split_pages(text: str, page_chars: int) -> list:
    """把整段文本按估算页字符数切分，返回 [{page_no, text, heading}]。"""
    if not text:
        return []
    pages = []
    n = page_chars
    for i in range(0, len(text), n):
        pages.append({
            "page_no": i // n + 1,
            "text": text[i:i + n],
            "heading": "",
        })
    return pages


def read_pages(path: str, page_chars: int = DEFAULT_PAGE_CHARS) -> list:
    """读取文件为物理页列表 [{page_no, text, heading}]。"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"文件不存在：{path}")

    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return _read_pdf_pages(p, page_chars)
    if suffix == ".docx":
        return _read_docx_pages(p, page_chars)
    # txt / md / 其他纯文本
    raw = p.read_text(encoding="utf-8", errors="ignore")
    return _split_pages(raw, page_chars)


def _read_pdf_pages(p: Path, page_chars: int) -> list:
    """PDF 降级链：pdfplumber → pypdf → 空。"""
    # 1) pdfplumber（最稳，带页码）
    try:
        import pdfplumber

        pages = []
        with pdfplumber.open(p) as pdf:
            for i, pg in enumerate(pdf.pages, 1):
                txt = pg.extract_text() or ""
                txt = _clean_extracted(txt)
                if txt:
                    pages.append({"page_no": i, "text": txt, "heading": ""})
        if pages and sum(len(x["text"]) for x in pages) >= 300:
            return pages
    except Exception as exc:
        logger.warning("pdfplumber 解析失败，尝试 pypdf: %s", exc)

    # 2) pypdf
    try:
        from pypdf import PdfReader

        reader = PdfReader(str(p))
        pages = []
        for i, pg in enumerate(reader.pages, 1):
            txt = pg.extract_text() or ""
            txt = _clean_extracted(txt)
            if txt:
                pages.append({"page_no": i, "text": txt, "heading": ""})
        if pages:
            return pages
    except Exception as exc:
        logger.warning("pypdf 解析失败: %s", exc)

    raise ValueError("该 PDF 无法提取文字（可能是扫描件）。请先转成文字版 PDF 或 txt/docx。")


def _read_docx_pages(p: Path, page_chars: int) -> list:
    """docx 用 python-docx 提取段落文本，按页字符数切分。"""
    try:
        import docx
    except ImportError:
        raise ValueError("缺少 python-docx，请 pip install python-docx")
    document = docx.Document(str(p))
    paras = [para.text for para in document.paragraphs if para.text.strip()]
    text = "\n\n".join(paras)
    return _split_pages(_clean_extracted(text), page_chars)


def read_text_stream(path: str) -> str:
    """读取 txt / md / docx 为整段文本流（不做虚拟分页），供按章节标题行切章。"""
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix == ".docx":
        try:
            import docx
        except ImportError:
            raise ValueError("缺少 python-docx，请 pip install python-docx")
        document = docx.Document(str(p))
        paras = [para.text for para in document.paragraphs if para.text.strip()]
        return _clean_extracted("\n\n".join(paras))
    raw = p.read_text(encoding="utf-8", errors="ignore")
    return _clean_extracted(raw)


# 章节标题行（用于 txt/md/docx 文本流切章）：第X章/卷/节/回、Chapter N、Markdown 标题
_CHAPTER_LINE_RE = re.compile(
    r"^\s*(第\s*[0-9一二三四五六七八九十百千万]+\s*[章卷部篇节回]"
    r"|Chapter\s+[0-9IVXLC]+"
    r"|#{1,3}\s+\S)"
    r".{0,60}$",
    re.IGNORECASE,
)


def split_text_by_chapters(text: str) -> list:
    """把文本流按章节标题行切成 [(章标题, 章内容)]。

    无任何标题行时返回 [("", 全文)]，调用方自行兜底。
    """
    lines = text.splitlines()
    segs, cur_title, cur = [], "", []
    found = False
    for ln in lines:
        s = ln.strip()
        if s and len(s) <= 70 and _CHAPTER_LINE_RE.match(s):
            found = True
            if cur:
                segs.append((cur_title, "\n".join(cur).strip()))
            cur_title, cur = s, [ln]
        else:
            cur.append(ln)
    if cur:
        segs.append((cur_title, "\n".join(cur).strip()))
    if not found:
        return [("", text.strip())]
    return segs


def detect_page_headings(pages: list) -> list:
    """按页识别章节标题（强模式：明确编号/标记样式），返回与 pages 等长的 bool 列表。

    注意：不再把"任意短行"当标题——那会导致一页一块。
    """
    result = []
    for p in pages:
        text = p.get("text") or ""
        first_line = (text.splitlines() or [""])[0].strip()
        result.append(bool(
            _CHAPTER_RE.match(first_line)
            or _HEADING_STYLE_RE.match(first_line)
        ))
    return result


def pdf_bookmarks(path: str) -> list:
    """提取 PDF 顶层书签目录，返回 [{"page_no"(1起), "title"}]，按页码升序。

    用书签切章是最准确的方式（技术书 PDF 基本都带书签）。
    """
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    marks, seen = [], set()
    for item in (reader.outline or []):
        if isinstance(item, list):
            continue  # 只取顶层书签
        try:
            title = (item.title or "").strip()[:60]
            page_no = reader.get_destination_page_number(item) + 1
            if title and page_no > 0 and page_no not in seen:
                seen.add(page_no)
                marks.append({"page_no": page_no, "title": title})
        except Exception:
            continue
    marks.sort(key=lambda m: m["page_no"])
    return marks
