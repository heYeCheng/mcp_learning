"""全局配置：从 .env 读取 OpenAI 兼容接口参数（火山方舟 / 任意兼容网关）。

PROJECT_ROOT 是整个项目唯一的位置锚点：所有目录（data/ skills/ external_tools/）
都从它推导，模块放到任何子包里都不会断。
"""
import os
from pathlib import Path

from dotenv import load_dotenv

# 项目根 = infra/ 的上一级
PROJECT_ROOT = Path(__file__).resolve().parent.parent

load_dotenv(PROJECT_ROOT / ".env")

# ===== OpenAI 兼容接口 =====
# 默认指向火山方舟按量计费网关；在公司部署时填公司的 BASE_URL / API_KEY / MODEL 即可。
BASE_URL = os.getenv("BASE_URL", "https://ark.cn-beijing.volces.com/api/v3")
API_KEY = os.getenv("API_KEY", "")
MODEL = os.getenv("MODEL", "")

# ===== 数据目录（运行时自动创建） =====
DATA_DIR = PROJECT_ROOT / "data"
VIZ_DIR = DATA_DIR / "viz"        # 小V 生成的可视化页面
UPLOAD_DIR = DATA_DIR / "uploads" # 小R 上传的文件
DATA_DIR.mkdir(parents=True, exist_ok=True)
VIZ_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

MEMORY_DB = DATA_DIR / "memory.db"
LIBRARY_DB = DATA_DIR / "library.db"

# ===== 记忆分层时长（秒） =====
SHORT_TTL_DAYS = 3      # 短期记忆：只维持 3 天
MID_TTL_DAYS = 90       # 中期记忆：3 个月
LONG_TTL_DAYS = None    # 长期记忆：人工确认后永久保存

if not API_KEY:
    print("[提示] 未配置 API_KEY，请复制 .env.example 为 .env 并填入公司的接口参数。")
