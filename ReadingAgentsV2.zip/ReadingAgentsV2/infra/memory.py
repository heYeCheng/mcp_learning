"""三态记忆存储层（SQLite）。

记忆分三层，每条都带时间戳：
- 短期记忆 (short)：自动沉淀，3 天过期。对话要点/近期上下文。
- 中期记忆 (mid)  ：自动沉淀，3 个月过期。较重要的知识。
- 长期记忆 (long) ：人工确认后永久保存。由 AI 提炼出候选 → 用户批量确认转正；
                    也支持手工强制记忆（用户直接在界面添加）。

另有：
- pending_memories：AI 提炼出的"待确认候选"，用户确认后转长期。
- hier_memories：小V 的层级记忆（书名/标题 → 章节 → 具体内容）。
- conversations：对话历史（属于短期上下文的一部分）。
"""
import json
import sqlite3
import time
from typing import Optional

from infra import config

TYPES = ("preference", "skill", "knowledge", "fact", "project")
TIERS = ("short", "mid", "long")
TIER_LABELS = {"short": "短期(3天)", "mid": "中期(3个月)", "long": "长期(永久)"}


def _expires(tier: str, now: Optional[float] = None) -> Optional[float]:
    """按分层时长计算过期时间；长期无过期。"""
    now = now or time.time()
    if tier == "short":
        return now + config.SHORT_TTL_DAYS * 86400
    if tier == "mid":
        return now + config.MID_TTL_DAYS * 86400
    return None  # long 永久


_INIT = """
CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    tier TEXT NOT NULL,
    type TEXT NOT NULL,
    content TEXT NOT NULL,
    source TEXT,
    created_at REAL NOT NULL,
    expires_at REAL,
    confirmed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS pending_memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    type TEXT NOT NULL,
    content TEXT NOT NULL,
    source TEXT,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS hier_memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    book_title TEXT NOT NULL,
    chapter TEXT DEFAULT '',
    content TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS mastery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    topic TEXT NOT NULL,
    level TEXT NOT NULL DEFAULT 'weak',
    note TEXT DEFAULT '',
    book_title TEXT DEFAULT '',
    updated_at REAL NOT NULL,
    UNIQUE(agent_id, topic)
);
CREATE INDEX IF NOT EXISTS idx_conv_agent ON conversations(agent_id);
CREATE INDEX IF NOT EXISTS idx_mem_agent ON memories(agent_id);
CREATE INDEX IF NOT EXISTS idx_pend_agent ON pending_memories(agent_id);
CREATE INDEX IF NOT EXISTS idx_hier_agent ON hier_memories(agent_id);
CREATE INDEX IF NOT EXISTS idx_mastery_agent ON mastery(agent_id);
"""


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(config.MEMORY_DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with _conn() as conn:
        conn.executescript(_INIT)


# ---------------------------------------------------------------------------
# 对话历史（短期上下文）
# ---------------------------------------------------------------------------

def add_message(agent_id: str, role: str, content: str) -> None:
    with _conn() as conn:
        conn.execute(
            "INSERT INTO conversations(agent_id, role, content, created_at) VALUES(?,?,?,?)",
            (agent_id, role, content, time.time()),
        )


def get_history(agent_id: str, limit: int = 30) -> list:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT role, content FROM conversations WHERE agent_id=? "
            "ORDER BY id DESC LIMIT ?",
            (agent_id, limit),
        ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def clear_history(agent_id: str) -> None:
    with _conn() as conn:
        conn.execute("DELETE FROM conversations WHERE agent_id=?", (agent_id,))


# ---------------------------------------------------------------------------
# 三层记忆
# ---------------------------------------------------------------------------

def add_memory(agent_id: str, tier: str, mtype: str, content: str,
               source: str = "chat") -> Optional[int]:
    """新增一条记忆（自动带时间戳与过期时间）。内容完全重复则跳过，返回 id 或 None。"""
    if tier not in TIERS:
        tier = "short"
    if mtype not in TYPES:
        mtype = "knowledge"
    content = (content or "").strip()
    if not content:
        return None
    now = time.time()
    with _conn() as conn:
        dup = conn.execute(
            "SELECT id FROM memories WHERE agent_id=? AND content=?",
            (agent_id, content),
        ).fetchone()
        if dup:
            return None
        cur = conn.execute(
            "INSERT INTO memories(agent_id, tier, type, content, source, created_at, expires_at, confirmed) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (agent_id, tier, mtype, content, source, now, _expires(tier, now),
             1 if tier == "long" else 0),
        )
        return cur.lastrowid


def force_add_long(agent_id: str, mtype: str, content: str, source: str = "manual") -> Optional[int]:
    """手工强制记忆：直接写入长期记忆（无需走待确认流程）。"""
    return add_memory(agent_id, "long", mtype, content, source=source)


def list_memories(agent_id: str, tier: Optional[str] = None) -> list:
    """列出某 Agent 的记忆（可过滤分层）。"""
    with _conn() as conn:
        if tier:
            rows = conn.execute(
                "SELECT * FROM memories WHERE agent_id=? AND tier=? ORDER BY id ASC",
                (agent_id, tier),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM memories WHERE agent_id=? ORDER BY id ASC",
                (agent_id,),
            ).fetchall()
    return [dict(r) for r in rows]


def get_active_memories(agent_id: str) -> list:
    """返回当前有效的记忆：未过期的 short + 未过期的 mid + 全部 long（含确认标记）。"""
    now = time.time()
    result = []
    for m in list_memories(agent_id):
        if m["tier"] in ("short", "mid"):
            if m.get("expires_at") and m["expires_at"] <= now:
                continue  # 已过期，不再注入
        result.append(m)
    return result


def clean_expired(agent_id: Optional[str] = None) -> int:
    """清理过期记忆（short/mid），返回删除条数。"""
    now = time.time()
    with _conn() as conn:
        if agent_id:
            cur = conn.execute(
                "DELETE FROM memories WHERE agent_id=? AND tier IN ('short','mid') AND expires_at <= ?",
                (agent_id, now),
            )
        else:
            cur = conn.execute(
                "DELETE FROM memories WHERE tier IN ('short','mid') AND expires_at <= ?",
                (now,),
            )
    return cur.rowcount


def delete_memory(agent_id: str, memory_id: int) -> None:
    with _conn() as conn:
        conn.execute("DELETE FROM memories WHERE agent_id=? AND id=?", (agent_id, memory_id))


def count_memories(agent_id: str) -> int:
    with _conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS c FROM memories WHERE agent_id=?", (agent_id,)
        ).fetchone()
    return row["c"]


# ---------------------------------------------------------------------------
# 待确认候选（AI 提炼 → 用户批量确认 → 长期记忆）
# ---------------------------------------------------------------------------

def add_pending(agent_id: str, mtype: str, content: str, source: str = "chat") -> Optional[int]:
    if mtype not in TYPES:
        mtype = "knowledge"
    content = (content or "").strip()
    if not content:
        return None
    with _conn() as conn:
        dup = conn.execute(
            "SELECT id FROM pending_memories WHERE agent_id=? AND content=?",
            (agent_id, content),
        ).fetchone()
        if dup:
            return None
        cur = conn.execute(
            "INSERT INTO pending_memories(agent_id, type, content, source, created_at) "
            "VALUES(?,?,?,?,?)",
            (agent_id, mtype, content, source, time.time()),
        )
        return cur.lastrowid


def get_pending(agent_id: Optional[str] = None) -> list:
    with _conn() as conn:
        if agent_id:
            rows = conn.execute(
                "SELECT * FROM pending_memories WHERE agent_id=? ORDER BY id ASC",
                (agent_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM pending_memories ORDER BY agent_id, id ASC").fetchall()
    return [dict(r) for r in rows]


def approve_pending_batch(ids: list) -> int:
    """批量确认待确认候选 → 写入长期记忆并移除候选。返回成功转正条数。"""
    n = 0
    for pid in ids:
        with _conn() as conn:
            row = conn.execute(
                "SELECT * FROM pending_memories WHERE id=?", (pid,)
            ).fetchone()
            if not row:
                continue
            if add_memory(row["agent_id"], "long", row["type"], row["content"], row["source"] or "chat"):
                n += 1
            conn.execute("DELETE FROM pending_memories WHERE id=?", (pid,))
    return n


def reject_pending(ids: list) -> int:
    """批量驳回待确认候选（直接删除）。"""
    n = 0
    for pid in ids:
        with _conn() as conn:
            cur = conn.execute("DELETE FROM pending_memories WHERE id=?", (pid,))
            n += cur.rowcount
    return n


# ---------------------------------------------------------------------------
# 小V 层级记忆：书名/标题 → 章节 → 具体内容
# ---------------------------------------------------------------------------

def add_hier(agent_id: str, book_title: str, chapter: str = "", content: str = "") -> Optional[int]:
    book_title = (book_title or "").strip()
    content = (content or "").strip()
    if not book_title or not content:
        return None
    with _conn() as conn:
        # 同一 书名+章节 已存在则更新内容（避免堆积）
        row = conn.execute(
            "SELECT id FROM hier_memories WHERE agent_id=? AND book_title=? AND chapter=?",
            (agent_id, book_title, chapter),
        ).fetchone()
        now = time.time()
        if row:
            conn.execute(
                "UPDATE hier_memories SET content=?, created_at=? WHERE id=?",
                (content, now, row["id"]),
            )
            return row["id"]
        cur = conn.execute(
            "INSERT INTO hier_memories(agent_id, book_title, chapter, content, created_at) "
            "VALUES(?,?,?,?,?)",
            (agent_id, book_title, chapter, content, now),
        )
        return cur.lastrowid


def get_hier(agent_id: str) -> list:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM hier_memories WHERE agent_id=? ORDER BY book_title, id ASC",
            (agent_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def delete_hier(agent_id: str, hier_id: int) -> None:
    with _conn() as conn:
        conn.execute("DELETE FROM hier_memories WHERE agent_id=? AND id=?", (agent_id, hier_id))


# ---------------------------------------------------------------------------
# 掌握度档案（小B）：知识点 → 三档掌握程度，回答组后由模型调用 update_mastery 维护
# ---------------------------------------------------------------------------

def upsert_mastery(agent_id: str, topic: str, level: str,
                   note: str = "", book_title: str = "") -> dict:
    """更新某知识点的掌握度（同 topic 覆盖）。返回 {topic, level, prev_level, ...}，
    prev_level 为更新前的档位（新建时为 None），供模型向用户通报进步轨迹。"""
    topic = (topic or "").strip()
    if not topic:
        raise ValueError("topic 不能为空")
    now = time.time()
    with _conn() as conn:
        row = conn.execute(
            "SELECT id, level FROM mastery WHERE agent_id=? AND topic=?",
            (agent_id, topic),
        ).fetchone()
        prev = row["level"] if row else None
        if row:
            conn.execute(
                "UPDATE mastery SET level=?, note=?, book_title=?, updated_at=? WHERE id=?",
                (level, note or "", book_title or "", now, row["id"]),
            )
        else:
            conn.execute(
                "INSERT INTO mastery(agent_id, topic, level, note, book_title, updated_at) "
                "VALUES(?,?,?,?,?,?)",
                (agent_id, topic, level, note or "", book_title or "", now),
            )
    return {"topic": topic, "level": level, "prev_level": prev,
            "note": note, "book_title": book_title}


def get_mastery(agent_id: str) -> list:
    """全部掌握度档案，薄弱在前、已掌握在后，同档内按最近更新排序。"""
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM mastery WHERE agent_id=? "
            "ORDER BY CASE level WHEN 'weak' THEN 0 WHEN 'familiar' THEN 1 ELSE 2 END, "
            "updated_at DESC",
            (agent_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def delete_mastery(agent_id: str, mastery_id: int) -> None:
    with _conn() as conn:
        conn.execute("DELETE FROM mastery WHERE agent_id=? AND id=?", (agent_id, mastery_id))


def build_mastery_block(agent_id: str) -> str:
    """把掌握度档案拼成注入 prompt 的文本块（供小B 出题前查阅）。"""
    rows = get_mastery(agent_id)
    if not rows:
        return ""
    labels = {"weak": "薄弱", "familiar": "一般", "mastered": "已掌握"}
    lines = []
    for r in rows:
        book = f"（《{r['book_title']}》）" if r["book_title"] else ""
        note = f"｜{r['note']}" if r["note"] else ""
        lines.append(f"- {r['topic']}{book}：{labels.get(r['level'], r['level'])}{note}")
    return ("【用户掌握度档案（出题前必看：优先考察薄弱点，已掌握的不再重复问）】\n"
            + "\n".join(lines))


# ---------------------------------------------------------------------------
# 待读取文件路径（小R 上传后记住，供 read_file 使用）
# ---------------------------------------------------------------------------

def _upload_state_path():
    return config.UPLOAD_DIR / "last_path.json"


def set_uploaded_path(agent_id: str, path: str) -> None:
    data = {}
    p = _upload_state_path()
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    data[agent_id] = path
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def get_uploaded_path(agent_id: str) -> str:
    p = _upload_state_path()
    if not p.exists():
        return ""
    try:
        return json.loads(p.read_text(encoding="utf-8")).get(agent_id, "")
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# 注入系统提示词的记忆块
# ---------------------------------------------------------------------------

def build_memory_block(agent_id: str) -> str:
    """把当前有效记忆（短/中/长 + 层级记忆）拼成一段 system prompt 文本。

    层级记忆按「书名 → 章节 → 内容」三级缩进展示（小V 专属结构）。
    """
    parts = []
    active = get_active_memories(agent_id)
    if active:
        lines = []
        for m in active:
            tag = TIER_LABELS.get(m["tier"], m["tier"])
            lines.append(f"- [{m['type']}·{tag}] {m['content']}")
        parts.append("【你记住的内容（短/中/长期，请主动遵循和复用）】\n" + "\n".join(lines))

    hier = get_hier(agent_id)
    if hier:
        groups = {}
        for h in hier:
            groups.setdefault(h["book_title"], []).append(h)
        lines = []
        for title, items in groups.items():
            lines.append(f"- 《{title}》")
            for it in items:
                ch = it["chapter"] or "（整体）"
                lines.append(f"    · {ch}：{it['content']}")
        parts.append("【层级记忆（书名 → 章节 → 内容）】\n" + "\n".join(lines))

    return "\n\n".join(parts)


init_db()
