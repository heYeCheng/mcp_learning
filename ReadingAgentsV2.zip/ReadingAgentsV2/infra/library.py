"""资料库：管理阅读/可视化的书目与材料（供小R/小V/小B 使用）。

books 表存储每本书的元信息、分段内容（sections）与全文/章节摘要。
sections 为 JSON 列表：[{"heading":..., "text":..., "summary":...}]
"""
import json
import sqlite3
import time
from typing import Optional

from infra import config

_DB = config.LIBRARY_DB

_INIT = """
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    source TEXT,
    file_hash TEXT,
    category TEXT,
    status TEXT DEFAULT 'reading',
    tags TEXT DEFAULT '[]',
    one_line TEXT DEFAULT '',
    sections TEXT DEFAULT '[]',
    summary TEXT DEFAULT '',
    key_points TEXT DEFAULT '[]',
    created_at REAL NOT NULL
);
"""


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(_DB)
    conn.row_factory = sqlite3.Row
    return conn


def init() -> None:
    with _conn() as conn:
        conn.executescript(_INIT)


def add_book(
    title: str,
    source: str = "",
    category: str = "",
    status: str = "reading",
    sections: Optional[list] = None,
    summary: str = "",
    tags: Optional[list] = None,
    one_line: str = "",
    file_hash: str = "",
    key_points: Optional[list] = None,
) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO books(title, source, file_hash, category, status, tags, one_line, sections, summary, key_points, created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (
                title,
                source,
                file_hash,
                category,
                status,
                json.dumps(tags or [], ensure_ascii=False),
                one_line,
                json.dumps(sections or [], ensure_ascii=False),
                summary,
                json.dumps(key_points or [], ensure_ascii=False),
                time.time(),
            ),
        )
        return cur.lastrowid


def list_books(status: Optional[str] = None) -> list:
    with _conn() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM books WHERE status=? ORDER BY id DESC", (status,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM books ORDER BY id DESC").fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d["tags"] = json.loads(d.get("tags") or "[]")
        d["sections"] = json.loads(d.get("sections") or "[]")
        d["key_points"] = json.loads(d.get("key_points") or "[]")
        result.append(d)
    return result


def get_book(book_id: int) -> Optional[dict]:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["tags"] = json.loads(d.get("tags") or "[]")
    d["sections"] = json.loads(d.get("sections") or "[]")
    d["key_points"] = json.loads(d.get("key_points") or "[]")
    return d


def update_book(book_id: int, **fields) -> None:
    allowed = {"title", "source", "file_hash", "category", "status", "tags",
               "one_line", "sections", "summary", "key_points"}
    sets, vals = [], []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k in ("tags", "sections", "key_points"):
            v = json.dumps(v or [], ensure_ascii=False)
        sets.append(f"{k}=?")
        vals.append(v)
    if not sets:
        return
    vals.append(book_id)
    with _conn() as conn:
        conn.execute(f"UPDATE books SET {', '.join(sets)} WHERE id=?", vals)


def delete_book(book_id: int) -> None:
    with _conn() as conn:
        conn.execute("DELETE FROM books WHERE id=?", (book_id,))


init()
