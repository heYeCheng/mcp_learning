"""基础设施层（最底层）：与 Agent 业务无关的通用机制。

- config / llm：配置与 LLM 客户端
- memory / library：SQLite 存储
- file_reader：文档解析（txt/md/docx/PDF）
- skill_loader：SKILL.md 扫描解析

依赖规则：本层不得 import core / services / ui（不得向上依赖）。
"""
