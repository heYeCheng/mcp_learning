"""技能提示词组装。

加载机制在 infra/skill_loader.py（扫描/解析/缓存）；本模块只做两件事：
把技能注册表里的数据按 Agent 需求组装成注入 instructions 的文本块，
以及 read_skill 工具的领域入口。
"""
from infra import skill_loader


def build_agent_skill_prompt(agent_id: str) -> str:
    """构建某 Agent 的技能注入块（主技能 + 依赖技能正文）。无技能时返回空串。"""
    main = skill_loader.registry().get(agent_id)
    if not main:
        return ""
    parts = [
        "## 你的专业技能（请严格遵循以下技能指令完成工作，不要另起炉灶）",
        f"### 主技能：{main.name}",
        main.prompt,
    ]
    for dep in main.dependencies:
        d = skill_loader.registry().get(dep)
        if d and d.name != main.name:
            parts.append(f"### 参考技能：{d.name}")
            parts.append(d.prompt)
    return "\n\n".join(parts)


def read_skill(rel_path: str) -> str:
    """读取技能文档（read_skill 工具的领域入口）。"""
    return skill_loader.read_skill_file(rel_path)


def skill_index() -> str:
    """列出全部可用技能（供 read_skill 工具提示）。"""
    lines = []
    for s in sorted(skill_loader.registry().values(), key=lambda x: x.name):
        deps = f"（依赖: {', '.join(s.dependencies)}）" if s.dependencies else ""
        lines.append(f"- {s.name}/SKILL.md：{s.description[:50]}{deps}")
    return "\n".join(lines)
