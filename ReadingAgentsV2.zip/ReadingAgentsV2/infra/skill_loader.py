"""技能加载机制（Skill Loader）——与具体 Agent 业务无关的底层能力。

职责：扫描 skills/ 目录、解析 SKILL.md（YAML frontmatter + Markdown 正文）、
构建注册表、提供安全的文件读取（read_skill）。与 file_reader（解析 PDF/docx）
同性质：都是"文件 → 结构化数据"的机制层。

上层（core/skills.py）负责把这些数据组装进 Agent 提示词。
"""
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

from infra import config

SKILLS_ROOT = config.PROJECT_ROOT / "skills"
SHARED_SKILLS_ROOT = SKILLS_ROOT / "shared"


@dataclass
class Skill:
    """一个技能的定义。"""
    name: str                          # 技能唯一标识（Agent 技能名 = agent_id）
    description: str                   # 触发描述
    prompt: str                        # 技能正文（SKILL.md 的 Markdown）
    file_path: str                     # SKILL.md 绝对路径
    dependencies: list = field(default_factory=list)  # 依赖的其他技能名


class SkillLoader:
    """扫描技能目录，解析所有 SKILL.md，构建注册表。"""

    def __init__(self, roots: list):
        self.roots = [Path(r) for r in roots]
        self._registry: dict[str, Skill] = {}

    def load_all(self) -> dict[str, Skill]:
        self._registry.clear()
        for root in self.roots:
            if not root.is_dir():
                continue
            for skill_file in root.rglob("SKILL.md"):
                skill = self._parse(skill_file)
                if skill and skill.name not in self._registry:
                    self._registry[skill.name] = skill
        # 依赖只保留注册表中确实存在的技能
        for skill in self._registry.values():
            skill.dependencies = [d for d in skill.dependencies if d in self._registry]
        return self._registry

    def get(self, name: str) -> Optional[Skill]:
        return self._registry.get(name)

    def list_skills(self) -> list:
        return list(self._registry.values())

    def _parse(self, path: Path) -> Optional[Skill]:
        try:
            content = path.read_text(encoding="utf-8")
        except Exception:
            return None
        m = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, re.DOTALL)
        if not m:
            return None
        try:
            meta = yaml.safe_load(m.group(1)) or {}
        except yaml.YAMLError:
            return None
        name = str(meta.get("name") or "").strip()
        if not name:
            return None
        return Skill(
            name=name,
            description=str(meta.get("description") or "").strip(),
            prompt=m.group(2).strip(),
            file_path=str(path),
            dependencies=[str(d).strip() for d in (meta.get("dependencies") or []) if str(d).strip()],
        )


# ---- 模块级注册表缓存 ----

_REGISTRY: dict[str, Skill] = {}
_LOADED = False


def registry() -> dict[str, Skill]:
    """获取技能注册表（首次调用时扫描目录，之后走缓存）。"""
    global _REGISTRY, _LOADED
    if not _LOADED:
        _REGISTRY = SkillLoader([SKILLS_ROOT, SHARED_SKILLS_ROOT]).load_all()
        _LOADED = True
    return _REGISTRY


def invalidate() -> None:
    """重新扫描技能目录（改完 SKILL.md 后调用，或重启服务）。"""
    global _LOADED
    _LOADED = False


def read_skill_file(rel_path: str, max_chars: int = 14000) -> str:
    """读取技能目录下的文档（SKILL.md / 参考文件），供 read_skill 工具使用。

    只允许读取 skills/ 目录内的文件，防止越权。
    """
    rel = (rel_path or "").strip().replace("\\", "/").lstrip("/")
    if not rel:
        return "错误：缺少 path（如 xiaov/SKILL.md）。"
    root = SKILLS_ROOT.resolve()
    target = (root / rel).resolve()
    if not str(target).startswith(str(root)) or not target.is_file():
        return f"[读取失败] 只允许读取 skills 目录下的文件：{rel}"
    try:
        text = target.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        return f"[读取失败] {exc}"
    if len(text) > max_chars:
        text = text[:max_chars] + "\n…（内容过长已截断，如需其他部分请说明）"
    return text
