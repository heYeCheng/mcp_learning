"""Agent 信息服务：界面获取 Agent 展示信息的唯一入口。

界面只依赖 services 层：展示信息来自 services.agents.META，
接口配置来自 infra.config，技能预览来自 infra.skills。
"""
from infra import config, skills
from services.agents import get_meta


def get_profile(agent_id: str) -> dict:
    """Agent 展示信息 + 接口配置状态（侧边栏用）。"""
    profile = dict(get_meta(agent_id))
    profile["api_ready"] = bool(config.API_KEY)
    profile["base_url"] = config.BASE_URL
    profile["model"] = config.MODEL
    return profile


def get_skill_prompt(agent_id: str) -> str:
    """该 Agent 已注入的技能正文（预览用）。"""
    return skills.build_agent_skill_prompt(agent_id)


def get_skill_index() -> str:
    return skills.skill_index()
