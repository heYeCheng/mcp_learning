"""可视化项目服务：一次可视化 = 一个多页站点文件夹。

设计原则（分页生成，告别截断）：
- 每页由模型通过 save_viz_page 单独提交，页小而完整，不再有整页大 I/O。
- 目录页 index.html 由本服务确定式生成，不依赖模型输出。
- 不做截断修复：页面校验不过就返回错误，模型修正后重交同一文件名即可覆盖。

项目结构：data/viz/<project_id>/ 下 index.html + 内容页 + manifest.json（元数据与页清单）。
"""
import html as html_mod
import json
import re
import time
from pathlib import Path

from infra import config

MAX_PAGE_CHARS = 24000          # 单页防御性上限
_MIN_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,80}$")
_PAGE_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,60}(\.html)?$")


# ---------------------------------------------------------------------------
# 项目目录与 manifest
# ---------------------------------------------------------------------------

def _project_dir(project_id: str) -> Path:
    pid = str(project_id or "").strip().lower()
    if not _MIN_ID_RE.match(pid):
        raise ValueError(f"非法项目 id：{project_id!r}")
    return config.VIZ_DIR / pid


def _manifest_path(d: Path) -> Path:
    return d / "manifest.json"


def _read_manifest(d: Path) -> dict:
    try:
        return json.loads(_manifest_path(d).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_manifest(d: Path, mf: dict) -> None:
    _manifest_path(d).write_text(json.dumps(mf, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# 三个阶段：开项目 → 逐页保存 → 收尾生成目录页
# ---------------------------------------------------------------------------

def start_project(title: str, style: str = "", book_id=None) -> dict:
    """新建可视化项目文件夹，返回 project_id 等信息。"""
    title = (title or "可视化").strip()[:80]
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")[:40] or "viz"
    project_id = f"{time.strftime('%Y%m%d_%H%M%S')}_{slug}"
    d = _project_dir(project_id)
    d.mkdir(parents=True, exist_ok=True)
    mf = {
        "title": title,
        "style": (style or "").strip(),
        "book_id": book_id,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "pages": [],  # [{filename, title}]，按保存顺序
    }
    _write_manifest(d, mf)
    return {"project_id": project_id, "title": title, "dir": str(d), "pages": []}


def save_page(project_id: str, filename: str, title: str, page_html: str) -> dict:
    """保存一页内容页（同 filename 重复提交 = 覆盖修正），返回项目当前页清单。"""
    d = _project_dir(project_id)
    if not d.is_dir():
        return {"error": f"项目 {project_id} 不存在。请先调用 start_viz_project。"}

    fname = str(filename or "").strip().lower().replace("\\", "/").split("/")[-1]
    if not _PAGE_RE.match(fname):
        return {"error": f"文件名不合法：{filename!r}。用 ch01.html 这类小写字母/数字/连字符。"}
    if not fname.endswith(".html"):
        fname += ".html"

    page_html = (page_html or "").strip()
    low = page_html.lower()
    if len(page_html) < 200:
        return {"error": f"页面过短（{len(page_html)} 字符），请提交完整页面。"}
    if "<!doctype html" not in low[:200] and "<html" not in low[:2000]:
        return {"error": "页面应以 <!DOCTYPE html> 或 <html> 开头。请重新提交完整页面。"}
    if "</html>" not in low[-500:]:
        return {"error": "页面未闭合（缺少 </html>），请补全后重新提交。"}
    if len(page_html) > MAX_PAGE_CHARS:
        return {"error": f"单页超过 {MAX_PAGE_CHARS} 字符，请把这一页拆成两页分别提交。"}

    (d / fname).write_text(page_html, encoding="utf-8")

    mf = _read_manifest(d)
    pages = mf.get("pages", [])
    entry = {"filename": fname, "title": (title or fname).strip()[:80]}
    pages = [p for p in pages if p["filename"] != fname] + [entry]
    mf["pages"] = pages
    _write_manifest(d, mf)
    return {
        "saved": fname,
        "page_count": len(pages),
        "pages": [f"{p['filename']}（{p['title']}）" for p in pages],
        "hint": f"已保存 {fname}。继续下一页，全部完成后调用 finish_viz_project。",
    }


def finish_project(project_id: str) -> dict:
    """生成目录页 index.html（服务端确定式生成），返回可打开路径。"""
    d = _project_dir(project_id)
    if not d.is_dir():
        return {"error": f"项目 {project_id} 不存在。"}
    mf = _read_manifest(d)
    pages = mf.get("pages", [])
    if not pages:
        return {"error": "项目还没有任何内容页，请先 save_viz_page 至少一页。"}

    e = html_mod.escape
    title = mf.get("title", "可视化")
    style = mf.get("style", "")
    cards = "\n".join(
        f'<a class="card" href="./{e(p["filename"])}"><span class="no">{i + 1:02d}</span>'
        f'<span class="t">{e(p["title"])}</span></a>'
        for i, p in enumerate(pages)
    )
    index = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{e(title)} · 目录</title>
<style>
:root{{--bg:#f4f7fb;--ink:#16243a;--muted:#687e9c;--line:#dde7f2;--accent:#2f6fed}}
body{{font-family:"PingFang SC","Microsoft YaHei",system-ui,sans-serif;background:var(--bg);color:var(--ink);margin:0;line-height:1.7}}
.hero{{background:linear-gradient(135deg,var(--accent),#7c5cf0);color:#fff;padding:44px 24px}}
.hero h1{{margin:0 0 6px;font-size:28px}}.hero p{{margin:2px 0;opacity:.88;font-size:14px}}
main{{max-width:760px;margin:0 auto;padding:24px}}
.grid{{display:grid;grid-template-columns:1fr;gap:12px}}
.card{{display:flex;gap:14px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:12px;padding:16px 18px;text-decoration:none;color:var(--ink)}}
.card:hover{{border-color:var(--accent);box-shadow:0 2px 10px rgba(47,111,237,.12)}}
.no{{font-size:20px;font-weight:700;color:var(--accent)}}
@media(min-width:640px){{.grid{{grid-template-columns:1fr 1fr}}}}
</style></head><body>
<div class="hero"><h1>{e(title)}</h1>
<p>{e(style) if style else "多页可视化站点"}</p><p>共 {len(pages)} 页 · 生成于 {e(mf.get("created", ""))}</p></div>
<main><div class="grid">
{cards}
</div></main>
</body></html>"""
    (d / "index.html").write_text(index, encoding="utf-8")
    return {
        "done": True,
        "project_id": project_id,
        "path": str(d / "index.html"),
        "page_count": len(pages),
        "hint": "站点已完成：请把上面的站点路径告诉用户，用浏览器打开 index.html 即可浏览全部页面。",
    }


def list_projects() -> list:
    """列出全部可视化项目（供界面/调试用）。"""
    if not config.VIZ_DIR.is_dir():
        return []
    out = []
    for d in sorted(config.VIZ_DIR.iterdir()):
        if d.is_dir() and _MIN_ID_RE.match(d.name):
            mf = _read_manifest(d)
            out.append({
                "project_id": d.name,
                "title": mf.get("title", d.name),
                "style": mf.get("style", ""),
                "pages": len(mf.get("pages", [])),
                "has_index": (d / "index.html").exists(),
            })
    return out


def active_project() -> dict | None:
    """返回最新一个尚未收尾（无 index.html）的项目状态，供对话接力。

    对话历史只存 user/assistant 文本，project_id 与页清单会丢失；
    本函数让「继续」时能拿回断点状态，避免模型重新开项目从头再来。
    """
    if not config.VIZ_DIR.is_dir():
        return None
    dirs = [d for d in sorted(config.VIZ_DIR.iterdir())
            if d.is_dir() and _MIN_ID_RE.match(d.name) and not (d / "index.html").exists()]
    if not dirs:
        return None
    d = dirs[-1]
    mf = _read_manifest(d)
    pages = mf.get("pages", [])
    return {
        "project_id": d.name,
        "title": mf.get("title", d.name),
        "style": mf.get("style", ""),
        "page_count": len(pages),
        "pages": [f"{p['filename']}（{p['title']}）" for p in pages],
    }
