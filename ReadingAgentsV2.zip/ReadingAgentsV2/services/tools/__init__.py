"""Agent 工具层：工具按归属拆子模块，import 即生效。

- base：公共契约（RunDeps 运行上下文 / AskUserInterrupt 中断异常 / truncate）
- library：书目浏览（小R / 小V / 小B 共用）
- reading：阅读（小R）
- viz：可视化（小V / 阿画）
- knowledge：巩固与记忆（小B / 小V）
- external：external_tools/*.py 自动扫描扩展点（EXTERNAL_TOOLS）

工具是把 services 业务动作暴露给模型的适配层：docstring 给模型看，
参数类型注解自动生成 schema。各 agent 文件（services/agents/*）直接引用
这里的工具对象组装自己的 Agent。
"""
from .base import AskUserInterrupt, MAX_TOOL_RESULT_CHARS, RunDeps, truncate  # noqa: F401
from . import external, knowledge, library, reading, viz  # noqa: F401
