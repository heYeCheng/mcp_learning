"""知识巩固与记忆工具（小B / 小V）。"""
from agents import RunContextWrapper, function_tool

from infra import memory, skills
from services.tools.base import RunDeps

MASTERY_LEVELS = ("weak", "familiar", "mastered")
MASTERY_LABELS = {"weak": "薄弱", "familiar": "一般", "mastered": "已掌握"}


@function_tool
def update_mastery(ctx: RunContextWrapper[RunDeps], topic: str, level: str,
                   note: str = "", book_title: str = "") -> str:
    """更新用户对某个知识点的掌握度档案。每当你对用户一组回答做出判定后调用；同一知识点重复调用会覆盖更新。

    Args:
        topic: 知识点/概念名称（简短、可复用，如「锚定效应」）。
        level: 掌握程度三档：weak（薄弱）/ familiar（一般）/ mastered（已掌握）。
        note: 一句话判定依据或薄弱点描述（可选）。
        book_title: 关联的书名（可选）。
    """
    level = (level or "").strip().lower()
    if level not in MASTERY_LEVELS:
        return "❌ level 必须是 weak / familiar / mastered 之一。"
    row = memory.upsert_mastery(ctx.context.agent_id, topic, level, note, book_title)
    label = MASTERY_LABELS[level]
    prev = f"（原为：{MASTERY_LABELS.get(row['level'], row['level'])}）" if row.get("prev_level") else ""
    return f"✅ 掌握度已更新：「{row['topic']}」→ {label}{prev}"


@function_tool
def remember_structure(ctx: RunContextWrapper[RunDeps], book_title: str,
                       content: str, chapter: str = "") -> str:
    """沉淀一条层级记忆：把一本书/资料的「书名/标题 → 章节 → 具体内容」记下来，以后可复用。当你把一本书/资料可视化或通读后调用，形成长期可查的结构化记忆。

    Args:
        book_title: 书名或标题。
        content: 该章节/整体的核心内容、要点或结构描述。
        chapter: 章节名（可选；不填表示整本书整体结构）。
    """
    mid = memory.add_hier(ctx.context.agent_id, book_title, chapter, content)
    if mid:
        return f"✅ 已沉淀层级记忆：{book_title} → {chapter or '整体'}"
    return "沉淀失败：缺少书名或内容。"


@function_tool
def read_skill(ctx: RunContextWrapper[RunDeps], path: str) -> str:
    """读取 skills 目录下的技能文档（SKILL.md）与参考文件，供你查阅设计规范/技能细节。path 用相对路径，如 xiaov/SKILL.md、shared/reading-visualizer/SKILL.md。一次读一个文件。

    Args:
        path: skills 目录下的相对路径。
    """
    return skills.read_skill(path)
