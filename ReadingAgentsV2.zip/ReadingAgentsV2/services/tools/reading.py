"""阅读工具（小R 专属）：解析 / 按块压缩 / 按章聚合 / 深入 / 全书总结。"""
from agents import RunContextWrapper, function_tool

from services import reading_service
from services.tools.base import RunDeps


@function_tool
def read_file(ctx: RunContextWrapper[RunDeps], path: str, title: str = "") -> str:
    """读取用户指定的文件（支持 txt / md / Word docx / 文字类 pdf），按物理页切分并存入资料库。返回书目概览和块列表，每个块带真实页码区间，可按「第X块/第X-Y页」定位阅读。

    Args:
        path: 文件的完整路径。
        title: 可选，给这份材料起的书名/标题。
    """
    info = reading_service.parse_book(path, title)
    listing = "\n".join(f"[{s['index']}] {s['heading']}" for s in info["sections"][:40])
    more = f"\n…共 {info['section_count']} 块" if info["section_count"] > 40 else ""
    return (
        f"已解析《{info['title']}》（id={info['book_id']}），共 {info['section_count']} 个阅读块"
        f"（按物理页切块，每块带真实页码区间，可对照实体书定位），已存入资料库，尚未做内容压缩。\n"
        f"阅读块列表：\n{listing}{more}\n\n"
        f"建议按块阅读：请告诉我「读第 X 块/节」，我逐块为你做内容压缩；"
        f"也可以说「从头读完/总结全书」。"
    )


@function_tool
def skim_chapter(ctx: RunContextWrapper[RunDeps], book_id: int, index: int) -> str:
    """为某本书的指定阅读块（heading 带页码区间）生成一段可读的中文压缩内容并入库。用于按块逐段阅读。

    Args:
        book_id: 书目 id（用 read_file 或 list_books 获取）。
        index: 阅读块序号（0 起）。
    """
    r = reading_service.skim_section(book_id, index)
    return (
        f"✅ 已完成第 {r['index']} 块「{r['heading']}」的内容压缩：\n{r['summary']}\n"
        f"（下一步可选：读第 {r['index'] + 1} 块 / 对这块说「深入讲讲某点」/"
        f"读完总结全书。）"
    )


@function_tool
def deep_dive(ctx: RunContextWrapper[RunDeps], book_id: int, index: int, focus: str = "") -> str:
    """获取某本书指定阅读块的完整原文（非摘要），用于对用户想深入了解的位置做深入讲解。用户说「这里展开讲讲/这个概念详细说说」时调用。

    Args:
        book_id: 书目 id（用 read_file 或 list_books 获取）。
        index: 阅读块序号（0 起）。
        focus: 可选，用户想深入的方向或问题，如「第2点的工作机制」。
    """
    try:
        r = reading_service.deep_dive(book_id, index)
    except ValueError as exc:
        return f"错误：{exc}"
    text = r["text"]
    truncated = ""
    if len(text) > 15000:
        text = text[:15000]
        truncated = "\n…（原文过长已截断；如需更靠后的内容请告诉用户分次深入）"
    head = f"用户想深入了解：{focus}\n" if focus else ""
    return (
        f"{head}以下为《{r['title']}》第 {r['index']} 块「{r['heading']}」的完整原文，"
        f"请基于原文（而非摘要）做深入讲解：\n\n{text}{truncated}"
    )


@function_tool
def read_chapter(ctx: RunContextWrapper[RunDeps], book_id: int,
                 chapter: int = 0, query: str = "") -> str:
    """按章聚合某本书某一章的全部阅读块原文，供整章阅读讲解。用户说「读第 X 章 / 讲讲某章」时调用；章序号（1 起，见 get_book 的章目录）与标题关键词二选一。

    Args:
        book_id: 书目 id（用 read_file 或 list_books 获取）。
        chapter: 章序号（1 起）。与 query 二选一。
        query: 章标题模糊匹配关键词，如「三体」；与 chapter 二选一。
    """
    try:
        r = reading_service.read_chapter(book_id, chapter=chapter, query=query.strip())
    except ValueError as exc:
        return f"错误：{exc}"
    return (
        f"以下为《{r['title']}》第 {r['chapter_index']} 章「{r['chapter_title']}」全文"
        f"（{r['chars']} 字，由 {r['blocks']} 个阅读块聚合），请基于原文为用户讲解本章内容，"
        f"结尾给出下一步选项（如：读下一章 / 深入讲讲本章某点）。{r['truncated_note']}\n\n{r['text']}"
    )


@function_tool
def skim_book(ctx: RunContextWrapper[RunDeps], book_id: int) -> str:
    """对某本书的剩余/全部阅读块做全书内容压缩（会逐批处理并生成全文总结）。当用户要求读完/总结全书时调用，且只调用一次。

    Args:
        book_id: 书目 id（用 read_file 或 list_books 获取）。
    """
    r = reading_service.read_and_skim_by_id(book_id)
    return (
        f"✅ 已完成全书内容压缩（共 {r['section_count']} 块）。\n"
        f"全文总结：{r['overall']}\n"
        f"核心要点：{'；'.join(r['key_points'])}\n"
        f"（接下来可以请小B 巩固、或请小V 可视化这本书。）"
    )
