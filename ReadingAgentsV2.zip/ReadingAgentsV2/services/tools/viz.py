"""可视化工具（小V / 阿画）：风格闸门 + 项目制多页站点。"""
from typing import Optional

from agents import RunContextWrapper, function_tool

from services import style_gate, viz_service
from services.tools.base import AskUserInterrupt, RunDeps


@function_tool(failure_error_function=None)  # AskUserInterrupt 必须向上传播，不能被转成错误字符串
def ask_user_style(ctx: RunContextWrapper[RunDeps], color_options: str,
                   layout_options: str, template_suggestion: str = "", note: str = "") -> str:
    """向用户发出风格建议单并结束本轮（等待用户回复）。开任何可视化项目前必须先调用本工具；用户回复后系统才授权 start_viz_project。参数里写清你的推荐，调用后把同样的建议用正文复述给用户。

    Args:
        color_options: 推荐 2-3 个色卡，各附一句话理由（来自 read_skill('shared/reading-visualizer/color/INDEX.md')）。
        layout_options: 推荐 1-2 种布局形态（来自 read_skill('shared/reading-visualizer/display/INDEX.md')）。
        template_suggestion: 可选，是否推荐套用现成模板及理由。
        note: 可选，补充说明。
    """
    # 记录"已发建议单，等待用户回复"状态，然后中断本轮（异常由 runtime 捕获）
    style_gate.request_confirmation(ctx.context.agent_id)
    raise AskUserInterrupt()


@function_tool
def start_viz_project(ctx: RunContextWrapper[RunDeps], title: str, confirmed: bool,
                      style: str = "", book_id: Optional[int] = None) -> str:
    """创建一个可视化项目（多页站点文件夹）。前置条件（硬性，系统闸门）：必须先调用 ask_user_style 并得到用户回复，系统授权后本工具才会成功。开项目后规划页面清单，然后把逐页生成移交给绘图手（transfer_to_drawer）。整本书可视化时传入 book_id 关联书目。

    Args:
        title: 项目/站点标题。
        confirmed: 用户已在风格建议单后回复选定风格时传 true。注意：仅传 true 不够，系统还要求此前调用过 ask_user_style 且用户已回复。
        style: 用户已选定的风格描述，如「色卡名 + 布局名」。
        book_id: 可选，关联的书目 id。
    """
    # 风格闸门（状态机级，模型无法伪造）：只有用户在 ask_user_style 建议单之后
    # 回复过，系统才会置 authorized。confirmed 参数只是次要校验。
    if not style_gate.is_authorized(ctx.context.agent_id):
        return ("❌ 系统未授权开项目：用户尚未确认风格。请立即调用 ask_user_style 工具"
                "（把色系 2-3 个推荐、布局 1-2 个推荐写进参数），它会替你结束本轮等待用户回复；"
                "用户回复后重新调用本工具才会成功。不要试图绕过。")
    if not confirmed:
        return "❌ 缺少 confirmed=true。确认风格已选定后携带 confirmed=true 重新调用。"
    r = viz_service.start_project(title or "可视化", style, book_id)
    style_gate.reset(ctx.context.agent_id)  # 授权已消费，下次开新项目必须重新问
    return (
        f"✅ 项目已创建：{r['project_id']}（目录 {r['dir']}，风格 {style or '未填'}）\n"
        f"接下来：规划页面清单（每页标题与要点），然后用 transfer_to_drawer 把逐页生成"
        f"移交给绘图手阿画。"
    )


@function_tool
def save_viz_page(ctx: RunContextWrapper[RunDeps], project_id: str, filename: str,
                  title: str, html: str) -> str:
    """向可视化项目保存一页内容页。一次调用只做一页，页面小而完整：<!DOCTYPE html> 开头、</html> 闭合、内联 CSS、不引用外部资源；页内加 <a href="./index.html">返回目录</a>。校验失败会返回错误，修正后用同一 filename 重新提交即可覆盖。单页内容过多时拆成两页。

    Args:
        project_id: 项目 id（start_viz_project 返回）。
        filename: 页文件名，如 ch01.html、ch02.html。
        title: 本页标题（显示在目录页）。
        html: 本页完整 HTML 文档全文。
    """
    r = viz_service.save_page(project_id, filename, title, html)
    if r.get("error"):
        return f"❌ 保存失败：{r['error']}"
    pages = "\n".join(f"  - {p}" for p in r["pages"])
    return f"✅ {r['hint']}\n当前页清单（{r['page_count']} 页）：\n{pages}"


@function_tool
def finish_viz_project(ctx: RunContextWrapper[RunDeps], project_id: str) -> str:
    """完成可视化项目：系统自动生成目录页 index.html，把全部内容页按保存顺序串联成可浏览的多页站点。全部页面保存完后调用。

    Args:
        project_id: 项目 id。
    """
    r = viz_service.finish_project(project_id)
    if r.get("error"):
        return f"❌ 收尾失败：{r['error']}"
    return (
        f"🎉 {r['hint']}\n"
        f"站点路径：{r['path']}（共 {r['page_count']} 页内容）\n"
        f"请立即把上面的站点路径告诉用户，例如：《站点已完成，文件在 {r['path']}，用浏览器打开即可浏览。》\n"
        f"提示：也可到界面「🎨 作品」页随时打开全部历史作品。"
    )
