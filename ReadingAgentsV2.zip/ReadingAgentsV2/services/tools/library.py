"""书目浏览工具（小R / 小V / 小B 共用）。"""
from typing import Optional

from agents import RunContextWrapper, function_tool

from infra import library
from services.reading_service import chapter_list
from services.tools.base import RunDeps


@function_tool
def list_books(ctx: RunContextWrapper[RunDeps], status: Optional[str] = None) -> str:
    """列出资料库中的所有书目（含状态、分类、一句话总结）。

    Args:
        status: 可选，按阅读状态过滤（reading=在读 / done=已完成）。
    """
    books = library.list_books(status)
    if not books:
        return "资料库暂无书目。"
    lines = []
    for b in books:
        state = {"reading": "在读", "done": "已完成"}.get(b.get("status"), b.get("status"))
        lines.append(
            f"- id={b['id']} 《{b['title']}》[{state}] 分类:{b.get('category') or '无'} "
            f"标签:{'、'.join(b.get('tags') or []) or '无'}｜{b.get('one_line') or b.get('summary') or ''}"
        )
    return "\n".join(lines)


@function_tool
def get_book(ctx: RunContextWrapper[RunDeps], book_id: int) -> str:
    """获取某本书的详细内容（各节标题、摘要、正文节选）。"""
    book = library.get_book(book_id)
    if not book:
        return f"未找到 id={book_id} 的书。"
    secs = book.get("sections") or []
    sec = []
    for s in secs:
        heading = s.get("heading") or "节"
        summ = s.get("summary") or ""
        text = (s.get("text") or "").replace("\n", " ")[:200]
        sec.append(f"- 【{heading}】摘要：{summ}\n    正文节选：{text}…")
    chapters = chapter_list(secs)
    ch_dir = ""
    if len(chapters) > 1 or (chapters and chapters[0]["title"] != "(未分章)"):
        ch_dir = ("章目录：" + "；".join(
            f"{c['index']}.{c['title']}" for c in chapters[:30]
        ) + "\n")
    return (
        f"《{book['title']}》（id={book['id']}，状态：{book.get('status')}）\n"
        f"分类：{book.get('category') or '无'}；标签：{'、'.join(book.get('tags') or []) or '无'}\n"
        f"总结：{book.get('summary')}\n"
        + ch_dir +
        f"各节（摘要+正文节选）：\n" + "\n".join(sec)
    )
