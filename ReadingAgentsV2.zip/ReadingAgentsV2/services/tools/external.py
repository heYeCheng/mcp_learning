"""外部工具扩展点：扫描 external_tools/*.py，把「SCHEMA + handle」包装成 FunctionTool。

新增外部工具无需改任何代码：在 external_tools/ 放一个含 SCHEMA、handle 的 py 文件，
启动时自动出现在 EXTERNAL_TOOLS 列表里；agent 文件按需把它加进自己的 tools。
"""
import importlib.util
import json
import logging
import sys

from agents import FunctionTool

from infra import config
from services.tools.base import truncate

logger = logging.getLogger(__name__)

EXTERNAL_TOOLS: list = []


def _wrap(schema: dict, handle) -> FunctionTool:
    """把外部模块的 SCHEMA + handle(args) 包装成 FunctionTool。"""
    fn = schema.get("function") or {}
    name = fn.get("name") or ""
    params = fn.get("parameters") or {"type": "object", "properties": {}}

    async def _invoke(_tool_ctx, input_json: str) -> str:
        try:
            args = json.loads(input_json or "{}")
        except json.JSONDecodeError:
            args = {}
        try:
            return truncate(handle(args or {}))
        except Exception as exc:  # 外部工具故障转成文本，不中断对话
            return f"[工具 {name} 执行失败] {exc}"

    return FunctionTool(
        name=name,
        description=fn.get("description") or "",
        params_json_schema=params,
        on_invoke_tool=_invoke,
        strict_json_schema=False,  # 外部 schema 不保证符合 strict 模式
    )


def _load() -> None:
    ext_root = config.PROJECT_ROOT / "external_tools"
    if not ext_root.is_dir():
        return
    for py in sorted(ext_root.glob("*.py")):
        if py.name.startswith("_"):
            continue
        mod_name = f"external_tools_{py.stem}"
        try:
            spec = importlib.util.spec_from_file_location(mod_name, py)
            mod = importlib.util.module_from_spec(spec)
            sys.modules[mod_name] = mod
            spec.loader.exec_module(mod)
        except Exception as exc:
            logger.warning("外部工具模块 %s 加载失败: %s", py.name, exc)
            continue
        schema = getattr(mod, "SCHEMA", None)
        handle = getattr(mod, "handle", None)
        if not schema or not callable(handle):
            continue
        for it in (schema if isinstance(schema, list) else [schema]):
            EXTERNAL_TOOLS.append(_wrap(it, handle))


_load()
