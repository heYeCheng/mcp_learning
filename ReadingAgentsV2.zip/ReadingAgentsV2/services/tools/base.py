"""工具层公共契约：运行上下文、中断异常、统一截断。

独立成模块的原因：工具子模块与包 __init__ 互相 import 会成环，
所有子模块只依赖本文件，__init__ 再转发，单向无环。
"""
from dataclasses import dataclass

# 单个工具结果最大字符数（控制上下文长度）
MAX_TOOL_RESULT_CHARS = 6000


@dataclass
class RunDeps:
    """一次对话运行中传给所有工具的上下文（Runner 的 context 参数）。"""

    agent_id: str


class AskUserInterrupt(Exception):
    """ask_user_style 触发：结束本轮，把控制权交还用户。

    工具抛出本异常（failure_error_function=None 使其向上传播），
    agents/runtime 捕获后不再继续 Run。
    """


def truncate(text) -> str:
    """统一截断工具结果，避免单个工具撑爆上下文。"""
    text = str(text)
    if len(text) <= MAX_TOOL_RESULT_CHARS:
        return text
    return text[:MAX_TOOL_RESULT_CHARS] + "\n…（结果过长已截断）"
