"""风格确认闸门（机制级强制小V先问风格）。

为什么需要：靠提示词"必须问风格"约束不住模型，confirmed 布尔值也是模型
自己填的、可以谎报。真正的强制只能由系统状态机完成：

- pending：小V 已调用 ask_user_style 发出风格建议单，本轮结束，等待用户回复；
- authorized：用户在建议单之后回复过（任意内容视为回应），此时才允许
  start_viz_project(confirmed=true) 成功；
- 项目成功创建后授权即被消费（reset），下次开新项目必须重新问。

状态按 agent_id 存于进程内存（单进程 Streamlit 应用足够）。

新版由 services/tools.py 的 ask_user_style 工具触发 request_confirmation，
并用 AskUserInterrupt 异常结束本轮（不再用 sentinel 字符串打断）。
"""

_pending: set = set()
_authorized: set = set()


def request_confirmation(agent_id: str) -> None:
    """ask_user_style 被调用：记录"已发建议单，等待用户回复"。"""
    if agent_id:
        _pending.add(agent_id)


def confirm_if_pending(agent_id: str) -> None:
    """用户发来了新消息：若此前发过建议单，则授权开项目。"""
    if agent_id and agent_id in _pending:
        _pending.discard(agent_id)
        _authorized.add(agent_id)


def is_authorized(agent_id: str) -> bool:
    return bool(agent_id) and agent_id in _authorized


def reset(agent_id: str) -> None:
    """项目创建成功（授权消费）或会话复位时调用。"""
    _authorized.discard(agent_id)
    _pending.discard(agent_id)
