"""记忆管理服务：界面与对话层对记忆系统的唯一入口。

包含两部分：
- 记忆 CRUD / 统计 / 待确认转正（界面层调用）
- 每轮对话结束后的 LLM 记忆提炼（chat_service 调用）
数据仍由 infra.memory 存储，本层负责业务规则（如转正、去重、统计）。
"""
import json
import logging

from infra import llm, memory
from services.agents import get_meta

logger = logging.getLogger(__name__)

# 常量转发（界面需要展示，但不应直接 import infra）
TYPES = memory.TYPES
TIERS = memory.TIERS
TIER_LABELS = memory.TIER_LABELS


def get_overview(agent_id: str) -> dict:
    """记忆概览（侧边栏用）：各层条数 + 待确认数 + 层级记忆数。"""
    all_mem = memory.list_memories(agent_id)
    counts = {t: 0 for t in TIERS}
    for m in all_mem:
        counts[m["tier"]] = counts.get(m["tier"], 0) + 1
    return {
        "tier_counts": counts,
        "pending": len(memory.get_pending(agent_id)),
        "hier": len(memory.get_hier(agent_id)),
    }


def clear_conversation(agent_id: str) -> None:
    """清空某 Agent 的对话历史。"""
    memory.clear_history(agent_id)


# ---- 三态记忆 CRUD ----

def list_by_tier(agent_id: str, tier: str) -> list:
    return memory.list_memories(agent_id, tier)


def delete(agent_id: str, mem_id: int) -> None:
    memory.delete_memory(agent_id, mem_id)


# ---- 待确认候选 ----

def get_pending(agent_id: str) -> list:
    return memory.get_pending(agent_id)


def approve_pending(ids: list) -> int:
    """批量确认候选 → 转长期记忆。"""
    return memory.approve_pending_batch(ids)


def reject_pending(ids: list) -> int:
    return memory.reject_pending(ids)


# ---- 手工强制记忆 ----

def force_long(agent_id: str, mtype: str, content: str):
    return memory.force_add_long(agent_id, mtype, content)


# ---- 层级记忆（小V）----

def list_hier(agent_id: str) -> list:
    return memory.get_hier(agent_id)


def add_hier(agent_id: str, book_title: str, chapter: str, content: str) -> bool:
    return memory.add_hier(agent_id, book_title, chapter, content)


def delete_hier(agent_id: str, item_id: int) -> None:
    memory.delete_hier(agent_id, item_id)


# ---- 掌握度档案（小B）----

MASTERY_LEVELS = ("weak", "familiar", "mastered")
MASTERY_LABELS = {"weak": "薄弱", "familiar": "一般", "mastered": "已掌握"}


def list_mastery(agent_id: str) -> list:
    return memory.get_mastery(agent_id)


def delete_mastery(agent_id: str, item_id: int) -> None:
    memory.delete_mastery(agent_id, item_id)


# ---- 记忆提炼（每轮对话结束后由 chat_service 调用）----

_EXTRACT_PROMPT = """你是记忆提炼助手。请阅读下面的对话，判断这位 Agent（{agent_name}，{agent_title}）从这次交流中值得记住哪些内容。

只提炼对这位 Agent 长期有用的信息，忽略寒暄和无关内容。类型：
- preference: 用户的偏好、风格、习惯、禁忌
- skill: 用户示范或确认的技术方法、技能、最佳实践
- knowledge: 该领域的事实、知识、概念
- fact: 具体的业务事实、数据、现状、决策
- project: 用户当前/进行中的项目背景、目标、约定

每条记忆给一个 importance：
- important: 用户明确强调、反复提到、或影响后续工作的关键信息（进入中期记忆 3 个月）
- normal:   一般性有用信息（进入短期记忆 3 天）

要求：
1. 每条记忆一句话，具体、可复用，不要泛泛而谈。
2. 如果这次对话没有值得记住的内容，返回空数组。
3. 严格返回如下 JSON，不要额外文字：
{{"memories": [{{"type": "preference", "content": "...", "importance": "normal"}}, ...]}}

<对话开始>
用户：{user_text}
{agent_name}：{assistant_text}
<对话结束>
"""


def _similar_exists(content: str, existing: list) -> bool:
    """字符二元组重叠度去重，避免重复提炼。"""
    def bigrams(s: str):
        return set(s[i: i + 2] for i in range(len(s) - 1))

    cb = bigrams((content or "").lower())
    if not cb:
        return True
    for e in existing:
        eb = bigrams((e or "").lower())
        if eb and len(cb & eb) / len(cb) >= 0.6:
            return True
    return False


def extract_memories(agent_id: str, user_text: str, assistant_text: str) -> dict:
    """从一轮对话提炼记忆，返回 {"added": 自动入短/中条数, "pending": 待确认条数}。

    importance=important → 自动写入中期记忆（3 个月）；normal → 短期（3 天）；
    所有候选同时进入待确认列表，用户批量确认后升级为长期记忆（永久）。
    """
    meta = get_meta(agent_id)
    try:
        raw = llm.chat_json([{
            "role": "user",
            "content": _EXTRACT_PROMPT.format(
                agent_name=meta["name"],
                agent_title=meta["title"],
                user_text=user_text,
                assistant_text=assistant_text,
            ),
        }])
        data = json.loads(raw)
    except Exception as exc:
        logger.warning("记忆提炼失败: %s", exc)
        return {"added": 0, "pending": 0}

    existing = [m["content"] for m in memory.list_memories(agent_id)]
    added = pending = 0
    for item in data.get("memories", []):
        mtype = item.get("type", "knowledge")
        content = (item.get("content") or "").strip()
        if not content or _similar_exists(content, existing):
            continue
        # 自动入短/中期（带时间戳与过期时间）
        importance = (item.get("importance") or "normal").lower()
        tier = "mid" if importance == "important" else "short"
        if memory.add_memory(agent_id, tier, mtype, content, source="chat"):
            existing.append(content)
            added += 1
        # 同时进入待确认列表，供用户确认后升级为长期记忆
        if memory.add_pending(agent_id, mtype, content, source="chat"):
            pending += 1

    # 顺手清理过期记忆
    try:
        memory.clean_expired(agent_id)
    except Exception:
        pass
    return {"added": added, "pending": pending}
