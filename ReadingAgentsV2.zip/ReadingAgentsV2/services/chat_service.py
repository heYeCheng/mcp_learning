"""对话产品编排：一轮对话的业务行为（历史 / 风格闸门 / 兜底话术 / 记忆提炼）。

分工——
- services/agents/*：agent 怎么定义（人设、工具、动态 instructions）
- services/agents/runtime.py：怎么跑（Runner 流式 + 事件桥接，纯机制）
- 本文件：怎么算"一轮对话"——存历史 → 授权确认 → 运行（空响应自愈重试）
  → 兜底文案 → 存回复 → 记忆提炼
"""
import asyncio
import logging

from infra import memory
from services import memory_service, style_gate
from services.agents import build, get_meta, runtime
from services.tools.base import RunDeps

logger = logging.getLogger(__name__)

_HISTORY_LIMIT = 30          # 每轮携带的历史消息条数
_EMPTY_RETRY_NOTE = (
    "⚠️ 你的上一条回复是空的（可能思考耗尽了输出额度）。"
    "请跳过长篇思考，直接调用合适的工具推进任务，或用简短文字回复用户。"
)
_ASK_USER_NOTE = (
    "请从风格建议单中选定：回复「色系 + 布局」（如「海洋深蓝 + 时间线布局」），"
    "或说「你定」让我来定。"
)


def _final_text(outcome: runtime.RunOutcome) -> str:
    """兜底文案：把「建议单已发出 / 轮次用尽 / 空响应」转成用户可操作的提示。"""
    if outcome.answer:
        return outcome.answer
    if outcome.asked:
        return _ASK_USER_NOTE
    if outcome.exhausted or outcome.events:
        # 轮次用尽，或模型静默但工具已执行了实际工作 → 汇报进度，引导「继续」
        done_pages = sum(1 for e in outcome.events if e["tool"] == "save_viz_page")
        if done_pages:
            proj = ""
            try:
                from services import viz_service
                ap = viz_service.active_project()
                if ap:
                    proj = f"（项目 {ap['project_id']}，累计已保存 {ap['page_count']} 页）"
            except Exception:
                pass
            return (f"⏸️ 本轮到此暂停，已保存 {done_pages} 页{proj}。"
                    f"请回复「继续」，我会从断点接着生成剩余页面。")
        if outcome.events:
            last = "、".join(e["tool"] for e in outcome.events[-3:])
            return f"⏸️ 本轮到此暂停，最后执行的工具：{last}。请回复「继续」，我会接着处理。"
    return "⏸️ 本轮未能产出有效回复，请换个说法重试或回复「继续」。"


def reply(agent_id: str, user_text: str, on_event=None) -> dict:
    """给指定 Agent 发一条消息，返回 {"answer", "events", "memory"}。

    on_event(phase, tool, info)：可选进度回调（UI 注入），见 runtime.run_agent。
    """
    memory.add_message(agent_id, "user", user_text)
    # 风格闸门：若上一轮小V发过风格建议单，用户本条回复即视为确认 → 授权开项目
    style_gate.confirm_if_pending(agent_id)

    agent = build(agent_id)                       # 每轮新建（事件循环隔离）
    max_turns = get_meta(agent_id)["max_tool_rounds"]
    history = memory.get_history(agent_id, limit=_HISTORY_LIMIT)

    outcome = None
    for attempt in range(2):  # 第 2 次仅在「完全空响应」时作为自愈重试
        run_input = list(history)
        if attempt:
            run_input.append({"role": "user", "content": _EMPTY_RETRY_NOTE})
        try:
            outcome = asyncio.run(
                runtime.run_agent(agent, RunDeps(agent_id), run_input, max_turns, on_event)
            )
        except Exception:
            logger.exception("[%s] 对话运行异常", agent_id)
            return {"answer": "⚠️ 对话运行出错，请重试；若反复出现请查看日志。",
                    "events": outcome.events if outcome else [],
                    "memory": {"added": 0, "pending": 0}}
        if outcome.answer or outcome.events or outcome.asked or outcome.exhausted:
            break  # 有产出/有工具进度/有意中断，都不再重试

    answer = _final_text(outcome)
    memory.add_message(agent_id, "assistant", answer)

    # 记忆提炼（失败不阻断主对话）
    mem_result = {"added": 0, "pending": 0}
    try:
        mem_result = memory_service.extract_memories(agent_id, user_text, answer)
    except Exception as exc:
        logger.warning("记忆提炼异常: %s", exc)

    return {"answer": answer, "events": outcome.events, "memory": mem_result}
