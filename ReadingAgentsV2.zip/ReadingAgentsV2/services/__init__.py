"""应用服务层（AI 的肌肉）：用框架干的具体业务。

- agents/：Agent 定义（一人一文件）+ runtime 运行引擎（openai-agents SDK）
- tools/：@function_tool 工具按归属分包（library / reading / viz / knowledge / external）
- chat_service：一轮对话的业务编排（流式运行 + 事件桥接 + 空响应自愈）
- reading_service：读书业务（切块 / 压缩 / 入库）
- viz_service：小V 可视化项目（开项目 / 存页 / 收尾）
- memory_service：记忆 CRUD / 统计 / 待确认转正 + 每轮对话后的记忆提炼
- library_service / agent_service：面向界面的收口

依赖规则：可 import infra，同层可互相调用；不得 import ui。
"""
