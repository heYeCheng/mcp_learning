"""资料库与上传服务：界面层对书目/文件上传的唯一入口。"""
from infra import config, library, memory


def list_books() -> list:
    return library.list_books()


def toggle_status(book_id: int) -> None:
    """在读 ⇄ 已完成 切换。"""
    book = library.get_book(book_id)
    if not book:
        return
    new_state = "done" if book.get("status") != "done" else "reading"
    library.update_book(book_id, status=new_state)


def delete_book(book_id: int) -> None:
    library.delete_book(book_id)


def save_upload(agent_id: str, filename: str, data: bytes) -> str:
    """保存上传文件到 data/uploads 并让该 Agent 记住路径。"""
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    path = config.UPLOAD_DIR / filename
    path.write_bytes(data)
    memory.set_uploaded_path(agent_id, str(path))
    return str(path)
