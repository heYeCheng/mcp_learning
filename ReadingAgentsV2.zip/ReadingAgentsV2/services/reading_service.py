"""阅读服务：读取文件 → 按物理页切块 → 逐块泛读压缩 → 存入资料库。供小R 使用。

压缩策略：
- 有目录：按目录章节压缩；某章节超过 max_chapter_pages 页再按 chunk_pages 页切分。
- 无目录：直接按每 chunk_pages 页切一块。
- 压缩是"保留实质内容的可读压缩"，不是一句话摘要。
"""
import hashlib
import json
import logging
from pathlib import Path

from infra import config, file_reader, library, llm

logger = logging.getLogger(__name__)

_reading_cfg = {
    "page_chars": 1800,        # 估算：一页约多少字
    "chunk_pages": 10,         # 无目录/章节过大时，每几页切一块
    "max_chapter_pages": 20,   # 章节超过多少页，再按 chunk_pages 切分
}

_BATCH = 2                     # 每批压缩的块数
_progress_cb = None            # UI 注入的进度回调


def set_progress_cb(cb):
    global _progress_cb
    _progress_cb = cb


def _report(done: int, total: int) -> None:
    if _progress_cb:
        try:
            _progress_cb(done, total)
        except Exception:
            pass


def _file_hash(path: str) -> str:
    h = hashlib.md5()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


_COMPRESS_PROMPT = """你是阅读压缩助手。下面包含若干段文档内容，每段以【标题】开头。
请把每一段分别压缩成一段通顺、可快速阅读的中文，保留该段的核心观点、关键数据、专有名词与逻辑结构，删除重复和冗余。
压缩后篇幅约为原文的 1/4 到 1/3，要保留实质内容，**不能只给一句话总结**。
严格返回 JSON：{{"sections": ["第1段压缩内容", "第2段压缩内容", ...]}}，数量与输入段落数一致、顺序一致。

<内容>
{content}
"""

_OVERALL_PROMPT = """你是阅读助手。基于下面这本资料的各块压缩内容，写：
1. overall：全文的一句话总结（不超过 50 字）。
2. key_points：3-6 条全文核心要点（每条一句话）。
3. one_line：可作为书名/标题的一句话描述（不超过 30 字）。
严格返回 JSON：{{"overall": "...", "key_points": [...], "one_line": "..."}}

<各块压缩内容>
{section_summaries}
"""


def _mk_chunk(pgs: list, heading: str, chapter: str = "") -> dict:
    text = "\n\n".join(p["text"] for p in pgs if p.get("text")).strip()
    start = pgs[0]["page_no"] if pgs else 0
    end = pgs[-1]["page_no"] if pgs else 0
    page_label = f"第{start}-{end}页" if start != end else f"第{start}页"
    label = f"{heading}（{page_label}）" if heading else page_label
    return {
        "heading": label,
        "text": text,
        "page_start": start,
        "page_end": end,
        "chapter": chapter or heading or "",
    }


_MAX_CHARS_PER_PIECE = 6000  # 文本流按章切分后，章内每块的目标字数


def split_reading_chunks(path: str) -> list:
    """切块。每块带 chapter（所属章标题），保证"细块也能聚合回章"。

    策略：
    - txt/md/docx：按章节标题行切章，章内按 _MAX_CHARS_PER_PIECE 字细分
    - PDF：优先书签目录切章（最准）；其次强模式标题检测；兜底按 chunk_pages 页合并
    返回 [{"heading","text","page_start","page_end","chapter"}]。
    """
    cfg = _reading_cfg
    suffix = Path(path).suffix.lower()

    # ---- txt / md / docx：文本流按章节标题行切章 ----
    if suffix in (".txt", ".md", ".docx"):
        text = file_reader.read_text_stream(path)
        if not text:
            return []
        segs = file_reader.split_text_by_chapters(text)
        chunks = []
        for title, content in segs:
            pieces = [content[i: i + _MAX_CHARS_PER_PIECE]
                      for i in range(0, len(content), _MAX_CHARS_PER_PIECE)] or [""]
            for j, piece in enumerate(pieces):
                heading = title if len(pieces) == 1 else f"{title}（{j + 1}/{len(pieces)}）"
                chunks.append({
                    "heading": heading or "(未分章)",
                    "text": piece,
                    "page_start": 0,
                    "page_end": 0,
                    "chapter": title or "(未分章)",
                })
        return chunks

    # ---- PDF：真实物理页 ----
    pages = file_reader.read_pages(path, cfg["page_chars"])
    pages = [
        {
            "page_no": p["page_no"],
            "text": file_reader._clean_extracted(p.get("text") or ""),
            "heading": p.get("heading"),
        }
        for p in pages
    ]
    if not pages:
        return []

    chunk_pages = cfg["chunk_pages"]
    max_chapter = cfg["max_chapter_pages"]
    total = len(pages)

    # 1) PDF 书签切章（最准确）
    marks = []
    try:
        marks = file_reader.pdf_bookmarks(path)
    except Exception as exc:
        logger.warning("读取 PDF 书签失败，退回标题检测: %s", exc)
    if len(marks) >= 2:
        cuts = sorted({m["page_no"] - 1 for m in marks if 1 <= m["page_no"] <= total})
        if not cuts or cuts[0] != 0:
            cuts = [0] + cuts
        title_by_start = {m["page_no"] - 1: m["title"] for m in marks}
        chunks = []
        for i, s in enumerate(cuts):
            e = cuts[i + 1] if i + 1 < len(cuts) else total
            if e <= s:
                continue
            chapter = title_by_start.get(s, "前言") if s != 0 else "前言"
            seg = pages[s:e]
            if len(seg) > max_chapter:
                for k in range(s, e, chunk_pages):
                    sub = pages[k:min(k + chunk_pages, e)]
                    chunks.append(_mk_chunk(sub, chapter if k == s else "", chapter))
            else:
                chunks.append(_mk_chunk(seg, chapter, chapter))
        return chunks

    # 2) 强模式标题检测 → 按章聚合
    headings = file_reader.detect_page_headings(pages)
    chapter_starts = [i for i, h in enumerate(headings) if h]

    chunks = []
    if chapter_starts:
        for bi, start in enumerate(chapter_starts):
            end = chapter_starts[bi + 1] if bi + 1 < len(chapter_starts) else len(pages)
            title = (pages[start].get("text") or "").splitlines()[0].strip()[:40]
            seg = pages[start:end]
            if len(seg) > max_chapter:
                for s in range(0, len(seg), chunk_pages):
                    chunks.append(_mk_chunk(seg[s: s + chunk_pages], title, title))
            else:
                chunks.append(_mk_chunk(seg, title, title))
        # 首章之前的页（封面/目录）
        pre = pages[: chapter_starts[0]]
        if pre:
            chunks.insert(0, _mk_chunk(pre, "前言", "前言"))
    else:
        # 3) 兜底：无章节特征，按 chunk_pages 页合并，chapter 留空
        for s in range(0, len(pages), chunk_pages):
            chunks.append(_mk_chunk(pages[s: s + chunk_pages], "", ""))
    return chunks


def _compress_chunks(chunks: list) -> list:
    """为每个阅读块生成可读压缩内容，返回 [{heading, text, summary}]。"""
    result = []
    done, total = 0, len(chunks)
    for i in range(0, total, _BATCH):
        batch = chunks[i: i + _BATCH]
        blocks = "\n\n".join(
            f"【{s.get('heading') or '(无标题)'}】\n{s.get('text', '')}" for s in batch
        )
        try:
            raw = llm.chat_json(
                [{"role": "user", "content": _COMPRESS_PROMPT.format(content=blocks)}]
            )
            contents = json.loads(raw).get("sections", [])
        except Exception as exc:
            logger.warning("内容压缩失败: %s", exc)
            contents = []
        for j, s in enumerate(batch):
            comp = contents[j] if j < len(contents) else (s.get("text", "")[:400])
            result.append({"heading": s.get("heading", ""), "text": s.get("text", ""), "summary": comp})
        done += len(batch)
        _report(done, total)
    return result


def _overall(sections: list) -> dict:
    sec_summ = "\n".join(
        f"- {s.get('heading') or '节'}：{s.get('summary', '')[:200]}" for s in sections
    )
    try:
        data = json.loads(llm.chat_json(
            [{"role": "user", "content": _OVERALL_PROMPT.format(section_summaries=sec_summ)}]
        ))
        return {
            "overall": data.get("overall", ""),
            "key_points": data.get("key_points", []),
            "one_line": data.get("one_line", ""),
        }
    except Exception as exc:
        logger.warning("全文总结失败: %s", exc)
        return {"overall": "", "key_points": [], "one_line": ""}


def parse_book(path: str, title: str = "") -> dict:
    """解析文件并按物理页切块入库（不做 LLM 压缩）。以内容 md5 去重。"""
    fh = _file_hash(path)
    if fh:
        for b in library.list_books():
            if b.get("file_hash") and b["file_hash"] == fh:
                return {
                    "book_id": b["id"],
                    "title": b.get("title") or Path(path).stem,
                    "section_count": len(b.get("sections") or []),
                    "sections": [
                        {"index": i, "heading": s["heading"] or f"第{i + 1}块"}
                        for i, s in enumerate(b.get("sections") or [])
                    ],
                }

    raw = [
        {"heading": s["heading"], "text": s["text"], "summary": "",
         "chapter": s.get("chapter", "")}
        for s in split_reading_chunks(path)
    ]
    if not title:
        title = Path(path).stem
    book_id = library.add_book(
        title=title, source=path, category="", status="reading",
        sections=raw, summary="", tags=[], one_line="", file_hash=fh,
    )
    return {
        "book_id": book_id,
        "title": title,
        "section_count": len(raw),
        "sections": [
            {"index": i, "heading": s["heading"] or f"第{i + 1}块"} for i, s in enumerate(raw)
        ],
    }


def skim_section(book_id: int, index: int) -> dict:
    """为某本书的指定阅读块生成压缩内容并入库。"""
    book = library.get_book(book_id)
    if not book:
        raise ValueError("书目不存在")
    sections = book.get("sections") or []
    if not (0 <= index < len(sections)):
        raise ValueError(f"块序号 {index} 超出范围（共 {len(sections)} 块）")
    comp = _compress_chunks([sections[index]])
    sections[index]["summary"] = comp[0]["summary"]
    library.update_book(book_id, sections=sections)
    return {
        "index": index,
        "heading": sections[index].get("heading") or f"第{index + 1}块",
        "summary": comp[0]["summary"],
    }


def deep_dive(book_id: int, index: int) -> dict:
    """取某本书指定阅读块的完整原文，供深入讲解（不截断内容本身）。"""
    book = library.get_book(book_id)
    if not book:
        raise ValueError("书目不存在")
    sections = book.get("sections") or []
    if not (0 <= index < len(sections)):
        raise ValueError(f"块序号 {index} 超出范围（共 {len(sections)} 块）")
    sec = sections[index]
    return {
        "book_id": book_id,
        "title": book.get("title", ""),
        "index": index,
        "heading": sec.get("heading") or f"第{index + 1}块",
        "text": sec.get("text", ""),
        "summary": sec.get("summary", ""),
    }


def chapter_list(sections: list) -> list:
    """从块列表聚合章目录（保序去重），返回 [{"index"(1起), "title", "blocks", "done"}]。"""
    chapters, pos = [], {}
    for s in sections:
        ch = (s.get("chapter") or "").strip() or "(未分章)"
        if ch not in pos:
            pos[ch] = len(chapters)
            chapters.append({"title": ch, "blocks": 0, "done": 0})
        c = chapters[pos[ch]]
        c["blocks"] += 1
        if (s.get("summary") or "").strip():
            c["done"] += 1
    for i, c in enumerate(chapters, 1):
        c["index"] = i
    return chapters


def read_chapter(book_id: int, chapter: int = 0, query: str = "") -> dict:
    """取某一章的全部块原文（聚合），供逐章阅读。chapter 为 1 起序号，query 为标题模糊匹配。"""
    book = library.get_book(book_id)
    if not book:
        raise ValueError("书目不存在")
    sections = book.get("sections") or []
    chapters = chapter_list(sections)
    if not chapters:
        raise ValueError("该书没有可读内容")
    target = None
    if query.strip():
        q = query.strip()
        target = next((c for c in chapters if q in c["title"]), None)
        if target is None:
            raise ValueError(f"找不到包含「{q}」的章。可用章："
                             + "；".join(f"{c['index']}.{c['title']}" for c in chapters[:40]))
    elif chapter:
        if not (1 <= chapter <= len(chapters)):
            raise ValueError(f"章序号 {chapter} 超出范围（共 {len(chapters)} 章）")
        target = chapters[chapter - 1]
    else:
        raise ValueError("缺少 chapter 或 query 参数")
    ch_name = target["title"]
    texts = [s.get("text", "") for s in sections
             if ((s.get("chapter") or "").strip() or "(未分章)") == ch_name]
    full = "\n\n".join(t for t in texts if t).strip()
    truncated = ""
    if len(full) > 25000:
        full = full[:25000]
        truncated = "\n…（本章过长已截断，可让我分块继续读本章）"
    return {
        "book_id": book_id,
        "title": book.get("title", ""),
        "chapter_index": target["index"],
        "chapter_title": ch_name,
        "blocks": target["blocks"],
        "chars": len(full),
        "text": full,
        "truncated_note": truncated,
    }


def read_and_skim_by_id(book_id: int) -> dict:
    """对已解析入册的书做全书压缩（带进度），并写回。"""
    book = library.get_book(book_id)
    if not book:
        raise ValueError("书目不存在")
    sections = _compress_chunks(book.get("sections") or [])
    meta = _overall(sections)
    library.update_book(
        book_id,
        sections=sections,
        summary=meta.get("overall", ""),
        one_line=meta.get("one_line", ""),
        key_points=meta.get("key_points", []),
    )
    return {
        "book_id": book_id,
        "section_count": len(sections),
        "key_points": meta.get("key_points", []),
        "overall": meta.get("overall", ""),
        "section_summaries": [s["summary"] for s in sections],
    }
