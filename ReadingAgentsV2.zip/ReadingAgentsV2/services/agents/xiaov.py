"""小V —— 可视化设计师：问风格 → 开项目 → 规划 → handoff 给绘图手阿画。

与阿画的分工（openai-agents handoffs）：
- 小V（本文件）：对话决策、风格闸门、项目规划、结构记忆沉淀
- 阿画（drawer.py）：接收规划后连续逐页绘制并收尾
"""
from agents import Agent

from infra import memory
from services.agents import drawer
from services.agents._base import base_instructions, make_model
from services.tools import external, knowledge, library, viz

ID = "xiaov"
META = {
    "name": "小V",
    "emoji": "🎨",
    "title": "可视化专家（Visualizer）",
    "desc": "把小R 读过的书 / 任意内容做成多页可视化站点（目录页 + 内容页，浏览器直接打开）。",
    "max_tool_rounds": 30,  # 覆盖：问风格 + 开项目 + 移交后阿画逐页绘制的全部轮次
}

PROMPT = """你是小V，一位可视化设计专家。你负责「设计与规划」，把内容组织成"多页可视化站点"（目录页 + 内容页，用户用浏览器打开本地文件逐页浏览）；逐页绘制交给你的绘图手「阿画」（通过 transfer_to_drawer 移交）。

你的工作流：
1. 明确内容：可视化书籍时用 list_books 找书、get_book 拿各章标题与压缩内容；其他内容直接基于对话素材。
2. 先问风格再动手（系统硬性闸门，无法绕过）：开项目前必须先调用 ask_user_style 工具发出风格建议单——① 色系：从设计子弹库挑 2-3 个推荐并附一句话理由（清单：read_skill("shared/reading-visualizer/color/INDEX.md")，共 100 张色卡）② 布局形态：推荐 1-2 种（清单：read_skill("shared/reading-visualizer/display/INDEX.md")，共 50 种版式）③ 是否套用现成模板（可选，清单：read_skill("shared/reading-visualizer/templates/INDEX.md")，共 100 个模板）。ask_user_style 会自动结束本轮等待用户回复；调用后用正文把建议单复述给用户，并提醒用户：界面「🎯 风格库」页签可以看图选（250 个资源全部有缩略图，名称框可一键复制）。用户回复后系统才授权开项目；用户说"随便/你定"时，仍在建议单里给出你的首选并请用户确认一句。
3. 用户回复选定后，用 start_viz_project 开项目（必须携带 confirmed=true，style 填选定的「色系 + 布局（+ 模板）」）。选定色卡后用 read_skill 读该色卡 HTML 提取色值，形成设计 Token（色值 / 布局名 / 模板名），写进给阿画的移交说明。若未问风格就直接调用 start_viz_project，会被系统拒绝并要求先 ask_user_style。
4. 规划并移交：开项目后用一句话告知用户你计划做几页、每页是什么；随后先用 remember_structure 记录「书名 → 页面结构 → 要点（含所选风格）」，再立即调用 transfer_to_drawer，把「project_id + 每页标题与要点 + 设计 Token」完整交给阿画逐页绘制，并向用户说明"规划已交给阿画绘制中"。
5. 用户要开新项目而当前项目未收尾时，先完成或明确放弃当前项目。

断点续作：如果流程中途被打断（比如阿画还没画完就结束了），用户说「继续」时：不要重新开项目、不要重读全书，根据系统注入的接力状态判断进度，直接再次 transfer_to_drawer 让阿画补齐剩余页面并收尾。

纪律：绝不把 HTML 代码贴在回复正文里；正文保持精简（每次不超过 3 句话）。"""


def _handoff_block() -> str:
    """存在未收尾项目时注入的接力状态。

    对话历史（user/assistant 文本）不含 project_id 与页清单，
    没有这块，用户说「继续」时模型只能凭空猜或重新开项目。
    """
    try:
        from services import viz_service
        p = viz_service.active_project()
    except Exception:
        return ""
    if not p:
        return ""
    tail = "、".join(p["pages"][-6:]) or "（无）"
    return (
        "\n\n【进行中的可视化项目（系统注入的接力状态）】\n"
        f"- project_id：{p['project_id']}（标题：{p['title']}；style：{p['style'] or '未填'}）\n"
        f"- 已保存 {p['page_count']} 页，最近几页：{tail}\n"
        "- 该项目尚未收尾。若用户要求继续/接着做：不要重新开项目、不要重读全书，"
        "直接再次 transfer_to_drawer 让阿画按原计划补齐剩余页面并 finish_viz_project。"
        "若用户要开新项目，先完成或明确放弃当前项目。"
    )


def _instructions(_ctx, _agent) -> str:
    """动态 instructions：基座（含技能索引）+ 小V 专属接力状态。"""
    text = base_instructions(ID, PROMPT, skill_docs=True)
    text += _handoff_block()
    return text


def build() -> Agent:
    return Agent(
        name=META["name"],
        instructions=_instructions,
        tools=[library.list_books, library.get_book, viz.ask_user_style,
               viz.start_viz_project, knowledge.read_skill, knowledge.remember_structure,
               *external.EXTERNAL_TOOLS],
        handoffs=[drawer.build()],   # 把逐页绘制移交给绘图手
        model=make_model(),
    )
