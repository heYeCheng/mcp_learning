"""Agent 组装公共件：模型工厂 + instructions 基座。

关键约束：make_model() 每次 build 都要新建 AsyncOpenAI——
reply 每轮 asyncio.run 会更换事件循环，共享客户端会复用旧循环的
连接池，第二次对话报「Event loop is closed」。
"""
from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel
from openai import AsyncOpenAI

from infra import config, memory, skills


def make_model() -> OpenAIChatCompletionsModel:
    """新建一个绑定独立 AsyncOpenAI 客户端的模型（每轮对话调用一次）。"""
    client = AsyncOpenAI(base_url=config.BASE_URL, api_key=config.API_KEY)
    return OpenAIChatCompletionsModel(config.MODEL, client)


def base_instructions(agent_id: str, persona_prompt: str, *,
                      skill_docs: bool = False) -> str:
    """人设正文 + 技能注入 + 记忆块（各 Agent 共用的 instructions 底座）。

    skill_docs=True 时附技能文档索引（有 read_skill 工具的 Agent 用）。
    各 agent 文件在自己的 instructions 函数里叠加专属上下文
    （小R 待读文件 / 小B 掌握度 / 小V 接力状态）。
    """
    parts = [persona_prompt]

    skill_prompt = skills.build_agent_skill_prompt(agent_id)
    if skill_prompt:
        parts.append(skill_prompt)

    if skill_docs:
        idx = skills.skill_index()
        if idx:
            parts.append(
                "【可用技能文档索引（用 read_skill 读取，path 填相对路径，"
                "如 xiaov/SKILL.md）】\n" + idx
            )

    mem_block = memory.build_memory_block(agent_id)
    if mem_block:
        parts.append(mem_block)

    return "\n\n".join(parts)
