"""流式运行引擎：Runner.run_streamed + SDK 事件桥接。

只负责机制（怎么跑、怎么桥接事件、怎么标记中断），不含任何产品话术；
一轮对话的业务行为（历史 / 闸门 / 兜底文案 / 记忆提炼）在 chat_service。
"""
import json
import logging
from dataclasses import dataclass, field

from agents import Agent, MaxTurnsExceeded, Runner
from agents.stream_events import RawResponsesStreamEvent, RunItemStreamEvent
from openai.types.responses import ResponseTextDeltaEvent

from services.tools.base import AskUserInterrupt, RunDeps

logger = logging.getLogger(__name__)


@dataclass
class RunOutcome:
    """一次流式运行的结果与状态标记。"""

    answer: str = ""
    events: list = field(default_factory=list)   # [{"tool","args","result"}]
    asked: bool = False       # ask_user_style 已发出建议单，等待用户回复
    exhausted: bool = False   # 工具轮次用尽


def _emit(on_event, phase: str, tool: str, info) -> None:
    if not on_event:
        return
    try:
        on_event(phase, tool, info)
    except Exception:
        pass  # 回调异常绝不影响主对话


async def run_agent(agent: Agent, deps: RunDeps, run_input: list,
                    max_turns: int, on_event=None) -> RunOutcome:
    """流式运行一个 SDK Agent，桥接事件到 on_event / RunOutcome。

    on_event(phase, tool, info)：
    - phase="delta" info=正文增量（流式渲染）
    - phase="start" info=工具参数 dict；"done" info=结果文本（截断）
    """
    outcome = RunOutcome()
    result = Runner.run_streamed(agent, input=run_input, context=deps, max_turns=max_turns)
    call_names: dict = {}  # tool call_id → 工具名（tool_output 事件里只有 call_id）

    try:
        async for event in result.stream_events():
            # 正文增量：透传给 UI 实时渲染
            if isinstance(event, RawResponsesStreamEvent) and isinstance(
                    event.data, ResponseTextDeltaEvent):
                outcome.answer += event.data.delta
                _emit(on_event, "delta", "answer", event.data.delta)

            # 工具调用 / 结果：记入 events，通知 UI
            elif isinstance(event, RunItemStreamEvent):
                if event.name == "tool_called":
                    raw = event.item.raw_item
                    call_names[raw.call_id] = raw.name
                    try:
                        args = json.loads(raw.arguments or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    outcome.events.append({"tool": raw.name, "args": args, "result": ""})
                    _emit(on_event, "start", raw.name, args)
                elif event.name == "tool_output":
                    raw = event.item.raw_item
                    name = call_names.get(raw.call_id, "?")
                    output = str(event.item.output)
                    for ev in reversed(outcome.events):
                        if ev["tool"] == name and not ev["result"]:
                            ev["result"] = output
                            break
                    _emit(on_event, "done", name, output[:200])
    except AskUserInterrupt:
        outcome.asked = True
    except MaxTurnsExceeded:
        outcome.exhausted = True
    except Exception:
        logger.exception("Agent 运行异常")
        raise

    outcome.answer = outcome.answer.strip()
    return outcome
