"""Agent 定义层：每个 agent 一个文件，人设 + 注入 + 工具 + 定义一个文件看全。

- xiaor.py：小R，阅读助手
- xiaob.py：小B，知识巩固导师（掌握度闭环）
- xiaov.py：小V，可视化设计师（handoffs → 阿画）
- drawer.py：阿画，小V 的绘图手（专职子 agent，不直接面对用户）
- runtime.py：流式运行引擎（Runner + 事件桥接）
- _base.py：模型工厂 + instructions 基座

build() 每次调用都新建 Agent 与模型连接（事件循环随 asyncio.run 每轮更换，
Agent/model 不能跨轮复用）；META 是纯展示信息（侧边栏 / 页签用）。
"""
from services.agents import drawer, xiaob, xiaor, xiaov

# 对话入口注册表（drawer 是内部子 agent，不在其中）
# 注意：小B 的 agent_id 全局约定为 "xiab"（入口文件 run_xiab.py、记忆库均用它）
_MODULES = {"xiaor": xiaor, "xiab": xiaob, "xiaov": xiaov}
META = {aid: dict(m.META, id=aid) for aid, m in _MODULES.items()}
AGENT_IDS = list(META)


def get_meta(agent_id: str) -> dict:
    """某 Agent 的展示信息；未知 id 直接报错。"""
    if agent_id not in META:
        raise KeyError(f"未知 Agent：{agent_id}（可选：{AGENT_IDS}）")
    return META[agent_id]


def build(agent_id: str):
    """新建某 Agent 的 SDK 实例（含模型连接，一轮对话调一次）。"""
    return _MODULES[agent_id].build()
