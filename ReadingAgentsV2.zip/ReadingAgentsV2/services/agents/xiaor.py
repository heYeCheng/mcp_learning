"""小R —— 阅读助手。人设、记忆注入、工具、Agent 定义：一个文件看全。

（注：`from agents import Agent` 引用的是 openai-agents SDK；
本包是 services.agents，与 SDK 顶层包不冲突。）
"""
from agents import Agent

from infra import memory
from services.agents._base import base_instructions, make_model
from services.tools import external, library, reading

ID = "xiaor"
META = {
    "name": "小R",
    "emoji": "📖",
    "title": "阅读助手（Reader）",
    "desc": "读取 txt / PDF / Word(docx) 文件，按物理页切块、逐块泛读压缩，提炼全书要点。",
    "max_tool_rounds": 8,   # 一次回复最多「模型调用 → 工具执行」轮数
}

PROMPT = """你是小R，一位专业的阅读助手。你的职责：
1. 读取用户提供的文档（txt / 文字类 PDF / Word docx），用 read_file 工具切块存入资料库。系统会自动识别章节结构（PDF 书签 > 章节标题行 > 智能兜底），每个阅读块带 chapter（所属章）字段，因此既能按块细读，也能按章聚合。
2. 阅读粒度按用户说法选择：用户说「读第 X 章 / 讲讲某章」时用 read_chapter 聚合整章原文再讲解（章号或标题关键词均可，配合 get_book 的章目录定位）；说「读第 X 块」时用 skim_chapter 只压缩那一块；只有用户要求「从头读完 / 总结全书」时才用 skim_book 做全书压缩，且只调用一次，不要反复循环。
3. 每压缩完一块，把压缩内容整理给用户后，必须明确给出下一步选项（如：继续读第 X+1 块 / 深入讲讲这块的某点 / 读完总结全书），让用户随时知道如何推进。
4. 深入展开：用户对某个位置想深入了解时（「这里展开讲讲」「这个概念详细说说」），先用 deep_dive 获取该块完整原文，再基于原文逐层讲解：补充背景、拆解机制、举例说明。不得编造原文没有的细节；原文不够时如实告知。
5. 记忆分层机制：你读到一个章节后，本系统会自动提炼候选记忆；重要的内容（关键结论、专有名词、阅读偏好）会被系统列入"待确认"，用户确认后成为你的长期记忆。你也可在对话中主动提示"这段值得记住，可到记忆管理页确认"。

你的沟通风格：高效、条理清晰、善于抓重点。"""


def _instructions(_ctx, _agent) -> str:
    """动态 instructions：基座 + 小R 专属的待读文件路径。"""
    text = base_instructions(ID, PROMPT)
    up = memory.get_uploaded_path(ID)
    if up:
        text += (
            f"\n\n【当前待阅读文件路径】\n{up}\n"
            "当用户让你阅读/打开/读这本书时，请调用 read_file 工具并传入上面的 path。"
        )
    return text


def build() -> Agent:
    """新建一个可运行的 SDK Agent（每次调用都带全新模型连接）。"""
    return Agent(
        name=META["name"],
        instructions=_instructions,
        tools=[library.list_books, reading.read_file, reading.skim_chapter,
               reading.read_chapter, reading.deep_dive, reading.skim_book,
               *external.EXTERNAL_TOOLS],
        model=make_model(),
    )
