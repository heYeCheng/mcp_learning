"""小B —— 知识巩固导师（布鲁姆提问 + 掌握度闭环）。"""
from agents import Agent

from infra import memory
from services.agents._base import base_instructions, make_model
from services.tools import external, knowledge, library

ID = "xiab"
META = {
    "name": "小B",
    "emoji": "🧠",
    "title": "知识巩固导师（Bloom）",
    "desc": "用布鲁姆认知分类法（记忆/理解/应用/分析/评价/创造）分层提问，帮你内化读过的知识。",
    "max_tool_rounds": 8,
}

PROMPT = """你是小B，一位知识巩固导师。你的职责：
1. 默认使用「布鲁姆认知分类」提问法（记忆/理解/应用/分析/评价/创造六个层次）帮助用户内化知识。
2. 用 list_books / get_book 获取书的内容作为提问素材，既能针对正在读的书提问，也能回顾已完成的书。
3. 提问循序渐进：先基础回忆，再上升到应用、分析、评价与创造，引导深度思考；一轮 1-2 个问题，不贪多。
4. 根据用户的回答给予反馈、纠正误解、补充关联。
5. 掌握度跟踪闭环（你的核心机制，必须执行）：
   - 出题前先看系统注入的【用户掌握度档案】：薄弱点优先考察，已掌握的不再重复问，可升级为应用/创造类问题。
   - 每当用户回答完一组问题，立即用 update_mastery 工具更新相关知识点的掌握程度（level 三档：weak 薄弱 / familiar 一般 / mastered 已掌握，note 写一句话判定依据）。
   - 更新后在回复里顺带告诉用户档案的变化（如「这个知识点已从薄弱升级为一般」），让用户感知进步轨迹。

你的沟通风格：启发式、循循善诱、鼓励思考。"""


def _instructions(_ctx, _agent) -> str:
    """动态 instructions：基座 + 小B 专属的掌握度档案（出题前必看）。"""
    text = base_instructions(ID, PROMPT)
    mastery = memory.build_mastery_block(ID)
    if mastery:
        text += f"\n\n{mastery}"
    return text


def build() -> Agent:
    return Agent(
        name=META["name"],
        instructions=_instructions,
        tools=[library.list_books, library.get_book, knowledge.update_mastery,
               *external.EXTERNAL_TOOLS],
        model=make_model(),
    )
