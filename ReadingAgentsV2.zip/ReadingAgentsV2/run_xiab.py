"""小B（知识巩固导师）独立启动入口。

启动：streamlit run run_xiab.py
"""
from ui.app import run

run("xiab")
