"""小V（可视化专家）独立启动入口。

启动：streamlit run run_xiaov.py
"""
from ui.app import run

run("xiaov")
