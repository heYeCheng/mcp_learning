"""文件上传页签：上传文件给小R 阅读并记住路径。"""
import streamlit as st

from services import library_service


def render(agent_id: str):
    st.subheader("上传文件给小R 阅读")
    st.caption("支持 txt / md / 文字类 PDF / Word(docx)。上传后文件路径会被记住，"
               "你在对话里说「读这本书」即可触发 read_file 工具。")
    f = st.file_uploader("选择文件", type=["txt", "md", "pdf", "docx"], key="up")
    if f is not None:
        path = library_service.save_upload(agent_id, f.name, f.getvalue())
        st.success(f"已保存并记住路径：{path}\n\n现在可以在对话里说：读《{f.name}》")
