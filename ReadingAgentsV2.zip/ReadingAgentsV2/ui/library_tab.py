"""资料库页签：书目与各节内容的展示。"""
import streamlit as st

from services import library_service


def render(agent_id: str):
    st.subheader("资料库")
    books = library_service.list_books()
    if not books:
        st.caption("（暂无书目。小R 上传文件并阅读后会自动入库。）")
        return
    for b in books:
        state = {"reading": "在读", "done": "已完成"}.get(b.get("status"), b.get("status"))
        with st.expander(f"#{b['id']} 《{b['title']}》[{state}] ｜ {b.get('one_line') or b.get('summary') or ''}"):
            st.markdown(f"**分类**：{b.get('category') or '无'}　**标签**：{'、'.join(b.get('tags') or []) or '无'}")
            if b.get("summary"):
                st.markdown(f"**总结**：{b['summary']}")
            secs = b.get("sections") or []
            for i, s in enumerate(secs):
                summ = s.get("summary") or ""
                text = (s.get("text") or "").replace("\n", " ")[:180]
                st.markdown(f"**[{i}] {s.get('heading') or '节'}**" + (f"　摘要：{summ}" if summ else ""))
                st.caption(text)
            c1, c2 = st.columns(2)
            if c1.button("切换状态", key=f"bs_{b['id']}"):
                library_service.toggle_status(b["id"])
                st.rerun()
            if c2.button("删除", key=f"bd_{b['id']}"):
                library_service.delete_book(b["id"])
                st.rerun()
