"""风格库浏览页签：设计子弹库缩略图浏览（色卡 / 布局 / 模板）。

250 个资源全是自包含 HTML 演示页。用 components.html 渲染成小图（iframe +
注入 scale 样式整页缩小），配合搜索与分页保证一次只渲染十几个、不卡页面。
用户看图选定后，点卡片下方名称框的复制图标，粘到「💬 对话」回复小V 即可。
"""
import os
import re

import streamlit as st
import streamlit.components.v1 as components

from infra import config

BASE = config.PROJECT_ROOT / "skills" / "shared" / "reading-visualizer"

CATEGORIES = {
    "🎨 色卡": {"dir": "color", "per_page": 12, "cols": 3, "scale": 0.32, "height": 260},
    "📐 布局": {"dir": "display", "per_page": 9, "cols": 3, "scale": 0.30, "height": 300},
    "🖼️ 模板": {"dir": "templates", "per_page": 6, "cols": 2, "scale": 0.28, "height": 340},
}


def _list_files(sub: str) -> list:
    """列出某分类下全部 HTML，按文件名数字前缀排序（避免 10 排在 9 前面）。"""
    d = BASE / sub
    if not d.is_dir():
        return []
    files = list(d.glob("*.html"))
    files.sort(key=lambda p: (int(m.group(1)) if (m := re.match(r"(\d+)", p.name)) else 10 ** 9,
                              p.name))
    return files


def _scaled_html(path, scale: float) -> str:
    """读入 HTML 并注入整页缩放样式，把桌面版式缩小成缩略图。"""
    html = path.read_text(encoding="utf-8", errors="ignore")
    inject = (f"<style>html{{transform:scale({scale});transform-origin:0 0;"
              f"width:{100 / scale:.1f}% !important;}}</style></head>")
    return html.replace("</head>", inject, 1)


def render(agent_id: str = ""):
    st.markdown("#### 🎯 风格库浏览（设计子弹库缩略图）")
    st.caption("小V 问你风格时，来这里看图选：点名称框右上角的复制图标，"
               "粘到「💬 对话」回复小V 即可。小图看不清就点「原尺寸打开」。")

    cat = st.radio("分类", list(CATEGORIES), horizontal=True, label_visibility="collapsed")
    cfg = CATEGORIES[cat]
    files = _list_files(cfg["dir"])
    if not files:
        st.error(f"目录不存在或为空：{BASE / cfg['dir']}")
        return

    q = st.text_input("搜索（按名称过滤）", "").strip()
    if q:
        files = [p for p in files if q in p.stem]

    per = cfg["per_page"]
    total = max(1, (len(files) + per - 1) // per)
    state_key = f"style_page_{cfg['dir']}"
    nav1, nav2, nav3 = st.columns([1, 1, 4])
    if nav1.button("◀ 上一页"):
        st.session_state[state_key] = max(0, st.session_state.get(state_key, 0) - 1)
    if nav2.button("下一页 ▶"):
        st.session_state[state_key] = min(total - 1, st.session_state.get(state_key, 0) + 1)
    page = min(st.session_state.get(state_key, 0), total - 1)
    nav3.caption(f"共 {len(files)} 个 · 第 {page + 1}/{total} 页")

    chunk = files[page * per:(page + 1) * per]
    for row_start in range(0, len(chunk), cfg["cols"]):
        row = chunk[row_start:row_start + cfg["cols"]]
        cols = st.columns(cfg["cols"])
        for col, p in zip(cols, row):
            with col:
                components.html(_scaled_html(p, cfg["scale"]),
                                height=cfg["height"], scrolling=False)
                st.code(p.stem, language=None)  # 名称框自带复制图标
                if st.button("🖥️ 原尺寸打开", key=f"open_{cfg['dir']}_{p.name}"):
                    os.startfile(p)
