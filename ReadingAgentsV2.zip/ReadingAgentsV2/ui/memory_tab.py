"""记忆管理页签：三态记忆 / 待确认候选 / 层级记忆的展示与操作。"""
import datetime

import streamlit as st

from services import memory_service


def fmt_time(ts) -> str:
    if not ts:
        return "永久"
    return datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def expire_label(row) -> str:
    if row.get("tier") == "long":
        return "永久"
    return f"→ {fmt_time(row.get('expires_at'))}"


def render_memory_rows(agent_id: str, rows: list, key_prefix: str):
    """渲染记忆列表（带删除按钮）。"""
    if not rows:
        st.caption("（暂无）")
        return
    for r in rows:
        cols = st.columns([0.62, 0.2, 0.18])
        label = f"[{r['type']}] {r['content']}"
        cols[0].markdown(f"**{label}**  \n⏱ {fmt_time(r['created_at'])}　{expire_label(r)}")
        cols[1].caption(f"来源: {r.get('source') or '-'}")
        if cols[2].button("删除", key=f"{key_prefix}_del_{r['id']}"):
            memory_service.delete(agent_id, r["id"])
            st.rerun()


def render(agent_id: str):
    st.subheader("记忆管理")
    tab_p, tab_s, tab_m, tab_l, tab_h, tab_k = st.tabs(
        ["待确认(转长期)", "短期(3天)", "中期(3个月)", "长期(永久)", "层级记忆(小V)", "掌握度(小B)"])

    # ---- 待确认：批量确认 ----
    with tab_p:
        st.markdown("AI 提炼出的候选记忆，**勾选后批量确认 → 转为长期记忆（永久）**。")
        pending = memory_service.get_pending(agent_id)
        if not pending:
            st.caption("（暂无待确认候选）")
        else:
            chosen = []
            for p in pending:
                if st.checkbox(f"[{p['type']}] {p['content']}　⏱{fmt_time(p['created_at'])}",
                               key=f"pend_{p['id']}"):
                    chosen.append(p["id"])
            c1, c2 = st.columns(2)
            if c1.button(f"✅ 确认选中 {len(chosen)} 条 → 长期"):
                n = memory_service.approve_pending(chosen)
                st.success(f"已转正 {n} 条为长期记忆。")
                st.rerun()
            if c2.button(f"🗑 驳回选中 {len(chosen)} 条"):
                n = memory_service.reject_pending(chosen)
                st.success(f"已驳回 {n} 条。")
                st.rerun()

    # ---- 强制记忆（手工） ----
    with tab_l:
        st.markdown("**手工强制记忆**：直接写入长期记忆（永久），不走待确认流程。")
        with st.form("force_long"):
            mtype = st.selectbox("类型", memory_service.TYPES, key="fm_type")
            content = st.text_area("内容", key="fm_content", height=80)
            if st.form_submit_button("强制记住"):
                if content.strip():
                    mid = memory_service.force_long(agent_id, mtype, content.strip())
                    st.success("已强制记入长期记忆。" if mid else "内容为空或已存在。")
                else:
                    st.warning("请输入内容。")
        st.divider()
        st.markdown("**长期记忆列表（人工确认后永久保存）**")
        render_memory_rows(agent_id, memory_service.list_by_tier(agent_id, "long"), "long")

    with tab_s:
        st.markdown("短期记忆：自动沉淀，**3 天**过期（保存时带时间戳）。")
        render_memory_rows(agent_id, memory_service.list_by_tier(agent_id, "short"), "short")
    with tab_m:
        st.markdown("中期记忆：自动沉淀，**3 个月**过期（保存时带时间戳）。")
        render_memory_rows(agent_id, memory_service.list_by_tier(agent_id, "mid"), "mid")

    # ---- 层级记忆（小V 专属：书名→章节→内容） ----
    with tab_h:
        st.markdown("层级记忆：**书名/标题 → 章节 → 具体内容**，供小V 复用做过的可视化结构。")
        hier = memory_service.list_hier(agent_id)
        if not hier:
            st.caption("（暂无层级记忆）")
        groups = {}
        for h in hier:
            groups.setdefault(h["book_title"], []).append(h)
        for title, items in groups.items():
            with st.expander(f"《{title}》（{len(items)} 条）"):
                for it in items:
                    cols = st.columns([0.8, 0.2])
                    ch = it["chapter"] or "（整体）"
                    cols[0].markdown(f"**{ch}**  \n{it['content']}  \n⏱{fmt_time(it['created_at'])}")
                    if cols[1].button("删除", key=f"hier_del_{it['id']}"):
                        memory_service.delete_hier(agent_id, it["id"])
                        st.rerun()
        st.divider()
        st.markdown("**手工添加层级记忆**")
        with st.form("hier_add"):
            h1 = st.text_input("书名/标题")
            h2 = st.text_input("章节（可留空=整体）")
            h3 = st.text_area("具体内容", height=80)
            if st.form_submit_button("添加"):
                if memory_service.add_hier(agent_id, h1, h2, h3):
                    st.success("已添加。")
                    st.rerun()
                else:
                    st.warning("书名和内容不能为空。")

    # ---- 掌握度档案（小B 专属：知识点 → 三档掌握程度） ----
    with tab_k:
        st.markdown("掌握度档案：小B 出题后自动记录你对各知识点的掌握程度"
                    "（🔴 薄弱 / 🟡 一般 / 🟢 已掌握），出题时优先考察薄弱点。")
        mastery = memory_service.list_mastery(agent_id)
        if not mastery:
            st.caption("（暂无掌握度记录）")
        for r in mastery:
            icon = {"weak": "🔴", "familiar": "🟡", "mastered": "🟢"}.get(r["level"], "⚪")
            book = f"（《{r['book_title']}》）" if r["book_title"] else ""
            note = f"  \n💬 {r['note']}" if r["note"] else ""
            cols = st.columns([0.82, 0.18])
            cols[0].markdown(
                f"{icon} **{r['topic']}**{book}　·　{memory_service.MASTERY_LABELS.get(r['level'], r['level'])}"
                f"{note}  \n⏱ {fmt_time(r['updated_at'])}"
            )
            if cols[1].button("删除", key=f"mastery_del_{r['id']}"):
                memory_service.delete_mastery(agent_id, r["id"])
                st.rerun()
