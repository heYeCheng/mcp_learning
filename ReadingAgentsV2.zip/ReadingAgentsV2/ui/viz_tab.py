"""可视化作品页签：列出全部可视化站点，一键打开，解决"生成了但找不到"的问题。"""
import os

import streamlit as st

from infra import config
from services import viz_service


def render(agent_id: str):
    st.subheader("可视化作品")
    st.caption("小V 生成的多页可视化站点都保存在这里。点「打开」从目录页 index.html 浏览全部页面。")
    projects = viz_service.list_projects()
    if not projects:
        st.caption("（还没有作品。到「对话」页让小V 做可视化，站点完成后会自动出现在这里。）")
        return
    for p in reversed(projects):  # 最新在前
        state = "目录页已生成" if p["has_index"] else "⚠️ 未收尾（缺目录页）"
        with st.expander(f"《{p['title']}》 · {p['pages']} 页 · {state} · {p['project_id']}"):
            path = str(config.VIZ_DIR / p["project_id"] / "index.html")
            if not p["has_index"]:
                st.caption("（生成目录页后即可打开）")
            st.code(path)
            b1, b2 = st.columns(2)
            if b1.button("📂 打开站点", key=f"viz_open_{p['project_id']}"):
                try:
                    os.startfile(path)  # noqa: S606（Windows 专用）
                except Exception:
                    st.warning(f"自动打开失败，请手动用浏览器打开：{path}")
            if b2.button("📁 打开所在文件夹", key=f"viz_dir_{p['project_id']}"):
                try:
                    os.startfile(str(config.VIZ_DIR / p["project_id"]))  # noqa: S606
                except Exception:
                    st.warning(f"请手动打开文件夹：{config.VIZ_DIR / p['project_id']}")
