"""界面主骨架：入口 run() 组装侧边栏与五个页签。

依赖规则：只 import services 层；各 tab 的展示函数在同级 tab 模块中。
当前 Agent 身份放 st.session_state，消灭原 global AGENT_ID。
"""
import streamlit as st

from services import agent_service, memory_service

from . import chat_tab as tab_chat
from . import library_tab as tab_library
from . import memory_tab as tab_memory
from . import skills_tab as tab_skills
from . import style_tab as tab_style
from . import upload_tab as tab_upload
from . import viz_tab as tab_viz


def sidebar(agent_id: str):
    agent = agent_service.get_profile(agent_id)
    with st.sidebar:
        st.markdown(f"# {agent['emoji']} {agent['name']}  <small>{agent['title']}</small>",
                    unsafe_allow_html=True)
        st.caption(agent["desc"])
        st.divider()

        st.markdown("**接口配置**")
        if not agent["api_ready"]:
            st.error("未配置 API_KEY，请复制 .env.example 为 .env 并填入公司的接口参数。")
        else:
            st.caption(f"BASE_URL: {agent['base_url']}\n\nMODEL: {agent['model']}")
        st.divider()

        st.markdown("**记忆概览**")
        ov = memory_service.get_overview(agent_id)
        for tier in memory_service.TIERS:
            st.caption(f"{memory_service.TIER_LABELS[tier]}：{ov['tier_counts'].get(tier, 0)} 条")
        st.caption(f"待确认候选：{ov['pending']} 条")
        if ov["hier"]:
            st.caption(f"层级记忆：{ov['hier']} 条")

        st.divider()
        if st.button("清空本轮对话"):
            memory_service.clear_conversation(agent_id)
            st.session_state.pop("chat_msgs", None)
            st.rerun()


def run(agent_id: str):
    """入口：run_xiaor / run_xiaov / run_xiab 各自调用。

    注意：st.set_page_config 与 st.tabs 必须在每次脚本运行时执行（会话内），
    不能放在模块层——模块只 import 一次，第二个会话会因元素树路径错位白屏。
    """
    st.set_page_config(page_title="Agent 骨架", page_icon="🤖", layout="wide")
    st.session_state["agent_id"] = agent_id
    sidebar(agent_id)
    tabs = st.tabs(["💬 对话", "🧠 记忆管理", "📚 资料库", "📁 文件上传", "🛠️ 技能", "🎨 作品"]
                   + (["🎯 风格库"] if agent_id == "xiaov" else []))
    TAB_CHAT, TAB_MEMORY, TAB_LIBRARY, TAB_UPLOAD, TAB_SKILLS, TAB_VIZ = tabs[:6]
    with TAB_CHAT:
        tab_chat.render(agent_id)
    with TAB_MEMORY:
        tab_memory.render(agent_id)
    with TAB_LIBRARY:
        tab_library.render(agent_id)
    with TAB_UPLOAD:
        tab_upload.render(agent_id)
    with TAB_SKILLS:
        tab_skills.render(agent_id)
    with TAB_VIZ:
        tab_viz.render(agent_id)
    if agent_id == "xiaov":
        with tabs[6]:
            tab_style.render(agent_id)
