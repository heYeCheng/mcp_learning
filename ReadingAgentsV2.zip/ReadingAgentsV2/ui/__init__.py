"""界面层：Streamlit 页面。只做展示与交互，业务逻辑一律调用 services。

依赖规则：只可 import services（及 core 的只读展示函数）；不得 import infra。
"""
