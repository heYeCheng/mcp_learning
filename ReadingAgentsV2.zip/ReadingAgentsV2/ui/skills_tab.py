"""技能页签：查看当前 Agent 挂载的技能（Skill 机制）。"""
import streamlit as st

from services import agent_service


def render(agent_id: str):
    st.subheader("技能（Skill 机制）")
    st.markdown("与 Trae 挂载技能等价：本 Agent 的 SKILL.md 会自动注入到系统提示词，"
                "并可用 read_skill 工具动态查阅。")
    prompt = agent_service.get_skill_prompt(agent_id)
    if not prompt:
        st.caption("（该 Agent 未配置技能）")
    else:
        st.markdown("**已注入的技能正文（预览）**")
        st.code(prompt, language="markdown")
    idx = agent_service.get_skill_index()
    if idx:
        st.divider()
        st.markdown("**可用技能索引（read_skill 可读）**")
        st.code(idx)
