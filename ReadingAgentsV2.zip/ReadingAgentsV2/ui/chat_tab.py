"""对话页签：聊天交互、工具调用事件、阅读快捷操作与可视化结果展示。"""
import os
import re

import streamlit as st

from services import agent_service, chat_service, library_service, memory_service, reading_service

_TOOL_HINTS = {
    "read_file": "解析文件并切块（大 PDF 需 1~3 分钟，请耐心等待）",
    "skim_book": "全书逐块压缩（每批一次 LLM 调用，整本书需 5~15 分钟）",
    "skim_chapter": "压缩指定块",
    "read_chapter": "聚合整章原文",
    "deep_dive": "调取原文以深入讲解",
    "start_viz_project": "创建可视化项目",
    "save_viz_page": "保存一页（单页生成中）",
    "finish_viz_project": "生成目录页",
    "get_book": "读取书目内容",
    "list_books": "查询资料库",
}


def _open_in_browser(path: str) -> None:
    """用系统默认浏览器/程序打开本地文件（Windows 下 os.startfile）。"""
    try:
        os.startfile(path)  # noqa: S606（Windows 专用，打开本地站点）
    except Exception:
        st.warning(f"自动打开失败，请手动用浏览器打开：{path}")


def _reading_panel(agent_id: str):
    """小R 专属：章目录 + 块进度 + 快捷操作。返回需要代发的消息文本（或 None）。"""
    books = library_service.list_books()
    if not books:
        return None
    last_id = st.session_state.get("last_book_id")
    idx = next((i for i, b in enumerate(books) if b["id"] == last_id), 0)
    idx = min(idx, len(books) - 1)
    sent = None
    with st.expander("📖 阅读进度与快捷操作", expanded=False):
        labels = [f"#{b['id']} 《{b['title']}》" for b in books]
        pick = st.selectbox("当前书目", labels, index=idx)
        book = books[labels.index(pick)]
        secs = book.get("sections") or []
        if secs:
            done = sum(1 for s in secs if (s.get("summary") or "").strip())
            st.progress(done / len(secs), text=f"已压缩阅读 {done}/{len(secs)} 块")

        # 章目录视图：块带 chapter 字段时可按章发起阅读
        chapters = reading_service.chapter_list(secs) if secs else []
        if len(chapters) > 1 or (chapters and chapters[0]["title"] != "(未分章)"):
            ch_labels = [
                f"{c['index']}. {c['title']}（{c['done']}/{c['blocks']} 块已读）"
                for c in chapters
            ]
            c1, c2 = st.columns([3, 1])
            pick_ch = c1.selectbox("章目录", ch_labels, key="qa_ch_pick")
            if c2.button("📖 读这章", key="qa_read_ch", use_container_width=True):
                sent = f"读第 {chapters[ch_labels.index(pick_ch)]['index']} 章"
        nxt = next(
            (i for i, s in enumerate(secs) if not (s.get("summary") or "").strip()), None
        )
        c1, c2 = st.columns(2)
        if c1.button("▶️ 读下一块", disabled=(nxt is None), key="qa_next_block"):
            sent = f"读第 {nxt} 块"
        if c2.button("📚 读完并总结全书", key="qa_skim_all"):
            sent = "从头读完并总结全书"
        if nxt is not None:
            st.caption(f"下一块：[{nxt}] {secs[nxt].get('heading') or '（无标题）'}")
        st.caption("也可以直接输入：读第 X 章 ｜ 读第 X 块 ｜ 深入讲讲第 X 块里的某个点 ｜ 总结全书")
    return sent


def _viz_cards(events: list) -> None:
    """finish_viz_project 的结果做成醒目卡片（不再藏在折叠面板里）。"""
    for i, ev in enumerate(events or []):
        if ev.get("tool") != "finish_viz_project":
            continue
        result = str(ev.get("result", ""))
        m = re.search(r"站点路径：(\S+)", result)
        if not m:
            continue
        path = m.group(1).strip()
        pages = re.search(r"共 (\d+) 页", result)
        n = pages.group(1) if pages else "?"
        st.success(f"🎨 可视化站点已生成（{n} 页）。也可以到「🎨 作品」页随时回看全部作品。")
        st.code(path)
        if st.button("📂 用浏览器打开", key=f"open_viz_{i}"):
            _open_in_browser(path)


def _mastery_panel(agent_id: str):
    """小B 专属：掌握度档案概览 + 一键出题巩固薄弱点。返回需要代发的消息（或 None）。"""
    rows = memory_service.list_mastery(agent_id)
    sent = None
    with st.expander("🎯 掌握度档案", expanded=False):
        if not rows:
            st.caption("还没有档案。先做几道题，我会记录你对各知识点的掌握程度。")
            return None
        weak = [r for r in rows if r["level"] == "weak"]
        if weak:
            topics = "、".join(r["topic"] for r in weak[:5])
            if st.button(f"🎯 出题巩固薄弱点（{len(weak)} 个）", use_container_width=True):
                sent = f"针对我的薄弱知识点出几道题帮我巩固：{topics}"
        for r in rows:
            icon = {"weak": "🔴", "familiar": "🟡", "mastered": "🟢"}.get(r["level"], "⚪")
            line = f"{icon} **{r['topic']}**"
            if r["book_title"]:
                line += f"（《{r['book_title']}》）"
            if r["note"]:
                line += f"：{r['note']}"
            st.markdown(line)
    return sent


def render(agent_id: str):
    agent = agent_service.get_profile(agent_id)
    st.subheader(f"与 {agent['name']} 对话")
    msgs = st.session_state.setdefault("chat_msgs", [])

    for role, text in msgs:
        with st.chat_message(role):
            st.markdown(text)

    quick = None
    if agent_id == "xiaor":
        quick = _reading_panel(agent_id)
    elif agent_id == "xiab":
        quick = _mastery_panel(agent_id)
    user_text = st.chat_input(f"和{agent['name']}说点什么…")
    text = (user_text or quick or "").strip()
    if not text:
        return
    msgs.append(("user", text))
    with st.chat_message("user"):
        st.markdown(text)

    with st.chat_message("assistant"):
        status = st.status("思考中…", expanded=True)
        placeholder = st.empty()

        buf = {"text": ""}  # 流式渲染缓冲

        def on_event(phase, tool, info):
            if phase == "delta":  # 正文增量：流式渲染
                buf["text"] += str(info)
                placeholder.markdown(buf["text"])
            elif phase == "start":
                hint = _TOOL_HINTS.get(tool, "")
                label = f"调用工具 {tool}…{('（' + hint + '）') if hint else ''}"
                status.update(label=label)
                status.write(f"▶ **{tool}** `{info}`")
            else:
                status.write(f"✔ **{tool}** 完成：{info}")

        def on_compress(done, total):
            status.update(label=f"内容压缩中… 第 {done}/{total} 块")

        try:
            reading_service.set_progress_cb(on_compress)
            res = chat_service.reply(agent_id, text, on_event=on_event)
        except Exception as exc:
            status.update(label="出错了", state="error", expanded=True)
            status.write(str(exc))
            reading_service.set_progress_cb(None)
            return
        reading_service.set_progress_cb(None)
        status.update(label="完成", state="complete", expanded=False)
        placeholder.markdown(res["answer"])

    # 记录最近解析的书目，供阅读进度面板默认选中
    for ev in res.get("events") or []:
        if ev.get("tool") == "read_file":
            m = re.search(r"id=(\d+)", str(ev.get("result", "")))
            if m:
                st.session_state["last_book_id"] = int(m.group(1))

    # 可视化结果醒目展示
    _viz_cards(res.get("events"))

    # 工具调用事件
    if res.get("events"):
        with st.expander(f"🔧 工具调用（{len(res['events'])} 次）", expanded=False):
            for ev in res["events"]:
                args = ", ".join(f"{k}={v}" for k, v in (ev.get("args") or {}).items())
                st.markdown(f"- **{ev['tool']}**({args})  \n结果：{str(ev.get('result'))[:300]}")

    # 记忆提炼反馈
    mem = res.get("memory") or {}
    if mem.get("added") or mem.get("pending"):
        st.info(f"🧠 本次已自动沉淀记忆 {mem.get('added', 0)} 条，新增待确认候选 "
                f"{mem.get('pending', 0)} 条，可在「记忆管理」页批量确认转长期。")

    msgs.append(("assistant", res["answer"]))
