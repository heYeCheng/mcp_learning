# 抽取骨架（Agent 骨架）

从「学习阅读团队」抽取出的**最小可运行骨架**，供公司在此基础上二次开发。
基于 **openai-agents SDK**（Agent / Runner / @function_tool）驱动，三个 Agent 各自独立启动，用 Streamlit 提供界面。

- **小R（阅读助手 📖）**：读取 txt / PDF / Word，按物理页切块、逐块泛读压缩、总结全书。
- **小V（可视化专家 🎨）**：确认风格、规划页面后，通过 openai-agents 的 **handoffs** 把逐页绘制移交给子 Agent「阿画」（drawer）接力完成；沉淀「书名 → 章节 → 内容」层级记忆。
- **小B（知识巩固导师 🧠）**：分层提问巩固知识；回答后自动维护「知识点 → 掌握程度」档案，薄弱点优先考察。

> 说明：本骨架不包含原团队已积累的记忆/书目数据，启动后是全新状态。

---

## 1. 快速启动（三步）

```bash
# ① 安装依赖
pip install -r requirements.txt

# ② 配置接口（OpenAI 兼容网关：火山方舟 / 公司内网网关均可）
copy .env.example .env
# 编辑 .env，填入公司的 BASE_URL / API_KEY / MODEL

# ③ 三个 Agent 各自独立启动（每个开一个终端）
streamlit run run_xiaor.py   # 小R  默认 http://localhost:8501
streamlit run run_xiaov.py   # 小V  默认 http://localhost:8502
streamlit run run_xiab.py    # 小B  默认 http://localhost:8503
```

> 想让端口固定，可加 `--server.port`：`streamlit run run_xiaov.py --server.port 8502`

---

## 2. 目录结构

```
ReadingAgentsV2/
├── run_xiaor.py / run_xiaov.py / run_xiab.py  # 三个独立入口（各自加载一个 Agent）
├── infra/
│   ├── config.py       # 配置：.env、数据目录、记忆分层时长
│   ├── llm.py          # 后台小任务的同步客户端（chat_json）+ tracing 开关
│   ├── memory.py       # 【三态记忆】短/中/长期 + 待确认 + 层级记忆 + 掌握度档案
│   ├── library.py      # 资料库（书目、章节、摘要）
│   ├── file_reader.py  # 文件解析（txt/md/docx/pdf 降级链）
│   ├── skill_loader.py # SKILL.md 扫描解析（技能注册表）
│   └── skills.py       # 【技能系统】技能注册表 + 提示词注入 + read_skill 工具
├── services/
│   ├── agents/         # 【Agent 定义，一人一文件】
│   │   ├── _base.py    #   模型工厂 + 动态 instructions 基座（人设/技能/记忆）
│   │   ├── runtime.py  #   运行引擎：Runner.run_streamed → RunOutcome（纯机制）
│   │   ├── xiaor.py / xiaob.py / xiaov.py   # 三位主 Agent
│   │   ├── drawer.py   #   阿画：小V 的子 Agent（handoffs 接力逐页绘制）
│   │   └── __init__.py #   注册表：META / build(agent_id)
│   ├── tools/          # 【@function_tool 工具按归属分包】
│   │   ├── base.py     #   RunDeps / AskUserInterrupt / truncate 公共契约
│   │   ├── library.py / reading.py / viz.py / knowledge.py
│   │   └── external.py #   外部工具扩展点（扫描 external_tools/ 自动注册）
│   ├── chat_service.py # 一轮对话的业务编排（存消息 → 跑 agent → 存回复 → 提炼记忆）
│   ├── reading_service.py   # 阅读服务（切块 → 压缩 → 总结）
│   ├── viz_service.py       # 小V 可视化项目（开项目 / 存页 / 收尾）
│   ├── memory_service.py    # 记忆 CRUD / 统计 / 待确认转正 + 记忆提炼
│   └── library_service.py / agent_service.py  # 面向界面的收口
├── ui/                 # Streamlit 界面（app.py 装配 6 个页签）
├── skills/             # 技能文档（SKILL.md），新增目录即自动生效
├── requirements.txt
└── .env.example
```

---

## 3. Skill 机制（为什么做这个 + 怎么加技能）

**背景**：本骨架通过 openai-agents 对接 OpenAI 兼容网关，模型默认收不到 skill 文件，
`infra/skills.py` 用一套轻量机制复刻了 Trae 的「执行技能」能力：

1. **技能注册表**：启动时扫描 `skills/` 目录，解析每个 `SKILL.md` 的 YAML frontmatter（`name` / `description` / `dependencies`）。
2. **提示词注入**：组装 Agent instructions 时，把该 Agent 的主技能 + 依赖技能正文拼进去——等价于 Trae 里挂载了 skill。
3. **read_skill 工具**：Agent 在对话中可随时用工具读取任意技能文档，动态「查阅技能」。

**给某位 Agent 加技能**：

```bash
mkdir skills/<agent_id>/my-skill   # 例如 skills/xiaov/sketch-style
```

在目录里放一个 `SKILL.md`：

```markdown
---
name: "my-skill"
description: "该技能做什么、何时触发"
dependencies: ["reading-visualizer"]   # 可选，依赖的其他技能名
---

# 技能正文

技能的具体步骤、规范、示例……（会整体注入 instructions）
```

重启该 Agent 的服务即可生效。共享技能放 `skills/shared/<name>/SKILL.md`，可被多个 Agent 依赖。

---

## 4. 三态记忆与掌握度

所有记忆保存时都带时间戳，按分层设置过期：

| 层级 | 有效期 | 来源 | 说明 |
|------|--------|------|------|
| 短期 `short` | **3 天** | AI 自动提炼（normal） | 对话要点、近期上下文 |
| 中期 `mid` | **3 个月** | AI 自动提炼（important） | 较重要的知识、偏好 |
| 长期 `long` | **永久** | 人工确认 / 手工强制 | 你确认过的关键记忆 |

### 长期记忆的两种写入方式
1. **待确认批量转正**：AI 每轮对话后提炼候选 → 进入「记忆管理 → 待确认」→ 你勾选 → **批量确认** → 转为长期。
   （例如小R 读完一个章节，系统会把可记忆的要点列为候选，你勾选确认即可。）
2. **手工强制记忆**：在「记忆管理 → 长期」页直接填类型+内容，**强制记住**（不走确认流程）。

### 小V 的层级记忆
小V 额外有「**书名/标题 → 章节 → 具体内容**」的层级记忆（`remember_structure` 工具或手工添加），
可在「记忆管理 → 层级记忆」页查看与维护，用于复用做过的可视化结构。

### 小B 的掌握度档案
小B 出题时先看你的掌握度档案（薄弱点优先考察、已掌握的不再重复问）；
你答完一组题，小B 用 `update_mastery` 工具更新对应知识点的掌握程度
（🔴 薄弱 / 🟡 一般 / 🟢 已掌握），并告诉你档案的变化。
档案可在「记忆管理 → 掌握度」页查看与删除，聊天页也有快捷面板可一键出题巩固薄弱点。

---

## 5. 外部工具扩展（可选）

预留了接入外部工具（公司 API / 数据库等）的能力，**当前未启用、不影响运行**：
想加时，在项目根目录建 `external_tools/` 目录，放一个 `.py` 文件，
定义 `SCHEMA`（OpenAI function schema）和 `handle(args) -> str`，重启即自动注册，
并挂到三位主 Agent 的工具列表（见 `services/tools/external.py`）。

```python
# external_tools/my_tool.py
SCHEMA = {"type": "function", "function": {
    "name": "get_current_time",
    "description": "获取当前时间",
    "parameters": {"type": "object", "properties": {}, "required": []},
}}
def handle(args):
    from datetime import datetime
    return f"当前时间：{datetime.now():%Y-%m-%d %H:%M:%S}"
```

---

## 6. 常见问题

- **启动报错 `未配置 API_KEY`**：复制 `.env.example` 为 `.env` 并填入公司的 BASE_URL / API_KEY / MODEL。
- **想换模型**：改 `.env` 的 `MODEL` 即可；三 Agent 共用同一接口。
- **数据存在哪**：运行时自动创建 `data/`（`memory.db` 记忆、`library.db` 资料库、`uploads/` 上传文件、`viz/` 小V 页面）。
- **记忆过期了会自动清理**：短期/中期到期后不再注入，并在下次提炼时清理。
