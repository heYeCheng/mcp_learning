"""小R（阅读助手）独立启动入口。

启动：streamlit run run_xiaor.py
"""
from ui.app import run

run("xiaor")
