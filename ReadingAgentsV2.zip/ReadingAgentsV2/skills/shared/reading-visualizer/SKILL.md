---
name: "reading-visualizer"
description: "可视化设计规范与设计子弹库：统一设计 Token、明暗双主题、SVG 图形化表达，内置 100 张色卡（color/）、50 种布局（display/）、100 个页面模板（templates/），供生成前与用户确认风格、生成时提取色值与版式。"
---

# 可视化设计规范与子弹库（reading-visualizer）

小V 生成的所有自包含 HTML 页面，必须遵循以下设计规范；生成前依据第 7 节的子弹库与用户确认风格。

## 1. 统一设计 Token（CSS 变量）

```css
:root{
  --bg:#f4f7fb; --surface:#ffffff; --ink:#16243a; --ink-soft:#3c5270; --muted:#687e9c;
  --line:#dde7f2; --accent:#2f7cf6; --accent-strong:#1b5fd9; --accent-soft:#e3eeff;
  --sans:"PingFang SC","Microsoft YaHei","Segoe UI",system-ui,sans-serif;
  --radius:16px; --shadow:0 6px 20px -8px rgba(18,35,58,.12);
}
[data-theme="dark"]{
  --bg:#0b1220; --surface:#131e30; --ink:#e6eefb; --ink-soft:#b6c7de; --muted:#8499b5;
  --line:#22334e; --accent:#4f94ff; --accent-strong:#6fa8ff; --accent-soft:#1b2c4d;
}
```

## 2. 明/暗双主题
- 默认跟随系统：`<html data-theme="dark">` 由 JS 检测 `prefers-color-scheme` 设置。
- 顶栏提供手动切换按钮，把选择存入 `localStorage`。
- 所有颜色必须用 CSS 变量，禁止写死颜色。

## 3. 页面骨架（所有页面必须包含）
- 顶栏：logo + 标题 + 右侧"切换主题/打印"按钮。
- 阅读进度条：顶部细条，随滚动变宽。
- 侧边目录：固定左侧，滚动时高亮当前章节；小屏（<980px）折叠为汉堡菜单。
- Hero 区：标题 + 一句话副标题。
- 回到顶部按钮、打印样式（@media print）。

## 4. SVG 图形化表达（重要）
- 图形优先：知识点之间关系用图形（节点/连线）表达，禁止大段纯文字。
- 标题 `<text>` 放 y=26 附近；所有主图 `<g transform="translate(x,y)">` 的 y 必须 > 40。
- viewBox 高度必须容纳所有元素，禁止溢出被裁剪。

## 5. 移动端自适应
- `@media(max-width:980px)`：侧边栏收进汉堡菜单、表格横向滚动、卡片单列。

## 6. 自包含
- 不引用外部 CDN / 字体 / 图片 / 脚本；保证离线可直接打开、可打印为 PDF。

## 7. 设计子弹库（色卡 / 布局 / 模板）

本技能目录下内置三类现成设计资源，供生成前向用户推荐风格、生成时提取色值与版式：

| 类别 | 目录 | 数量 | 内容 |
|---|---|---|---|
| 色卡 | `color/` | 100 | 每张一套完整配色（主色/辅助色/背景/文字，含色值），如 53_海洋深蓝、66_琥珀金、96_暗夜深色 |
| 布局 | `display/` | 50 | 页面骨架版式，如 01_居中单栏、30_时间线、17_仪表盘网格、09_瀑布流 |
| 模板 | `templates/` | 100 | 完整页面示例，如 01_读书总结、04_思维导图、14_金句语录墙、05_时间线 |

### 用法（配合 read_skill 工具，一次读一个文件）
1. **拿清单**：`read_skill("shared/reading-visualizer/color/INDEX.md")` → 该类全部文件名列表（display、templates 同理）。INDEX 是纯文件名清单，直接据此向用户推荐。
2. **读详情**：选定后 `read_skill("shared/reading-visualizer/color/53_海洋深蓝.html")` → 从中提取色值填入第 1 节的 CSS 变量。布局/模板 HTML 较大，读取返回前 14000 字符已含头部样式与版式要点，足够参考。
3. **推荐纪律**：每次向用户推荐 2-3 个色卡 + 1-2 个布局，各附一句话理由；模板仅在内容类型匹配时提及。

### 与第 1 节 Token 的关系
- 用户选定色卡后，把色卡色值替换 `:root` 中 `--bg / --surface / --ink / --accent` 等变量的值；骨架、SVG、自包含等结构规范仍然全部适用。
- 色卡若为深色系（如 96_暗夜深色），可直接以深色为默认主题；浅色系则维持默认浅色。
