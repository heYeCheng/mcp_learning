import pandas as pd
import numpy as np
from itertools import pairwise


def calc_woe(df: pd.DataFrame, col: str, target: str, smooth: float = 0.5, bins=None):
    """
    计算单特征的 WOE 和 IV。

    bins 参数支持自定义分箱/归组：
      - 数值型: 传入分箱边界列表，如 [0, 30, 50, 100]
      - 分类型: 传入旧→新映射字典，如 {"高中": "低学历", "本科": "高学历"}
    """
    if bins is not None:
        if isinstance(bins, dict):
            df["_bin"] = df[col].map(bins).fillna("其他")
        else:
            df["_bin"] = pd.cut(df[col], bins=bins, include_lowest=True)
    elif pd.api.types.is_numeric_dtype(df[col]):
        df["_bin"] = pd.qcut(df[col], q=min(10, df[col].nunique()), duplicates="drop")
    else:
        df["_bin"] = df[col]
    grp = df.groupby("_bin", observed=False)[target].agg(bad="sum", total="count")
    grp["good"] = grp["total"] - grp["bad"]
    grp["badrate"] = grp["bad"] / grp["total"]
    tb, tg = grp["bad"].sum(), grp["good"].sum()
    n = len(grp)
    grp["p_bad"] = (grp["bad"] + smooth) / (tb + smooth * n)
    grp["p_good"] = (grp["good"] + smooth) / (tg + smooth * n)
    grp["woe"] = np.log(grp["p_good"] / grp["p_bad"])
    grp["iv"] = (grp["p_good"] - grp["p_bad"]) * grp["woe"]
    grp.index.name = col
    return grp[["total", "good", "bad", "badrate", "p_good", "p_bad", "woe", "iv"]], grp["iv"].sum()


# ==================== 自动最优分箱 ====================


def _check_monotonic(woe_series: pd.Series) -> str:
    """检查 WOE 序列的单调性，返回 '递增' / '递减' / '非单调'"""
    diffs = np.diff(woe_series)
    if (diffs >= 0).all():
        return "递增"
    elif (diffs <= 0).all():
        return "递减"
    return "非单调"


def _merge_adjacent_bins(bin_edges: list, merge_idx: int) -> list:
    """合并相邻两个箱，返回新的 bin_edges"""
    edges = list(bin_edges)
    del edges[merge_idx + 1]
    return edges


def _auto_numerical_bins(df: pd.DataFrame, col: str, target: str,
                         min_bad: int = 10, max_bins: int = 7) -> list:
    """
    对数值型变量自动寻找最优单调分箱（贪心合并法）。
    1. 初始分 20 个细粒度等频箱
    2. 从违反单调性的位置开始合并相邻箱
    3. 合并 bad < min_bad 的箱
    4. 控制最终箱数 3~7
    """
    n_unique = df[col].nunique()
    init_bins = min(20, n_unique)
    if init_bins < 3:
        return sorted(df[col].dropna().unique())

    try:
        df["_bin_tmp"], edges = pd.qcut(df[col], q=init_bins, duplicates="drop", retbins=True)
    except ValueError:
        return sorted(df[col].dropna().quantile(np.linspace(0, 1, 5)).unique())

    edges = list(edges)

    while len(edges) > 3:
        grp = df.groupby("_bin_tmp", observed=False)[target].agg(bad="sum", total="count")
        grp["good"] = grp["total"] - grp["bad"]
        tb, tg = grp["bad"].sum(), grp["good"].sum()
        n = len(grp)
        grp["p_bad"] = (grp["bad"] + 0.5) / (tb + 0.5 * n)
        grp["p_good"] = (grp["good"] + 0.5) / (tg + 0.5 * n)
        grp["woe"] = np.log(grp["p_good"] / grp["p_bad"])
        woe_vals = grp["woe"].values

        monotonic = _check_monotonic(woe_vals)
        diffs = np.diff(woe_vals)
        merge_candidates = []

        for i in range(len(grp)):
            if grp["bad"].iloc[i] < min_bad:
                merge_candidates.append(i)

        if monotonic == "递增":
            merge_candidates.extend(i for i, d in enumerate(diffs) if d < 0)
        elif monotonic == "递减":
            merge_candidates.extend(i for i, d in enumerate(diffs) if d > 0)

        if not merge_candidates:
            if len(edges) <= max_bins + 1:
                break
            woe_diffs = [abs(woe_vals[i] - woe_vals[i + 1]) for i in range(len(woe_vals) - 1)]
            merge_idx = int(np.argmin(woe_diffs))
        else:
            merge_idx = merge_candidates[0]

        edges = _merge_adjacent_bins(edges, merge_idx)
        try:
            df["_bin_tmp"] = pd.cut(df[col], bins=edges, include_lowest=True)
        except Exception:
            break

    df.drop(columns=["_bin_tmp"], inplace=True)
    return edges


def _auto_categorical_bins(df: pd.DataFrame, col: str, target: str,
                           min_bad: int = 10) -> dict:
    """对分类型变量自动归组：bad < min_bad 的类别合并到其他"""
    grp = df.groupby(col)[target].agg(bad="sum", total="count")
    grp["badrate"] = grp["bad"] / grp["total"]

    mapping = {}
    other_cats = []
    for cat, row in grp.iterrows():
        if pd.isna(cat):
            continue
        if row["bad"] < min_bad or row["total"] < min_bad * 2:
            other_cats.append(cat)
        else:
            mapping[cat] = cat

    if other_cats:
        mapping.update({c: "其他" for c in other_cats})

    if len(set(mapping.values())) == 1:
        best_cat = grp["badrate"].idxmax()
        mapping = {c: (c if c == best_cat else "其他") for c in grp.index if not pd.isna(c)}

    return mapping


def auto_woe_binning(df: pd.DataFrame, cols: list[str] = None, target: str = "Default",
                     min_bad: int = 10, max_bins: int = 7, verbose: bool = True):
    """
    对指定变量列表自动进行最优 WOE 分箱，内部调用 calc_woe 计算。

    参数:
        df: 输入数据
        cols: 变量列表，为 None 时自动选择所有非 target 列
        target: 目标变量列名
        min_bad: 每箱最小坏样本数
        max_bins: 最大分箱数
        verbose: 是否打印进度

    返回:
        {变量名: {"detail": 分箱明细表, "iv": IV值, "bins": 分箱参数,
                  "monotonic": 单调性, "type": "numerical/categorical"}}
    """
    if cols is None:
        cols = [c for c in df.columns if c != target and c != "LoanID"]

    results = {}
    for col in cols:
        if col == target or col not in df.columns:
            continue

        if pd.api.types.is_numeric_dtype(df[col]):
            bin_param = _auto_numerical_bins(df, col, target, min_bad, max_bins)
            col_type = "numerical"
        else:
            bin_param = _auto_categorical_bins(df, col, target, min_bad)
            col_type = "categorical"

        detail, iv = calc_woe(df, col, target, bins=bin_param)
        mono_str = _check_monotonic(detail["woe"]) if col_type == "numerical" else "N/A"

        results[col] = {
            "detail": detail,
            "iv": iv,
            "bins": bin_param,
            "monotonic": mono_str,
            "type": col_type,
        }

        if verbose:
            print(f"  [{col_type[:4]}] {col:<20} IV={iv:.4f}  bins={len(detail)}  monotonic={mono_str}")

    return results


# ==================== WOE 编码 ====================


def woe_encode(df: pd.DataFrame, binning_results: dict,
               features: list[str] = None) -> pd.DataFrame:
    """
    将原始特征值替换为 WOE 值。

    参数:
        df: 原始数据
        binning_results: auto_woe_binning 或 review_auto_binning 的结果
        features: 要编码的特征列表，None 表示全部

    返回:
        新 DataFrame，指定特征列已替换为 WOE 值，列名加 _woe 后缀
    """
    if features is None:
        features = list(binning_results.keys())

    df_out = df.copy()
    for col in features:
        if col not in binning_results:
            continue
        res = binning_results[col]
        detail = res["detail"]
        woe_map = detail["woe"].to_dict()  # {bin_label: woe_value}

        if res["type"] == "numerical":
            edges = res["bins"]
            df_out[f"{col}_woe"] = pd.cut(df[col], bins=edges, include_lowest=True).map(woe_map)
        else:
            mapping = res["bins"]
            df_out[f"{col}_woe"] = df[col].map(mapping).fillna(df[col]).map(woe_map)

    return df_out