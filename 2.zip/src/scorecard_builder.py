"""
评分卡打分转换
==============
将模型预测概率转换为标准评分卡分数（PDO 方法），
生成评分卡打分表（各变量分箱→得分映射）。
"""

import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

ROOT_DIR = Path(__file__).parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from scorecard.src.woe_calculator import calc_woe

warnings.filterwarnings("ignore")


def prob_to_score(p, factor, offset):
    """将违约概率 p 转换为评分卡分数。"""
    odds = (1 - p) / (p + 1e-12)  # good/bad 比率
    return offset + factor * np.log(odds)


def build_scorecard(
    df: pd.DataFrame,
    refined_binning: dict,
    model_coef: dict,
    intercept: float,
    base_score: float = 600,
    base_odds: float = 50,
    pdo: float = 20,
    target: str = "Default",
) -> dict:
    """
    构建评分卡打分表。

    核心公式:
      Factor = PDO / ln(2)
      Offset = BaseScore - Factor × ln(BaseOdds)
      Score = Offset + Factor × ln(odds)
            = (Offset + Factor × intercept) + Σ(Factor × coef_i × WOE_i)
            = Base + Σ(Points_i)

    参数:
        df: 原始数据
        refined_binning: review_auto_binning 的结果
        model_coef: {特征名: 系数值}，如 {"Age_woe": -0.45}
        intercept: 模型截距
        base_score: 基准分数（当 odds = base_odds 时的分数）
        base_odds: 基准 odds（good/bad 比率）
        pdo: Points to Double Odds（odds 翻倍需要增加的分数）
        target: 目标变量列名

    返回:
        {
            "scorecard_table": 评分卡打分表 DataFrame,
            "params": {factor, offset, base_score, base_odds, pdo},
            "score_stats": 分数分布统计,
        }
    """
    # 1. 计算 Factor 和 Offset
    factor = pdo / np.log(2)
    offset = base_score - factor * np.log(base_odds)

    print(f"\n{'='*55}")
    print(f"  评分卡参数")
    print(f"{'='*55}")
    print(f"  BaseScore = {base_score}  (odds={base_odds}:1)")
    print(f"  PDO       = {pdo}")
    print(f"  Factor    = {factor:.4f}")
    print(f"  Offset    = {offset:.4f}")

    # 2. 构建评分卡表
    n_features = len(model_coef)
    base = offset + factor * intercept  # 基础分
    print(f"  基础分    = {base:.2f}")

    rows = []
    for col_woe, coef in model_coef.items():
        orig_col = col_woe.replace("_woe", "")
        if orig_col not in refined_binning:
            continue
        res = refined_binning[orig_col]
        detail = res["detail"]

        for bin_label, row in detail.iterrows():
            woe = row["woe"]
            # 单个分箱的贡献分 = Factor × coef × WOE
            points = factor * coef * woe
            rows.append({
                "变量": orig_col,
                "分箱": str(bin_label),
                "WOE": round(woe, 4),
                "系数": round(coef, 4),
                "得分": round(points, 2),
            })

    scorecard_df = pd.DataFrame(rows)
    total_points_var = scorecard_df.groupby("变量")["得分"].sum()
    print(f"\n  各变量得分贡献汇总:")
    for var, pts in total_points_var.items():
        print(f"    {var:<20} {pts:>8.2f} 分")
    print(f"  基础分                 {base:>8.2f} 分")
    print(f"  总分范围: {scorecard_df['得分'].sum() + base:.2f}")

    # 3. 计算全量样本的分数分布
    # 先用 WOE 编码算出每个样本的 ln(odds)，再转分数
    df_score = df.copy()
    df_score["_ln_odds"] = intercept  # 从截距开始
    for col_woe, coef in model_coef.items():
        orig_col = col_woe.replace("_woe", "")
        if orig_col not in refined_binning:
            continue
        res = refined_binning[orig_col]
        detail = res["detail"]
        woe_map = detail["woe"].to_dict()

        if res["type"] == "numerical":
            edges = res["bins"]
            df_score[f"_{orig_col}_woe"] = pd.cut(
                df[orig_col], bins=edges, include_lowest=True
            ).map(woe_map).astype(float)
        else:
            mapping = res["bins"]
            df_score[f"_{orig_col}_woe"] = (
                df[orig_col].map(mapping).fillna(df[orig_col]).map(woe_map)
            ).astype(float)

        df_score["_ln_odds"] += coef * df_score[f"_{orig_col}_woe"].fillna(0)

    df_score["score"] = offset + factor * df_score["_ln_odds"]
    df_score["score"] = df_score["score"].round(0).astype(int)
    df_score["is_bad"] = df[target]

    # 4. 按分数段统计
    quantiles = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    score_bins = df_score["score"].quantile(quantiles).unique()
    score_bins = sorted(score_bins)
    if len(score_bins) > 1:
        df_score["_score_bin"] = pd.cut(
            df_score["score"], bins=score_bins, include_lowest=True
        )
        stats = (
            df_score.groupby("_score_bin", observed=False)
            .agg(
                total=("is_bad", "count"),
                bad=("is_bad", "sum"),
            )
            .reset_index()
        )
        stats["good"] = stats["total"] - stats["bad"]
        stats["badrate"] = stats["bad"] / stats["total"]
        stats["累计占比"] = stats["total"].cumsum() / stats["total"].sum()
        # 累计坏样本占比
        stats["累计坏占比"] = stats["bad"].cumsum() / stats["bad"].sum()
        stats["评分区间"] = stats["_score_bin"].astype(str)
        stats = stats[["评分区间", "total", "good", "bad", "badrate", "累计占比", "累计坏占比"]]
    else:
        stats = pd.DataFrame()

    print(f"\n  评分分布（按十分位）:")
    for _, row in stats.iterrows():
        print(f"    {row['评分区间']:<25} 样本={row['total']:>6}  badrate={row['badrate']:.2%}")

    return {
        "scorecard_table": scorecard_df,
        "params": {
            "factor": round(factor, 4),
            "offset": round(offset, 4),
            "base_score": base_score,
            "base_odds": base_odds,
            "pdo": pdo,
            "base": round(base, 2),
        },
        "score_stats": stats,
        "scores": df_score[["score", "is_bad"]],
    }


def print_scorecard(scorecard_result: dict):
    """打印完整的评分卡打分表"""
    table = scorecard_result["scorecard_table"]
    params = scorecard_result["params"]

    print(f"\n{'='*60}")
    print(f"  评分卡打分表")
    print(f"  BaseScore={params['base_score']}, PDO={params['pdo']}, "
          f"BaseOdds={params['base_odds']}:1")
    print(f"  基础分: {params['base']:.2f}")
    print(f"{'='*60}")

    for var in table["变量"].unique():
        var_rows = table[table["变量"] == var]
        print(f"\n  {var}:")
        print(f"  {'分箱':<35} {'WOE':>8} {'系数':>8} {'得分':>8}")
        print(f"  {'-'*59}")
        for _, row in var_rows.iterrows():
            bin_str = str(row["分箱"])[:33]
            print(f"  {bin_str:<35} {row['WOE']:>8.4f} {row['系数']:>8.4f} {row['得分']:>8.2f}")
        print(f"  {'小计':>35} {'':>8} {'':>8} {var_rows['得分'].sum():>8.2f}")

    print(f"\n  {'基础分':>35} {'':>8} {'':>8} {params['base']:>8.2f}")
    print(f"  {'总分':>35} {'':>8} {'':>8} {table['得分'].sum() + params['base']:>8.2f}")


if __name__ == "__main__":
    # 独立运行示例
    MODEL_DIR = Path(__file__).parent.parent / "models"
    DATA_PATH = Path(__file__).parent.parent / "Loan_default.csv"

    # 加载模型元信息
    meta_path = MODEL_DIR / "model_meta.json"
    if not meta_path.exists():
        print("❌ 请先运行 train_scorecard.py")
        exit()

    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    # 加载分箱参数
    bin_path = MODEL_DIR / "bin_mapping_refined.json"
    if not bin_path.exists():
        print("❌ 分箱参数不存在")
        exit()

    from scorecard.src.binning_reviewer import review_auto_binning
    from scorecard.src.woe_calculator import auto_woe_binning

    df = pd.read_csv(DATA_PATH)
    auto_results = auto_woe_binning(df, verbose=False)
    refined = review_auto_binning(df, auto_results, verbose=False)

    result = build_scorecard(
        df, refined, meta["coef"], meta["intercept"],
        base_score=600, base_odds=50, pdo=20,
    )
    print_scorecard(result)