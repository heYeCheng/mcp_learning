"""
评分卡开发 Agent（LLM 驱动版）
==============================
通过自然语言与 LLM 交互，自动调用评分卡流水线的各个工具。
用法：用户说"帮我建模"、"把年龄每5岁分一组"等，LLM 理解意图并自动执行。
"""

import json
import os
import shutil
import sys
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from dotenv import load_dotenv
from openai import OpenAI
from sklearn.model_selection import train_test_split

# 确保项目根目录在 sys.path 中
ROOT_DIR = Path(__file__).parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from scorecard.src.woe_calculator import calc_woe, auto_woe_binning, woe_encode
from scorecard.src.binning_reviewer import review_auto_binning
from scorecard.src.model_reviewer import train_with_coef_review
from scorecard.src.evaluate_model import evaluate_model
from scorecard.src.scorecard_builder import build_scorecard

load_dotenv(ROOT_DIR / ".env")
warnings.filterwarnings("ignore")

API_KEY = os.getenv("DOUBAO_API_KEY", "")
BASE_URL = os.getenv("DOUBAO_BASE_URL", "https://ark.cn-beijing.volces.com/api/v3")
MODEL = os.getenv("DOUBAO_MODEL", "")


# ==================== 评分卡 Agent ====================

class ScorecardAgent:
    """
    LLM 驱动的评分卡开发 Agent。
    用户用自然语言提出需求，LLM 自动选择并调用工具完成。
    """

    def __init__(self):
        self.client: OpenAI = None
        self.df: pd.DataFrame = None
        self.data_path: Path = None
        self.target = "Default"
        self.base_score = 600
        self.base_odds = 50
        self.pdo = 20

        # 中间状态
        self.refined: dict = None
        self.df_woe: pd.DataFrame = None
        self.woe_cols: list[str] = []
        self.model = None
        self.final_features: list[str] = []
        self.dropped_features: list[str] = []
        self.train_result: dict = None
        self.train_metrics: dict = None
        self.test_metrics: dict = None
        self.scorecard_result: dict = None
        self.X_train = self.X_test = None
        self.y_train = self.y_test = None

        # 路径
        self.model_dir: Path = None
        self.result_dir: Path = None

    # ========== 工具函数（供 LLM 调用，返回字符串） ==========

    def _load_data(self, file_path: str) -> str:
        """加载 CSV 数据"""
        p = Path(file_path)
        if not p.exists():
            return f"❌ 文件不存在: {file_path}"
        self.data_path = p
        self.df = pd.read_csv(p)
        self.model_dir = p.parent / "models"
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.result_dir = p.parent / "results"
        self.result_dir.mkdir(parents=True, exist_ok=True)
        n_cols = len(self.df.columns)
        badrate = self.df[self.target].mean()
        return (f"✅ 数据加载完成: {self.df.shape[0]} 行, {n_cols} 列\n"
                f"   目标列 '{self.target}' 违约率: {badrate:.2%}\n"
                f"   列名: {list(self.df.columns)}")

    def _run_binning(self, min_bad: int = 10, max_bins: int = 7) -> str:
        """自动分箱 + React 审查"""
        if self.df is None:
            return "❌ 请先加载数据"
        auto_results = auto_woe_binning(self.df, target=self.target,
                                        min_bad=min_bad, max_bins=max_bins, verbose=False)
        self.refined = review_auto_binning(self.df, auto_results, target=self.target,
                                           min_bad=min_bad, verbose=False)
        n_pass = sum(1 for r in self.refined.values() if r["passed"])
        lines = [f"✅ 分箱完成: {n_pass}/{len(self.refined)} 个特征通过审查"]
        lines.append(f"\n📊 IV 排名:")
        ivs = sorted([(k, v["iv"]) for k, v in self.refined.items()],
                     key=lambda x: -x[1])
        for rank, (name, iv) in enumerate(ivs[:10], 1):
            res = self.refined[name]
            lines.append(f"  {rank}. {name:<20} IV={iv:.4f}  "
                         f"bins={len(res['detail'])}  type={res['type']}  "
                         f"monotonic={res.get('monotonic','N/A')}")
        if len(ivs) > 10:
            lines.append(f"  ... 共 {len(ivs)} 个特征")
        return "\n".join(lines)

    def _update_binning(self, variable: str, method: str = "equal_width",
                        step: int = None, edges: list = None,
                        mapping: dict = None) -> str:
        """
        更新指定变量的分箱规则。
        method: 'equal_width'=等宽, 'quantile'=等频, 'manual'=手动指定边界/mapping
        """
        if self.df is None:
            return "❌ 请先加载数据"
        if variable not in self.df.columns:
            return f"❌ 变量 '{variable}' 不存在。可用: {list(self.df.columns)}"

        col = variable
        if method == "equal_width" and step is not None:
            lo, hi = self.df[col].min(), self.df[col].max()
            new_bins = list(np.arange(np.floor(lo / step) * step, hi + step, step))
            new_bins[0] = lo - 0.001
            new_bins[-1] = hi + 0.001
        elif method == "manual" and edges is not None:
            new_bins = edges
        elif method == "manual" and mapping is not None:
            new_bins = mapping
        else:
            return (f"❌ 不支持的 method/参数组合。method={method}, "
                    f"step={step}, edges={edges}, mapping={mapping}")

        detail, iv = calc_woe(self.df.copy(), col, self.target, bins=new_bins)
        from scorecard.src.woe_calculator import _check_monotonic
        mono = _check_monotonic(detail["woe"]) if pd.api.types.is_numeric_dtype(self.df[col]) else "N/A"
        col_type = "numerical" if isinstance(new_bins, list) else "categorical"

        self.refined[col] = {
            "detail": detail, "iv": iv, "bins": new_bins,
            "monotonic": mono, "type": col_type, "passed": True,
        }

        lines = [f"✅ {col} 分箱已更新 (IV={iv:.4f}, bins={len(detail)}, monotonic={mono})"]
        lines.append(str(detail[["total", "bad", "badrate", "woe", "iv"]]))
        return "\n".join(lines)

    def _show_binning(self, variable: str) -> str:
        """查看某个变量的分箱详情"""
        if self.refined is None:
            return "❌ 请先执行分箱"
        if variable not in self.refined:
            avail = list(self.refined.keys())
            return f"❌ 变量 '{variable}' 不在分箱结果中。可用: {avail}"
        res = self.refined[variable]
        detail = res["detail"]
        return (f"📊 {variable}  类型={res['type']}  IV={res['iv']:.4f}  "
                f"bins={len(detail)}  monotonic={res.get('monotonic','N/A')}\n\n"
                f"{detail[['total','bad','badrate','woe','iv']].to_string()}")

    def _train_model(self, expected_sign: str = "negative",
                     max_rounds: int = 10, test_size: float = 0.3) -> str:
        """WOE编码 + React 系数审查训练"""
        if self.refined is None:
            return "❌ 请先执行分箱"
        features = list(self.refined.keys())
        self.df_woe = woe_encode(self.df, self.refined, features=features)
        self.woe_cols = [f"{c}_woe" for c in features]

        X = self.df_woe[self.woe_cols].fillna(0)
        y = self.df[self.target]
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        self.train_result = train_with_coef_review(
            self.X_train, self.y_train, self.X_test, self.y_test,
            expected_sign=expected_sign, max_rounds=max_rounds, verbose=False,
        )
        self.model = self.train_result["model"]
        self.final_features = self.train_result["features"]
        self.dropped_features = self.train_result["dropped"]

        lines = [
            f"✅ 模型训练完成: {len(self.final_features)} 个特征",
            f"   train_acc={self.train_result['train_score']:.4f}  "
            f"test_acc={self.train_result['test_score']:.4f}",
        ]
        if self.dropped_features:
            lines.append(f"   🗑️  已剔除: {self.dropped_features}")
        coefs = self.train_result["coef"]
        lines.append("\n📊 系数:")
        for k, v in sorted(coefs.items(), key=lambda x: x[1]):
            lines.append(f"   {k:<25} {v:+.4f}")
        return "\n".join(lines)

    def _evaluate(self) -> str:
        """评估模型区分度"""
        if self.model is None:
            return "❌ 请先训练模型"
        train_df = self.X_train[self.final_features].copy()
        train_df[self.target] = self.y_train
        test_df = self.X_test[self.final_features].copy()
        test_df[self.target] = self.y_test

        self.train_metrics = evaluate_model(train_df, self.model, self.final_features, "训练集")
        self.test_metrics = evaluate_model(test_df, self.model, self.final_features, "测试集")

        tm = self.test_metrics
        return (f"📊 测试集评估:\n"
                f"   AUC={tm['auc']:.4f}  GINI={tm['gini']:.4f}  "
                f"KS={tm['ks']:.4f}")

    def _build_scorecard(self, base_score: int = 600,
                         base_odds: int = 50, pdo: int = 20) -> str:
        """构建评分卡打分表"""
        if self.model is None:
            return "❌ 请先训练模型"
        if self.refined is None:
            return "❌ 请先执行分箱"

        coef_dict = dict(zip(self.final_features, self.model.coef_[0]))
        self.scorecard_result = build_scorecard(
            self.df, self.refined, coef_dict, float(self.model.intercept_[0]),
            base_score=base_score, base_odds=base_odds, pdo=pdo,
            target=self.target,
        )
        params = self.scorecard_result["params"]
        total_pts = self.scorecard_result["scorecard_table"]["得分"].sum()
        return (f"✅ 评分卡构建完成\n"
                f"   BaseScore={params['base_score']}, PDO={params['pdo']}, "
                f"BaseOdds={params['base_odds']}:1\n"
                f"   基础分={params['base']:.2f}, 总分范围≈{total_pts + params['base']:.0f}")

    def _save(self) -> str:
        """保存模型及所有结果"""
        if self.model is None:
            return "❌ 请先训练模型"
        self.model_dir.mkdir(parents=True, exist_ok=True)

        joblib.dump(self.model, self.model_dir / "logistic_regression.pkl")
        meta = {
            "features": self.final_features,
            "coef": self.train_result["coef"],
            "intercept": self.train_result["intercept"],
            "dropped": self.dropped_features,
            "scorecard_params": self.scorecard_result["params"] if self.scorecard_result else {},
        }
        with open(self.model_dir / "model_meta.json", "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        if self.train_metrics and self.test_metrics:
            with open(self.model_dir / "evaluation.json", "w", encoding="utf-8") as f:
                json.dump({"train": self.train_metrics, "test": self.test_metrics},
                          f, ensure_ascii=False, indent=2)
        if self.scorecard_result:
            self.scorecard_result["scorecard_table"].to_csv(
                self.model_dir / "scorecard_table.csv", index=False, encoding="utf-8-sig")
            self.scorecard_result["score_stats"].to_csv(
                self.model_dir / "score_distribution.csv", index=False, encoding="utf-8-sig")
        bin_src = self.result_dir / "bin_mapping_refined.json"
        if bin_src.exists():
            shutil.copy2(bin_src, self.model_dir / "bin_mapping_refined.json")

        return f"✅ 模型已保存至 {self.model_dir}"

    def _status(self) -> str:
        """查看当前状态"""
        lines = ["📊 评分卡 Agent 状态"]
        if self.df is not None:
            lines.append(f"   数据: {self.df.shape[0]} 行, {self.df.shape[1]} 列, "
                         f"违约率={self.df[self.target].mean():.2%}")
        else:
            lines.append("   数据: ❌ 未加载")
        lines.append(f"   分箱: {'✅' if self.refined else '❌'}")
        lines.append(f"   模型: {'✅' if self.model else '❌'}")
        lines.append(f"   评估: {'✅' if self.test_metrics else '❌'}")
        lines.append(f"   评分卡: {'✅' if self.scorecard_result else '❌'}")
        if self.test_metrics:
            lines.append(f"   GINI={self.test_metrics['gini']:.4f}  "
                         f"KS={self.test_metrics['ks']:.4f}")
        if self.model and self.final_features:
            lines.append(f"   特征: {len(self.final_features)} 个")
        return "\n".join(lines)

    def _run_all(self) -> str:
        """一键执行全流程"""
        parts = []
        parts.append(self._load_data(str(self.data_path)))
        parts.append(self._run_binning())
        parts.append(self._train_model())
        parts.append(self._evaluate())
        parts.append(self._build_scorecard())
        parts.append(self._save())
        return "\n\n".join(parts)


# ==================== Function Calling 工具定义 ====================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "load_data",
            "description": "加载CSV数据文件，开始评分卡建模。必须先调用此工具。",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "CSV文件路径，如 'scorecard/Loan_default.csv'",
                    }
                },
                "required": ["file_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_binning",
            "description": "对所有变量进行自动最优WOE分箱，并执行React审查（边界规整、bad>=10、单调性、3-7箱）。",
            "parameters": {
                "type": "object",
                "properties": {
                    "min_bad": {
                        "type": "integer",
                        "description": "每箱最少坏样本数，默认10",
                    },
                    "max_bins": {
                        "type": "integer",
                        "description": "最大分箱数，默认7",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_binning",
            "description": "更新指定变量的分箱规则。例如：把年龄改成每5岁一组，或手动指定分箱边界、分类映射。",
            "parameters": {
                "type": "object",
                "properties": {
                    "variable": {
                        "type": "string",
                        "description": "要更新的变量名，如 'Age'",
                    },
                    "method": {
                        "type": "string",
                        "enum": ["equal_width", "quantile", "manual"],
                        "description": "分箱方法: equal_width=等宽(如每5岁), manual=手动指定",
                    },
                    "step": {
                        "type": "integer",
                        "description": "等宽步长，如 Age 每5岁一组则填5",
                    },
                    "edges": {
                        "type": "array",
                        "items": {"type": "number"},
                        "description": "手动指定分箱边界，如 [0, 25, 35, 50, 100]",
                    },
                    "mapping": {
                        "type": "object",
                        "description": "分类型变量的归组映射，如 {'高中':'低学历','本科':'高学历'}",
                    },
                },
                "required": ["variable", "method"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "show_binning",
            "description": "查看某个变量的分箱详情（各箱样本数、bad、badrate、WOE、IV等）。",
            "parameters": {
                "type": "object",
                "properties": {
                    "variable": {
                        "type": "string",
                        "description": "变量名，如 'Age'",
                    }
                },
                "required": ["variable"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "train_model",
            "description": "WOE编码 + 逻辑回归训练 + React系数审查。WOE评分卡系数应全部为负。",
            "parameters": {
                "type": "object",
                "properties": {
                    "expected_sign": {
                        "type": "string",
                        "enum": ["negative", "positive"],
                        "description": "系数期望方向: negative=全部为负(WOE评分卡), positive=全部为正",
                    },
                    "max_rounds": {
                        "type": "integer",
                        "description": "最大系数审查轮次，默认10",
                    },
                    "test_size": {
                        "type": "number",
                        "description": "测试集比例，默认0.3",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "evaluate",
            "description": "评估模型区分度，输出AUC/GINI/KS指标。",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "build_scorecard",
            "description": "构建评分卡打分表，将模型输出转换为标准评分卡分数（PDO方法）。",
            "parameters": {
                "type": "object",
                "properties": {
                    "base_score": {
                        "type": "integer",
                        "description": "基准分，默认600",
                    },
                    "base_odds": {
                        "type": "integer",
                        "description": "基准odds，默认50",
                    },
                    "pdo": {
                        "type": "integer",
                        "description": "PDO(Points to Double Odds)，默认20",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "save",
            "description": "保存模型、评分卡、评估结果等全部文件到models目录。",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "status",
            "description": "查看当前评分卡开发进度和状态。",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_all",
            "description": "一键执行全流程：加载数据→分箱→训练→评估→评分卡→保存。",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
]

# 工具名 → 方法映射
TOOL_MAP = {
    "load_data": "_load_data",
    "run_binning": "_run_binning",
    "update_binning": "_update_binning",
    "show_binning": "_show_binning",
    "train_model": "_train_model",
    "evaluate": "_evaluate",
    "build_scorecard": "_build_scorecard",
    "save": "_save",
    "status": "_status",
    "run_all": "_run_all",
}


# ==================== 命令行入口 ====================

def init_client() -> OpenAI:
    if not API_KEY:
        print("❌ 未设置 API Key！请检查 .env 文件")
        exit(1)
    return OpenAI(api_key=API_KEY, base_url=BASE_URL)


def run_tool_call(agent: ScorecardAgent, tool_call) -> str:
    func_name = tool_call.function.name
    func_args = json.loads(tool_call.function.arguments)
    print(f"\n  🛠️  调用工具: {func_name}({json.dumps(func_args, ensure_ascii=False)})")

    method_name = TOOL_MAP.get(func_name)
    if not method_name:
        return f"未知工具: {func_name}"
    try:
        method = getattr(agent, method_name)
        result = method(**func_args)
        return result
    except Exception as e:
        return f"❌ 工具执行失败: {e}"


def chat_loop():
    agent = ScorecardAgent()
    client = init_client()
    agent.client = client

    messages = [{
        "role": "system",
        "content": (
            "你是一个评分卡开发助手。你有以下工具可用：\n"
            "1. load_data - 加载数据（必须先加载）\n"
            "2. run_binning - 自动分箱+审查\n"
            "3. update_binning - 调整单个变量的分箱（如'Age每5岁一组'）\n"
            "4. show_binning - 查看某个变量的分箱详情\n"
            "5. train_model - 训练逻辑回归模型\n"
            "6. evaluate - 评估模型\n"
            "7. build_scorecard - 构建评分卡\n"
            "8. save - 保存模型\n"
            "9. status - 查看进度\n"
            "10. run_all - 一键全流程\n\n"
            "评分卡建模标准流程: load_data → run_binning → train_model → "
            "evaluate → build_scorecard → save。\n"
            "如果用户要调整某个变量分箱，先 update_binning 再继续后续步骤。\n"
            "如果用户说'一键建模'或'全流程'，直接调用 run_all。\n"
            "用中文简洁回复，不要太啰嗦。"
        ),
    }]

    print("=" * 55)
    print("  🃏 评分卡开发 Agent v13.0 (LLM 驱动)")
    print("  💬 自然语言交互，LLM 自动选择工具")
    print("=" * 55)
    print("  💡 你可以这样说:")
    print("     '帮我加载scorecard/Loan_default.csv'")
    print("     '一键建模'")
    print("     '把Age每5岁分一组，Income每10000分一组'")
    print("     '看看Age的分箱效果'")
    print("     '看看现在的进度'")
    print("  /clear  - 清空对话  |  /exit  - 退出")
    print("=" * 55)

    while True:
        try:
            user_input = input("\n🧑 你: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n👋 再见！")
            break

        if not user_input:
            continue
        if user_input == "/exit":
            print("👋 再见！")
            break
        if user_input == "/clear":
            messages = [messages[0]]
            print("✅ 对话已清空")
            continue

        messages.append({"role": "user", "content": user_input})

        MAX_TURNS = 10
        for turn in range(MAX_TURNS):
            print(f"\n🤖 AI: ", end="", flush=True)

            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                temperature=0.3,
                max_tokens=4096,
            )

            choice = response.choices[0]

            if choice.finish_reason == "tool_calls":
                tool_calls = choice.message.tool_calls
                messages.append(choice.message)
                for tc in tool_calls:
                    result = run_tool_call(agent, tc)
                    # 截断过长结果
                    if len(result) > 2000:
                        result = result[:2000] + "\n...(结果已截断)"
                    print(result[:500])
                    if len(result) > 500:
                        print("  ...(输出较长，LLM 已收到完整结果)")
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result,
                    })
                continue

            if choice.finish_reason == "stop":
                content = choice.message.content or ""
                print(content, flush=True)
                messages.append({"role": "assistant", "content": content})
                break
        else:
            print("\n⚠️  达到最大工具调用轮次")

    print()


def main():
    chat_loop()


if __name__ == "__main__":
    main()