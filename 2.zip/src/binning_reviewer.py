"""
分箱审查器（React 模式）
======================
对 auto_woe_binning 的结果进行审查和优化：
- 边界规整为"好读"的数字（如年龄每5岁一档）
- 检查单调性、bad≥10、分箱数 3~7
- 不通过则自动调整，循环直到收敛

React 流程：
  Generation → Review(Reason) → Refine(Act) → Re-evaluate(Observe) → Loop
"""

import numpy as np
import pandas as pd

from .woe_calculator import calc_woe, _check_monotonic


# ==================== 边界规整 ====================


def _nice_step(value_range: float) -> int:
    """根据数值范围，自动选择合适的 nice step"""
    if value_range <= 10:
        return 1
    elif value_range <= 30:
        return 5
    elif value_range <= 100:
        return 10
    elif value_range <= 500:
        return 25
    elif value_range <= 2000:
        return 50
    elif value_range <= 10000:
        return 100
    elif value_range <= 100000:
        return 5000
    else:
        return 10000


def _round_to_nice(edges: list, step: int, vmin: float, vmax: float) -> list:
    """将分箱边界规整为 nice 数字"""
    nice = [vmin]
    for e in edges[1:-1]:
        rounded = round(e / step) * step
        if rounded <= nice[-1]:
            rounded = nice[-1] + step
        nice.append(rounded)
    if nice[-1] < vmax:
        nice.append(int(np.ceil(vmax / step)) * step)
    return nice


# ==================== 审查规则 ====================


def _review_bad_count(detail: pd.DataFrame, min_bad: int = 10) -> list[str]:
    """检查每箱 bad 数是否 ≥ min_bad"""
    issues = []
    for idx, row in detail.iterrows():
        if row["bad"] < min_bad:
            issues.append(f"箱 '{idx}' bad={int(row['bad'])} < {min_bad}")
    return issues


def _review_bin_count(detail: pd.DataFrame) -> list[str]:
    """检查分箱数是否在 3~7"""
    n = len(detail)
    if n < 3:
        return [f"分箱数={n} < 3，过少"]
    if n > 7:
        return [f"分箱数={n} > 7，过多"]
    return []


def _review_monotonic(detail: pd.DataFrame) -> list[str]:
    """检查 WOE 单调性"""
    mono = _check_monotonic(detail["woe"])
    if mono == "非单调":
        return ["WOE 非单调，违反业务约束"]
    return []


def _review_edge_niceness(edges: list, step: int) -> list[str]:
    """检查边界是否规整为 nice 数字"""
    issues = []
    for i, e in enumerate(edges):
        if e % step != 0 and i > 0 and i < len(edges) - 1:
            issues.append(f"边界 {e} 不是 {step} 的整数倍")
    return issues


# ==================== 调整策略 ====================


def _fix_nice_edges(df: pd.DataFrame, col: str, target: str,
                    edges: list, step: int) -> list:
    """规整边界为 nice 数字，同时保持 bad≥10"""
    vmin, vmax = df[col].min(), df[col].max()
    nice = _round_to_nice(edges, step, vmin, vmax)

    # 确保至少 3 个边界
    if len(nice) < 3:
        nice = [vmin, vmin + step, vmax]

    # 去重
    nice = sorted(set(nice))
    if len(nice) < 3:
        nice = [vmin, (vmin + vmax) / 2, vmax]

    return nice


def _fix_merge_small_bins(df: pd.DataFrame, col: str, target: str,
                          edges: list, min_bad: int = 10) -> list:
    """合并 bad < min_bad 的箱"""
    if len(edges) <= 3:
        return edges

    detail, _ = calc_woe(df, col, target, bins=edges)
    bad_vals = detail["bad"].values

    # 找到 bad 最小的箱，合并到相邻箱
    min_idx = int(np.argmin(bad_vals))
    if bad_vals[min_idx] >= min_bad:
        return edges

    # 合并到相邻箱（选 WOE 更接近的）
    woe_vals = detail["woe"].values
    if min_idx == 0:
        merge_idx = 0
    elif min_idx == len(bad_vals) - 1:
        merge_idx = min_idx - 1
    else:
        diff_left = abs(woe_vals[min_idx] - woe_vals[min_idx - 1])
        diff_right = abs(woe_vals[min_idx] - woe_vals[min_idx + 1])
        merge_idx = min_idx - 1 if diff_left < diff_right else min_idx

    new_edges = list(edges)
    del new_edges[merge_idx + 1]
    return new_edges


def _fix_monotonic_bins(df: pd.DataFrame, col: str, target: str,
                        edges: list) -> list:
    """修复非单调：找到违反单调性的位置，合并相邻箱"""
    if len(edges) <= 3:
        return edges

    detail, _ = calc_woe(df, col, target, bins=edges)
    woe_vals = detail["woe"].values
    diffs = np.diff(woe_vals)

    # 判断整体趋势
    pos_count = (diffs > 0).sum()
    neg_count = (diffs < 0).sum()

    # 找到违反趋势的位置
    if pos_count >= neg_count:
        # 整体递增，找递减的位置
        bad_idx = [i for i, d in enumerate(diffs) if d < 0]
    else:
        # 整体递减，找递增的位置
        bad_idx = [i for i, d in enumerate(diffs) if d > 0]

    if not bad_idx:
        return edges

    # 合并第一个违反位置
    new_edges = list(edges)
    del new_edges[bad_idx[0] + 1]
    return new_edges


# ==================== React 主循环 ====================


def review_and_refine(df: pd.DataFrame, col: str, target: str,
                      initial_bins, min_bad: int = 10,
                      max_rounds: int = 5, verbose: bool = True) -> dict:
    """
    React 审查循环：对自动分箱进行审查和优化。

    参数:
        df: 数据
        col: 特征名
        target: 目标变量
        initial_bins: 初始分箱（auto_woe_binning 的输出）
        min_bad: 每箱最小坏样本数
        max_rounds: 最大审查轮次
        verbose: 是否打印审查过程

    返回:
        {"bins": 最终分箱参数, "detail": 分箱明细, "iv": IV值,
         "monotonic": 单调性, "rounds": 审查轮次记录, "passed": 是否通过}
    """
    is_numerical = isinstance(initial_bins, list)
    if not is_numerical:
        # 分类型：只做 bad≥10 检查，不规整边界
        detail, iv = calc_woe(df, col, target, bins=initial_bins)
        bad_issues = _review_bad_count(detail, min_bad)
        return {
            "bins": initial_bins,
            "detail": detail,
            "iv": iv,
            "monotonic": "N/A",
            "rounds": [],
            "passed": len(bad_issues) == 0,
        }

    # ---- 数值型：React 循环 ----
    current_edges = list(initial_bins)
    vmin, vmax = df[col].min(), df[col].max()
    value_range = vmax - vmin
    step = _nice_step(value_range)
    round_log = []

    for rnd in range(1, max_rounds + 1):
        detail, iv = calc_woe(df, col, target, bins=current_edges)

        # === Reason（审查） ===
        issues = _review_bad_count(detail, min_bad)
        issues += _review_bin_count(detail)
        issues += _review_monotonic(detail)
        issues += _review_edge_niceness(current_edges, step)

        if not issues:
            if verbose:
                print(f"  ✅ 第{rnd}轮审查通过（{len(current_edges)-1}箱）")
            return {
                "bins": current_edges,
                "detail": detail,
                "iv": iv,
                "monotonic": _check_monotonic(detail["woe"]),
                "rounds": round_log,
                "passed": True,
            }

        if verbose:
            print(f"  🔍 第{rnd}轮审查: {len(issues)}个问题")
            for issue in issues[:3]:
                print(f"     - {issue}")

        # === Act（调整） ===
        prev_edges = current_edges.copy()

        # 优先级1: 规整边界
        if _review_edge_niceness(current_edges, step):
            current_edges = _fix_nice_edges(df, col, target, current_edges, step)

        # 优先级2: bad 不足 → 合并
        bad_issues = _review_bad_count(detail, min_bad)
        if bad_issues:
            current_edges = _fix_merge_small_bins(df, col, target, current_edges, min_bad)

        # 优先级3: 非单调 → 合并
        if _review_monotonic(detail):
            current_edges = _fix_monotonic_bins(df, col, target, current_edges)

        # 优先级4: 箱数过多 → 合并
        if len(detail) > 7:
            # 合并 WOE 最接近的相邻箱
            woe_vals = detail["woe"].values
            woe_diffs = [abs(woe_vals[i] - woe_vals[i + 1]) for i in range(len(woe_vals) - 1)]
            merge_idx = int(np.argmin(woe_diffs))
            new_edges = list(current_edges)
            del new_edges[merge_idx + 1]
            current_edges = new_edges

        round_log.append({
            "round": rnd,
            "issues": len(issues),
            "edges_before": prev_edges,
            "edges_after": current_edges,
        })

        if current_edges == prev_edges:
            if verbose:
                print(f"  ⚠️  第{rnd}轮无变化，跳出循环")
            break

    # 最终结果
    detail, iv = calc_woe(df, col, target, bins=current_edges)
    final_issues = (
        _review_bad_count(detail, min_bad)
        + _review_monotonic(detail)
    )

    if verbose:
        if final_issues:
            print(f"  ⚠️  审查未完全通过（剩余{len(final_issues)}个问题，需人工介入）")
        else:
            print(f"  ✅ 审查通过（{len(current_edges)-1}箱）")

    return {
        "bins": current_edges,
        "detail": detail,
        "iv": iv,
        "monotonic": _check_monotonic(detail["woe"]),
        "rounds": round_log,
        "passed": len(final_issues) == 0,
    }


def review_auto_binning(df: pd.DataFrame, auto_results: dict, target: str = "Default",
                        min_bad: int = 10, max_rounds: int = 5,
                        verbose: bool = True) -> dict:
    """
    对 auto_woe_binning 的全部结果进行 React 审查。

    参数:
        df: 数据
        auto_results: auto_woe_binning 的返回结果
        target: 目标变量列名
        min_bad: 每箱最小坏样本数
        max_rounds: 最大审查轮次
        verbose: 是否打印审查过程

    返回:
        {变量名: {"bins": ..., "detail": ..., "iv": ..., "monotonic": ...,
                  "rounds": ..., "passed": ..., "type": ...}}
    """
    refined = {}
    for col, res in auto_results.items():
        if verbose:
            print(f"\n🔍 审查 [{col}] ({res['type']})")
        refined[col] = review_and_refine(
            df, col, target, res["bins"], min_bad, max_rounds, verbose
        )
        refined[col]["type"] = res["type"]
    return refined