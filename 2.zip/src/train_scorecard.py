"""
评分卡建模流水线
==============
1. 自动分箱 → 2. React 审查分箱 → 3. WOE 编码
→ 4. React 系数审查训练 → 5. 模型评估
→ 6. 评分卡打分转换 → 7. 保存模型
"""

import json
import shutil
import sys
import warnings
from pathlib import Path

# 确保可以从项目根目录导入
ROOT_DIR = Path(__file__).parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import joblib
import pandas as pd
from sklearn.model_selection import train_test_split

from scorecard.src.woe_calculator import auto_woe_binning, woe_encode
from scorecard.src.binning_reviewer import review_auto_binning
from scorecard.src.model_reviewer import train_with_coef_review
from scorecard.src.evaluate_model import evaluate_model
from scorecard.src.scorecard_builder import build_scorecard, print_scorecard

warnings.filterwarnings("ignore")

# ==================== 配置 ====================
DATA_PATH = Path(__file__).parent.parent / "Loan_default.csv"
MODEL_DIR = Path(__file__).parent.parent / "models"
MODEL_DIR.mkdir(exist_ok=True)

TARGET = "Default"
TEST_SIZE = 0.3
RANDOM_STATE = 42

# ==================== 1. 加载数据 ====================
print("=" * 55)
print("  评分卡建模流水线（含系数审查）")
print("=" * 55)

df = pd.read_csv(DATA_PATH)
print(f"\n📊 数据集: {df.shape[0]} 行, {df.shape[1]} 列")
print(f"📈 违约率: {df[TARGET].mean():.2%}")

# ==================== 2. 自动分箱 + 审查 ====================
print("\n🔍 Step 1: 自动最优分箱...")
auto_results = auto_woe_binning(df, target=TARGET, verbose=False)

print("🔍 Step 2: React 审查分箱...")
refined = review_auto_binning(df, auto_results, target=TARGET, verbose=False)

# ==================== 3. WOE 编码 ====================
print("\n🔧 Step 3: WOE 编码...")
features = [col for col in refined.keys()]
df_woe = woe_encode(df, refined, features=features)
woe_cols = [f"{c}_woe" for c in features]
print(f"  ✅ 生成 {len(woe_cols)} 个 WOE 特征")

# ==================== 4. React 系数审查训练 ====================
print("\n🚀 Step 4: React 系数审查训练...")
print(f"  📋 规则: WOE 评分卡系数应全部为负 (WOE↑ → 风险↓)\n")

X = df_woe[woe_cols].fillna(0)
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y
)

# React 训练循环
result = train_with_coef_review(
    X_train, y_train, X_test, y_test,
    expected_sign="negative",  # WOE 评分卡: 系数应为负
    max_rounds=10,
    verbose=True,
)

model = result["model"]
final_features = result["features"]
dropped = result["dropped"]

print(f"\n  📊 最终模型: {len(final_features)} 个特征, 全部通过系数审查")
if dropped:
    print(f"  🗑️  已剔除: {dropped}")

# ==================== 5. 模型评估 ====================
print("\n📊 Step 5: 模型区分度评估...")

train_df = X_train[final_features].copy()
train_df[TARGET] = y_train
test_df = X_test[final_features].copy()
test_df[TARGET] = y_test

train_metrics = evaluate_model(train_df, model, final_features, "训练集")
test_metrics = evaluate_model(test_df, model, final_features, "测试集")

# ==================== 6. 评分卡打分转换 ====================
print("\n📊 Step 6: 评分卡打分转换...")
coef_dict = dict(zip(final_features, model.coef_[0]))
scorecard_result = build_scorecard(
    df, refined, coef_dict, float(model.intercept_[0]),
    base_score=600, base_odds=50, pdo=20, target=TARGET,
)
print_scorecard(scorecard_result)

# 保存评分卡打分明细
scorecard_result["scorecard_table"].to_csv(
    MODEL_DIR / "scorecard_table.csv", index=False, encoding="utf-8-sig"
)
print(f"\n  ✅ scorecard_table.csv — 评分卡打分表")

# 保存评分分布
scorecard_result["score_stats"].to_csv(
    MODEL_DIR / "score_distribution.csv", index=False, encoding="utf-8-sig"
)
print(f"  ✅ score_distribution.csv — 评分分布")

# ==================== 7. 保存模型 ====================
print("\n💾 Step 7: 保存模型文件...")

# 7a. sklearn 模型
model_path = MODEL_DIR / "logistic_regression.pkl"
joblib.dump(model, model_path)
print(f"  ✅ logistic_regression.pkl")

# 7b. 模型元信息
meta = {
    "features": final_features,
    "coef": result["coef"],
    "intercept": result["intercept"],
    "dropped": dropped,
    "n_rounds": len(result["rounds"]),
    "train_score": result["train_score"],
    "test_score": result["test_score"],
    "scorecard_params": scorecard_result["params"],
}
meta_path = MODEL_DIR / "model_meta.json"
with open(meta_path, "w", encoding="utf-8") as f:
    json.dump(meta, f, ensure_ascii=False, indent=2)
print(f"  ✅ model_meta.json")

# 7c. 分箱参数
src = Path(__file__).parent.parent / "results" / "bin_mapping_refined.json"
if src.exists():
    dst = MODEL_DIR / "bin_mapping_refined.json"
    shutil.copy2(src, dst)
    print(f"  ✅ bin_mapping_refined.json")

# 7d. 评估结果
eval_result = {"train": train_metrics, "test": test_metrics}
eval_path = MODEL_DIR / "evaluation.json"
with open(eval_path, "w", encoding="utf-8") as f:
    json.dump(eval_result, f, ensure_ascii=False, indent=2)
print(f"  ✅ evaluation.json")

# 7e. 审查日志
review_path = MODEL_DIR / "coef_review_log.json"
with open(review_path, "w", encoding="utf-8") as f:
    json.dump(result["rounds"], f, ensure_ascii=False, indent=2)
print(f"  ✅ coef_review_log.json")

print(f"\n📁 所有文件保存至: {MODEL_DIR}")
print("=" * 55)