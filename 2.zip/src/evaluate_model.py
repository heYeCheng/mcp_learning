"""
模型评估脚本
============
计算评分卡模型的区分度指标：GINI 系数、KS 值、AUC。
可独立运行，也可被 train_scorecard.py 导入调用。
"""

import json
import sys
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve

warnings.filterwarnings("ignore")

ROOT_DIR = Path(__file__).parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# ==================== 配置 ====================
DATA_PATH = Path(__file__).parent.parent / "Loan_default.csv"
MODEL_DIR = Path(__file__).parent.parent / "models"
TARGET = "Default"


def calc_gini(y_true, y_score) -> float:
    """GINI = 2 * AUC - 1"""
    return 2 * roc_auc_score(y_true, y_score) - 1


def calc_ks(y_true, y_score) -> float:
    """KS = max(|TPR - FPR|)"""
    fpr, tpr, _ = roc_curve(y_true, y_score)
    return float(max(abs(tpr - fpr)))


def evaluate_model(df, model, woe_cols, dataset_name: str) -> dict:
    """对单个数据集计算并打印 AUC/GINI/KS"""
    X = df[woe_cols].fillna(0)
    y_true = df[TARGET]
    y_prob = model.predict_proba(X)[:, 1]

    auc = roc_auc_score(y_true, y_prob)
    gini = calc_gini(y_true, y_prob)
    ks = calc_ks(y_true, y_prob)

    print(f"\n{'='*50}")
    print(f"  📊 {dataset_name} 评估结果")
    print(f"{'='*50}")
    print(f"  AUC  : {auc:.4f}")
    print(f"  GINI : {gini:.4f}")
    print(f"  KS   : {ks:.4f}")
    print(f"  样本数: {len(y_true)}")

    return {"auc": round(auc, 4), "gini": round(gini, 4), "ks": round(ks, 4)}


def main():
    print("=" * 55)
    print("  模型区分度评估")
    print("=" * 55)

    # 1. 加载模型
    model_path = MODEL_DIR / "logistic_regression.pkl"
    if not model_path.exists():
        print(f"\n❌ 模型文件不存在: {model_path}\n   请先运行 train_scorecard.py")
        return

    model = joblib.load(model_path)
    print(f"\n✅ 模型已加载: {model_path}")

    # 2. 加载元信息（获取特征列）
    meta_path = MODEL_DIR / "model_meta.json"
    if not meta_path.exists():
        print(f"❌ 模型元信息不存在: {meta_path}")
        return
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    woe_cols = meta["features"]

    # 3. 加载原始数据 + 分箱参数
    df = pd.read_csv(DATA_PATH)
    bin_path = MODEL_DIR / "bin_mapping_refined.json"
    if not bin_path.exists():
        print(f"❌ 分箱参数不存在: {bin_path}")
        return
    with open(bin_path, "r", encoding="utf-8") as f:
        bin_mapping = json.load(f)

    # 4. 手动 WOE 编码
    from scorecard.src.woe_calculator import calc_woe

    df_woe = df.copy()
    for col in woe_cols:
        orig_col = col.replace("_woe", "")
        if orig_col not in bin_mapping:
            continue
        info = bin_mapping[orig_col]
        if info["type"] == "numerical":
            detail, _ = calc_woe(df, orig_col, TARGET, bins=info["breaks"])
            woe_map = detail["woe"].to_dict()
            df_woe[col] = pd.cut(df[orig_col], bins=info["breaks"], include_lowest=True).map(woe_map)
        else:
            detail, _ = calc_woe(df, orig_col, TARGET, bins=info["mapping"])
            woe_map = detail["woe"].to_dict()
            df_woe[col] = df[orig_col].map(info["mapping"]).fillna(df[orig_col]).map(woe_map)

    # 5. 划分训练/测试集
    from sklearn.model_selection import train_test_split

    X = df_woe[woe_cols].fillna(0)
    y = df[TARGET]
    X_train, X_test, _, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    test_df = X_test.copy()
    test_df[TARGET] = y_test

    # 6. 评估
    test_metrics = evaluate_model(test_df, model, woe_cols, "测试集")

    # 7. 保存
    eval_path = MODEL_DIR / "evaluation.json"
    with open(eval_path, "w", encoding="utf-8") as f:
        json.dump({"test": test_metrics}, f, ensure_ascii=False, indent=2)
    print(f"\n✅ 评估结果已保存: {eval_path}")


if __name__ == "__main__":
    main()