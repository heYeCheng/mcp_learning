"""
WOE 自动分箱分析脚本
====================
对 Loan_default.csv 全量特征进行自动最优分箱，保存结果。
"""

import json
import sys
import warnings
from pathlib import Path

import pandas as pd

ROOT_DIR = Path(__file__).parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from scorecard.src.woe_calculator import auto_woe_binning

warnings.filterwarnings("ignore")

# ==================== 配置 ====================
DATA_PATH = Path(__file__).parent.parent / "Loan_default.csv"
RESULT_DIR = Path(__file__).parent.parent / "results"
RESULT_DIR.mkdir(exist_ok=True)

# ==================== 1. 加载数据 ====================
print("=" * 60)
print("  WOE 自动分箱分析")
print("=" * 60)

df = pd.read_csv(DATA_PATH)
print(f"\n📊 数据集: {df.shape[0]} 行, {df.shape[1]} 列")
print(f"📈 违约率: {df['Default'].mean():.2%}")

# ==================== 2. 自动分箱 ====================
print("\n🔍 正在对所有特征进行自动最优分箱...\n")

results = auto_woe_binning(
    df,
    target="Default",
    min_bad=10,
    max_bins=7,
    verbose=True,
)

# ==================== 3. 保存结果 ====================

# 3a. IV 排名汇总
print("\n💾 保存结果中...")

iv_data = []
for col, res in results.items():
    iv_data.append({
        "特征": col,
        "类型": res["type"],
        "IV": round(res["iv"], 6),
        "分箱数": len(res["detail"]),
        "单调性": res["monotonic"],
    })

iv_df = pd.DataFrame(iv_data).sort_values("IV", ascending=False).reset_index(drop=True)
iv_df.index = iv_df.index + 1  # 排名从 1 开始
iv_df.index.name = "排名"
iv_path = RESULT_DIR / "iv_ranking.csv"
iv_df.to_csv(iv_path, encoding="utf-8-sig")
print(f"  ✅ iv_ranking.csv — IV 排名 ({len(iv_df)} 个特征)")

# 3b. 各特征分箱明细 + 分箱参数
bin_mapping = {}
for col, res in results.items():
    # 分箱明细表
    detail = res["detail"].copy()
    detail_path = RESULT_DIR / f"binning_{col}.csv"
    detail.to_csv(detail_path, encoding="utf-8-sig")

    # 分箱参数（用于后续 WOE 转换）
    bin_param = res["bins"]
    if isinstance(bin_param, list):
        # 数值型：保存边界
        bin_mapping[col] = {
            "type": "numerical",
            "breaks": [round(b, 4) for b in bin_param],
            "iv": round(res["iv"], 6),
            "monotonic": res["monotonic"],
        }
    else:
        # 分类型：保存类别映射
        bin_mapping[col] = {
            "type": "categorical",
            "mapping": {str(k): str(v) for k, v in bin_param.items()},
            "iv": round(res["iv"], 6),
        }

    print(f"  ✅ binning_{col}.csv — {col} 分箱明细 ({len(detail)} 箱)")

# 3c. 分箱映射配置（JSON，用于后续评分卡开发）
mapping_path = RESULT_DIR / "bin_mapping.json"
with open(mapping_path, "w", encoding="utf-8") as f:
    json.dump(bin_mapping, f, ensure_ascii=False, indent=2)
print(f"  ✅ bin_mapping.json — 分箱映射配置")

# 3d. 简便汇总表
summary_path = RESULT_DIR / "analysis_summary.csv"
iv_df.to_csv(summary_path, encoding="utf-8-sig")
print(f"  ✅ analysis_summary.csv — 分析汇总")

# ==================== 4. 输出报告 ====================
print("\n" + "=" * 60)
print("  分析报告")
print("=" * 60)

# IV 解读
print(f"\n{'排名':>4} {'特征':<20} {'类型':<12} {'IV':>10} {'分箱数':>6} {'单调性':>8}")
print("-" * 65)
for rank, (_, row) in enumerate(iv_df.iterrows(), 1):
    iv_val = row["IV"]
    if iv_val < 0.02:
        strength = "无预测力"
    elif iv_val < 0.1:
        strength = "弱"
    elif iv_val < 0.3:
        strength = "中等"
    elif iv_val < 0.5:
        strength = "强"
    else:
        strength = "极强"
    print(f"{rank:>4} {row['特征']:<20} {row['类型']:<12} {row['IV']:>10.6f} {row['分箱数']:>6} {row['单调性']:>8}")

# 特征评估
print("\n📋 特征预测力评估：")
strong_vars = iv_df[iv_df["IV"] >= 0.1]
weak_vars = iv_df[iv_df["IV"] < 0.02]
if len(strong_vars) > 0:
    print(f"  ✅ 强预测力 (IV≥0.1): {', '.join(strong_vars['特征'].values)}")
if len(weak_vars) > 0:
    print(f"  ⚠️  弱预测力 (IV<0.02): {', '.join(weak_vars['特征'].values)}")

# 非单调警告
non_mono = [col for col, res in results.items()
            if res["type"] == "numerical" and res["monotonic"] == "非单调"]
if non_mono:
    print(f"  ⚠️  非单调特征: {', '.join(non_mono)} — 建议检查业务合理性")

# 坏样本不足警告
print("\n🔍 各特征分箱 bad 数检查：")
for col, res in results.items():
    min_bad = res["detail"]["bad"].min()
    if min_bad < 10:
        print(f"  ⚠️  {col}: 最小 bad={int(min_bad)} < 10，建议人工调整")

print(f"\n📁 所有结果已保存至: {RESULT_DIR}")
print("=" * 60)