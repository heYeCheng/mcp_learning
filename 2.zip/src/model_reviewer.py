"""
模型系数审查器（React 模式）
============================
审查逻辑回归系数正负是否符合业务预期。

WOE 评分卡业务规则：
  - WOE = ln(%good / %bad)，WOE 越高 = 风险越低
  - 预测 Default=1 时，系数应为负（WOE 越高 → 违约概率越低）
  - 如果某个变量系数为正，说明该变量与业务逻辑矛盾，应剔除

React 流程：
  Train → Review(系数正负 vs 业务规则) → 
    → 有问题 → 剔除变量 → retrain → review again
    → 没问题 → 输出最终模型
"""

import warnings
from copy import deepcopy

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")


def _review_coefficients(coef_dict: dict, expected_sign: str = "negative") -> list[str]:
    """
    审查系数正负是否符合业务预期。

    参数:
        coef_dict: {特征名: 系数值}
        expected_sign: "negative"(全部负) 或 "positive"(全部正)

    返回:
        有问题的特征列表（系数符号不符合预期的）
    """
    bad_features = []
    for feat, coef in coef_dict.items():
        if expected_sign == "negative" and coef > 0:
            bad_features.append(feat)
        elif expected_sign == "positive" and coef < 0:
            bad_features.append(feat)
    return bad_features


def train_with_coef_review(
    X_train, y_train, X_test, y_test,
    expected_sign: str = "negative",
    max_rounds: int = 10,
    verbose: bool = True,
    model_kwargs: dict = None,
):
    """
    React 循环训练：训练 → 审查系数 → 剔除问题变量 → 重新训练。

    参数:
        X_train, y_train: 训练集
        X_test, y_test: 测试集
        expected_sign: 期望系数符号，"negative"(全部负) 或 "positive"(全部正)
        max_rounds: 最大审查轮次
        verbose: 是否打印过程
        model_kwargs: 传给 LogisticRegression 的参数

    返回:
        {
            "model": 最终模型,
            "features": 最终使用的特征列表,
            "dropped": 被剔除的特征列表,
            "rounds": 审查轮次记录,
            "coef": 最终系数,
            "intercept": 截距,
            "train_score": 训练集准确率,
            "test_score": 测试集准确率,
            "passed": 是否全部通过,
        }
    """
    if model_kwargs is None:
        model_kwargs = {"C": 1.0, "solver": "lbfgs", "max_iter": 1000, "random_state": 42}

    current_features = list(X_train.columns)
    dropped_features = []
    round_log = []

    for rnd in range(1, max_rounds + 1):
        # 训练
        X_train_sub = X_train[current_features].fillna(0)
        X_test_sub = X_test[current_features].fillna(0)

        model = LogisticRegression(**model_kwargs)
        model.fit(X_train_sub, y_train)

        coef_dict = dict(zip(current_features, model.coef_[0]))
        train_score = model.score(X_train_sub, y_train)
        test_score = model.score(X_test_sub, y_test)

        # 审查系数
        bad_features = _review_coefficients(coef_dict, expected_sign)

        round_log.append({
            "round": rnd,
            "n_features": len(current_features),
            "bad_features": list(bad_features),
            "train_score": round(train_score, 4),
            "test_score": round(test_score, 4),
        })

        if verbose:
            sign_str = "全部为负" if expected_sign == "negative" else "全部为正"
            status = "✅" if not bad_features else f"⚠️  发现 {len(bad_features)} 个符号异常"
            print(f"  第{rnd}轮: {len(current_features)}个特征  train_acc={train_score:.4f}  test_acc={test_score:.4f}  {status}")
            if bad_features:
                for f in bad_features:
                    print(f"    剔除 {f} (系数={coef_dict[f]:+.4f}, 期望{sign_str})")

        if not bad_features:
            if verbose:
                print(f"  ✅ 全部系数符号符合预期（{sign_str}）")
            return {
                "model": model,
                "features": current_features,
                "dropped": dropped_features,
                "rounds": round_log,
                "coef": {f: float(model.coef_[0][i]) for i, f in enumerate(current_features)},
                "intercept": float(model.intercept_[0]),
                "train_score": round(train_score, 4),
                "test_score": round(test_score, 4),
                "passed": True,
            }

        # 剔除问题变量
        for f in bad_features:
            current_features.remove(f)
            dropped_features.append(f)

        if not current_features:
            if verbose:
                print("  ❌ 所有特征均被剔除，无法建模")
            return {
                "model": None,
                "features": [],
                "dropped": dropped_features,
                "rounds": round_log,
                "coef": {},
                "intercept": 0,
                "train_score": 0,
                "test_score": 0,
                "passed": False,
            }

        # 继续下一轮

    # 超过最大轮次
    if verbose:
        print(f"  ⚠️  达到最大审查轮次({max_rounds})，仍有 {len(bad_features)} 个符号异常特征")

    # 用最后一轮模型
    return {
        "model": model,
        "features": current_features,
        "dropped": dropped_features,
        "rounds": round_log,
        "coef": {f: float(model.coef_[0][i]) for i, f in enumerate(current_features)},
        "intercept": float(model.intercept_[0]),
        "train_score": round(train_score, 4),
        "test_score": round(test_score, 4),
        "passed": len(bad_features) == 0,
    }